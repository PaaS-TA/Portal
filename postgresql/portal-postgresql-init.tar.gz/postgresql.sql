--
-- PostgreSQL database dump
--

-- Dumped from database version 9.4.6
-- Dumped by pg_dump version 9.5.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE portaldb;
--
-- Name: portaldb; Type: DATABASE; Schema: -; Owner: vcap
--

CREATE DATABASE portaldb WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE portaldb OWNER TO vcap;

\connect portaldb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: vcap
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO vcap;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: vcap
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


SET search_path = public, pg_catalog;

--
-- Name: administrable_role_authorizations; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW administrable_role_authorizations AS
 SELECT applicable_roles.grantee,
    applicable_roles.role_name,
    applicable_roles.is_grantable
   FROM information_schema.applicable_roles
  WHERE ((applicable_roles.is_grantable)::text = 'YES'::text);


ALTER TABLE administrable_role_authorizations OWNER TO portaladmin;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: answer; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE answer (
    no integer NOT NULL,
    content text NOT NULL,
    file_name character varying(255),
    file_path character varying(512),
    file_size bigint,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone,
    question_no integer NOT NULL,
    answerer character varying(128) NOT NULL
);


ALTER TABLE answer OWNER TO portaladmin;

--
-- Name: COLUMN answer.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.no IS '고유번호';


--
-- Name: COLUMN answer.content; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.content IS '내용';


--
-- Name: COLUMN answer.file_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.file_name IS '첨부파일_이름';


--
-- Name: COLUMN answer.file_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.file_path IS '첨부파일_주소';


--
-- Name: COLUMN answer.file_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.file_size IS '첨부파일_크기';


--
-- Name: COLUMN answer.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.created IS '생성시간';


--
-- Name: COLUMN answer.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.lastmodified IS '마지막_수정_시간';


--
-- Name: COLUMN answer.question_no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.question_no IS '문의_고유번호';


--
-- Name: COLUMN answer.answerer; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN answer.answerer IS '답변자_ID';


--
-- Name: answer_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE answer_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE answer_no_seq OWNER TO portaladmin;

--
-- Name: answer_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE answer_no_seq OWNED BY answer.no;


--
-- Name: applicable_roles; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW applicable_roles AS
 SELECT (a.rolname)::information_schema.sql_identifier AS grantee,
    (b.rolname)::information_schema.sql_identifier AS role_name,
    (
        CASE
            WHEN m.admin_option THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ((pg_auth_members m
     JOIN pg_authid a ON ((m.member = a.oid)))
     JOIN pg_authid b ON ((m.roleid = b.oid)))
  WHERE pg_has_role(a.oid, 'USAGE'::text);


ALTER TABLE applicable_roles OWNER TO portaladmin;

--
-- Name: attributes; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW attributes AS
 SELECT (current_database())::information_schema.sql_identifier AS udt_catalog,
    (nc.nspname)::information_schema.sql_identifier AS udt_schema,
    (c.relname)::information_schema.sql_identifier AS udt_name,
    (a.attname)::information_schema.sql_identifier AS attribute_name,
    (a.attnum)::information_schema.cardinal_number AS ordinal_position,
    (pg_get_expr(ad.adbin, ad.adrelid))::information_schema.character_data AS attribute_default,
    (
        CASE
            WHEN (a.attnotnull OR ((t.typtype = 'd'::"char") AND t.typnotnull)) THEN 'NO'::text
            ELSE 'YES'::text
        END)::information_schema.yes_or_no AS is_nullable,
    (
        CASE
            WHEN ((t.typelem <> (0)::oid) AND (t.typlen = (-1))) THEN 'ARRAY'::text
            WHEN (nt.nspname = 'pg_catalog'::name) THEN format_type(a.atttypid, NULL::integer)
            ELSE 'USER-DEFINED'::text
        END)::information_schema.character_data AS data_type,
    (information_schema._pg_char_max_length(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS character_maximum_length,
    (information_schema._pg_char_octet_length(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS character_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (
        CASE
            WHEN (nco.nspname IS NOT NULL) THEN current_database()
            ELSE NULL::name
        END)::information_schema.sql_identifier AS collation_catalog,
    (nco.nspname)::information_schema.sql_identifier AS collation_schema,
    (co.collname)::information_schema.sql_identifier AS collation_name,
    (information_schema._pg_numeric_precision(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS numeric_precision,
    (information_schema._pg_numeric_precision_radix(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS numeric_precision_radix,
    (information_schema._pg_numeric_scale(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS numeric_scale,
    (information_schema._pg_datetime_precision(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS datetime_precision,
    (information_schema._pg_interval_type(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (current_database())::information_schema.sql_identifier AS attribute_udt_catalog,
    (nt.nspname)::information_schema.sql_identifier AS attribute_udt_schema,
    (t.typname)::information_schema.sql_identifier AS attribute_udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS scope_name,
    (NULL::integer)::information_schema.cardinal_number AS maximum_cardinality,
    (a.attnum)::information_schema.sql_identifier AS dtd_identifier,
    ('NO'::character varying)::information_schema.yes_or_no AS is_derived_reference_attribute
   FROM ((((pg_attribute a
     LEFT JOIN pg_attrdef ad ON (((a.attrelid = ad.adrelid) AND (a.attnum = ad.adnum))))
     JOIN (pg_class c
     JOIN pg_namespace nc ON ((c.relnamespace = nc.oid))) ON ((a.attrelid = c.oid)))
     JOIN (pg_type t
     JOIN pg_namespace nt ON ((t.typnamespace = nt.oid))) ON ((a.atttypid = t.oid)))
     LEFT JOIN (pg_collation co
     JOIN pg_namespace nco ON ((co.collnamespace = nco.oid))) ON (((a.attcollation = co.oid) AND ((nco.nspname <> 'pg_catalog'::name) OR (co.collname <> 'default'::name)))))
  WHERE ((((a.attnum > 0) AND (NOT a.attisdropped)) AND (c.relkind = 'c'::"char")) AND (pg_has_role(c.relowner, 'USAGE'::text) OR has_type_privilege(c.reltype, 'USAGE'::text)));


ALTER TABLE attributes OWNER TO portaladmin;

--
-- Name: auto_scaling_config; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE auto_scaling_config (
    no integer NOT NULL,
    guid character varying(255) NOT NULL,
    org character varying(255),
    space character varying(255),
    app character varying(255),
    instance_min_cnt integer NOT NULL,
    instance_max_cnt integer NOT NULL,
    cpu_threshold_min_per numeric(2,1) NOT NULL,
    cpu_threshold_max_per numeric(2,1) NOT NULL,
    memory_min_size integer,
    memory_max_size integer,
    check_time_sec integer NOT NULL,
    auto_increase_yn character(1),
    auto_decrease_yn character(1)
);


ALTER TABLE auto_scaling_config OWNER TO portaladmin;

--
-- Name: COLUMN auto_scaling_config.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.no IS '고유번호';


--
-- Name: COLUMN auto_scaling_config.guid; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.guid IS '고유식별자';


--
-- Name: COLUMN auto_scaling_config.org; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.org IS '조직';


--
-- Name: COLUMN auto_scaling_config.space; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.space IS '공간';


--
-- Name: COLUMN auto_scaling_config.app; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.app IS '앱';


--
-- Name: COLUMN auto_scaling_config.instance_min_cnt; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.instance_min_cnt IS '인스턴스_최소_수';


--
-- Name: COLUMN auto_scaling_config.instance_max_cnt; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.instance_max_cnt IS '인스턴스_최대_수';


--
-- Name: COLUMN auto_scaling_config.cpu_threshold_min_per; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.cpu_threshold_min_per IS 'cpu_임계_최소_값';


--
-- Name: COLUMN auto_scaling_config.cpu_threshold_max_per; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.cpu_threshold_max_per IS 'cpu_임계_최대_값';


--
-- Name: COLUMN auto_scaling_config.memory_min_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.memory_min_size IS '메모리 최소';


--
-- Name: COLUMN auto_scaling_config.memory_max_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.memory_max_size IS '메모리 최대';


--
-- Name: COLUMN auto_scaling_config.check_time_sec; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.check_time_sec IS '체크_시간_초';


--
-- Name: COLUMN auto_scaling_config.auto_increase_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.auto_increase_yn IS '자동확장유무';


--
-- Name: COLUMN auto_scaling_config.auto_decrease_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN auto_scaling_config.auto_decrease_yn IS '자동축소유무';


--
-- Name: board; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE board (
    no integer NOT NULL,
    title character varying(255) NOT NULL,
    user_id character varying(128) NOT NULL,
    content text,
    file_name character varying(255),
    file_path character varying(512),
    file_size bigint,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone,
    parent_no integer NOT NULL,
    group_no integer NOT NULL
);


ALTER TABLE board OWNER TO portaladmin;

--
-- Name: COLUMN board.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.no IS '고유번호';


--
-- Name: COLUMN board.title; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.title IS '제목';


--
-- Name: COLUMN board.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.user_id IS '사용자_아이디';


--
-- Name: COLUMN board.content; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.content IS '내용';


--
-- Name: COLUMN board.file_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.file_name IS '첨부파일_이름';


--
-- Name: COLUMN board.file_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.file_path IS '첨부파일_주소';


--
-- Name: COLUMN board.file_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.file_size IS '첨부파일_크기';


--
-- Name: COLUMN board.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.created IS '생성시간';


--
-- Name: COLUMN board.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.lastmodified IS '마지막_수정_시간';


--
-- Name: COLUMN board.parent_no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.parent_no IS '상위_게시글_번호';


--
-- Name: COLUMN board.group_no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN board.group_no IS '그룹_고유_번호';


--
-- Name: board_comment; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE board_comment (
    no integer NOT NULL,
    user_id character varying(128) NOT NULL,
    content text NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone,
    board_no integer NOT NULL,
    parent_no integer NOT NULL,
    group_no integer NOT NULL
);


ALTER TABLE board_comment OWNER TO portaladmin;

--
-- Name: board_comment_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE board_comment_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE board_comment_no_seq OWNER TO portaladmin;

--
-- Name: board_comment_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE board_comment_no_seq OWNED BY board_comment.no;


--
-- Name: board_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE board_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE board_no_seq OWNER TO portaladmin;

--
-- Name: board_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE board_no_seq OWNED BY board.no;


--
-- Name: bom; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE bom (
    item_id integer NOT NULL,
    parent_id integer,
    item_name character varying(20) NOT NULL,
    item_qty integer
);


ALTER TABLE bom OWNER TO portaladmin;

--
-- Name: buildpack_category; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE buildpack_category (
    no integer NOT NULL,
    name character varying(255) NOT NULL,
    classification character varying(36) NOT NULL,
    summary character varying(255) NOT NULL,
    description text,
    buildpack_name character varying(255) NOT NULL,
    thumb_img_name character varying(255),
    thumb_img_path character varying(512),
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    app_sample_file_name character varying(255),
    app_sample_file_path character varying(512),
    app_sample_file_size bigint,
    user_id character varying(128) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE buildpack_category OWNER TO portaladmin;

--
-- Name: COLUMN buildpack_category.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.no IS '고유번호';


--
-- Name: COLUMN buildpack_category.name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.name IS '이름';


--
-- Name: COLUMN buildpack_category.classification; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.classification IS '분류';


--
-- Name: COLUMN buildpack_category.summary; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.summary IS '요약';


--
-- Name: COLUMN buildpack_category.description; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.description IS '설명';


--
-- Name: COLUMN buildpack_category.buildpack_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.buildpack_name IS '빌드팩_이름';


--
-- Name: COLUMN buildpack_category.thumb_img_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.thumb_img_name IS '썸네일_이름';


--
-- Name: COLUMN buildpack_category.thumb_img_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.thumb_img_path IS '썸네일_경로';


--
-- Name: COLUMN buildpack_category.use_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.use_yn IS '사용_여부';


--
-- Name: COLUMN buildpack_category.app_sample_file_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.app_sample_file_name IS '앱_샘플_파일_이름';


--
-- Name: COLUMN buildpack_category.app_sample_file_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.app_sample_file_path IS '앱_샘플_파일_경로';


--
-- Name: COLUMN buildpack_category.app_sample_file_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.app_sample_file_size IS '앱_샘플_파일_크기';


--
-- Name: COLUMN buildpack_category.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.user_id IS '사용자_아이디';


--
-- Name: COLUMN buildpack_category.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.created IS '생성시간';


--
-- Name: COLUMN buildpack_category.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN buildpack_category.lastmodified IS '마지막_수정_시간';


--
-- Name: buildpack_category_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE buildpack_category_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE buildpack_category_no_seq OWNER TO portaladmin;

--
-- Name: buildpack_category_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE buildpack_category_no_seq OWNED BY buildpack_category.no;


--
-- Name: catalog_history; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE catalog_history (
    no integer NOT NULL,
    catalog_no integer NOT NULL,
    catalog_type character varying(255) NOT NULL,
    user_id character varying(128) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE catalog_history OWNER TO portaladmin;

--
-- Name: COLUMN catalog_history.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN catalog_history.no IS '고유번호';


--
-- Name: COLUMN catalog_history.catalog_no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN catalog_history.catalog_no IS '카탈로그_번호';


--
-- Name: COLUMN catalog_history.catalog_type; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN catalog_history.catalog_type IS '카탈로그_유형';


--
-- Name: COLUMN catalog_history.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN catalog_history.user_id IS '사용자_아이디';


--
-- Name: COLUMN catalog_history.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN catalog_history.created IS '생성시간';


--
-- Name: COLUMN catalog_history.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN catalog_history.lastmodified IS '마지막_수정시간';


--
-- Name: catalog_history_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE catalog_history_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE catalog_history_no_seq OWNER TO portaladmin;

--
-- Name: catalog_history_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE catalog_history_no_seq OWNED BY catalog_history.no;


--
-- Name: character_sets; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW character_sets AS
 SELECT (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (getdatabaseencoding())::information_schema.sql_identifier AS character_set_name,
    (
        CASE
            WHEN (getdatabaseencoding() = 'UTF8'::name) THEN 'UCS'::name
            ELSE getdatabaseencoding()
        END)::information_schema.sql_identifier AS character_repertoire,
    (getdatabaseencoding())::information_schema.sql_identifier AS form_of_use,
    (current_database())::information_schema.sql_identifier AS default_collate_catalog,
    (nc.nspname)::information_schema.sql_identifier AS default_collate_schema,
    (c.collname)::information_schema.sql_identifier AS default_collate_name
   FROM (pg_database d
     LEFT JOIN (pg_collation c
     JOIN pg_namespace nc ON ((c.collnamespace = nc.oid))) ON (((d.datcollate = c.collcollate) AND (d.datctype = c.collctype))))
  WHERE (d.datname = current_database())
  ORDER BY char_length((c.collname)::text) DESC, c.collname
 LIMIT 1;


ALTER TABLE character_sets OWNER TO portaladmin;

--
-- Name: check_constraint_routine_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW check_constraint_routine_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (nc.nspname)::information_schema.sql_identifier AS constraint_schema,
    (c.conname)::information_schema.sql_identifier AS constraint_name,
    (current_database())::information_schema.sql_identifier AS specific_catalog,
    (np.nspname)::information_schema.sql_identifier AS specific_schema,
    ((((p.proname)::text || '_'::text) || (p.oid)::text))::information_schema.sql_identifier AS specific_name
   FROM pg_namespace nc,
    pg_constraint c,
    pg_depend d,
    pg_proc p,
    pg_namespace np
  WHERE ((((((((nc.oid = c.connamespace) AND (c.contype = 'c'::"char")) AND (c.oid = d.objid)) AND (d.classid = ('pg_constraint'::regclass)::oid)) AND (d.refobjid = p.oid)) AND (d.refclassid = ('pg_proc'::regclass)::oid)) AND (p.pronamespace = np.oid)) AND pg_has_role(p.proowner, 'USAGE'::text));


ALTER TABLE check_constraint_routine_usage OWNER TO portaladmin;

--
-- Name: check_constraints; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW check_constraints AS
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (rs.nspname)::information_schema.sql_identifier AS constraint_schema,
    (con.conname)::information_schema.sql_identifier AS constraint_name,
    ("substring"(pg_get_constraintdef(con.oid), 7))::information_schema.character_data AS check_clause
   FROM (((pg_constraint con
     LEFT JOIN pg_namespace rs ON ((rs.oid = con.connamespace)))
     LEFT JOIN pg_class c ON ((c.oid = con.conrelid)))
     LEFT JOIN pg_type t ON ((t.oid = con.contypid)))
  WHERE (pg_has_role(COALESCE(c.relowner, t.typowner), 'USAGE'::text) AND (con.contype = 'c'::"char"))
UNION
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (n.nspname)::information_schema.sql_identifier AS constraint_schema,
    (((((((n.oid)::text || '_'::text) || (r.oid)::text) || '_'::text) || (a.attnum)::text) || '_not_null'::text))::information_schema.sql_identifier AS constraint_name,
    (((a.attname)::text || ' IS NOT NULL'::text))::information_schema.character_data AS check_clause
   FROM pg_namespace n,
    pg_class r,
    pg_attribute a
  WHERE (((((((n.oid = r.relnamespace) AND (r.oid = a.attrelid)) AND (a.attnum > 0)) AND (NOT a.attisdropped)) AND a.attnotnull) AND (r.relkind = 'r'::"char")) AND pg_has_role(r.relowner, 'USAGE'::text));


ALTER TABLE check_constraints OWNER TO portaladmin;

--
-- Name: code_detail; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE code_detail (
    key character varying(36) NOT NULL,
    value character varying(256) NOT NULL,
    summary character varying(255),
    group_id character varying(36) NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    "order" integer DEFAULT 1 NOT NULL,
    user_id character varying(128) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE code_detail OWNER TO portaladmin;

--
-- Name: COLUMN code_detail.key; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.key IS '키';


--
-- Name: COLUMN code_detail.value; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.value IS '값';


--
-- Name: COLUMN code_detail.summary; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.summary IS '요약';


--
-- Name: COLUMN code_detail.group_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.group_id IS '그룹_아이디';


--
-- Name: COLUMN code_detail.use_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.use_yn IS '사용여부';


--
-- Name: COLUMN code_detail."order"; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail."order" IS '순서';


--
-- Name: COLUMN code_detail.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.user_id IS '사용자_아이디';


--
-- Name: COLUMN code_detail.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.created IS '생성시간';


--
-- Name: COLUMN code_detail.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_detail.lastmodified IS '마지막_수정_시간';


--
-- Name: code_group; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE code_group (
    id character varying(35) NOT NULL,
    name character varying(256) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone,
    user_id character varying(128) NOT NULL
);


ALTER TABLE code_group OWNER TO portaladmin;

--
-- Name: COLUMN code_group.id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_group.id IS '키';


--
-- Name: COLUMN code_group.name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_group.name IS '값';


--
-- Name: COLUMN code_group.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_group.created IS '생성시간';


--
-- Name: COLUMN code_group.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_group.lastmodified IS '마지막_수정_시간';


--
-- Name: COLUMN code_group.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN code_group.user_id IS '사용자_아이디';


--
-- Name: collation_character_set_applicability; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW collation_character_set_applicability AS
 SELECT (current_database())::information_schema.sql_identifier AS collation_catalog,
    (nc.nspname)::information_schema.sql_identifier AS collation_schema,
    (c.collname)::information_schema.sql_identifier AS collation_name,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (getdatabaseencoding())::information_schema.sql_identifier AS character_set_name
   FROM pg_collation c,
    pg_namespace nc
  WHERE ((c.collnamespace = nc.oid) AND (c.collencoding = ANY (ARRAY[(-1), ( SELECT pg_database.encoding
           FROM pg_database
          WHERE (pg_database.datname = current_database()))])));


ALTER TABLE collation_character_set_applicability OWNER TO portaladmin;

--
-- Name: collations; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW collations AS
 SELECT (current_database())::information_schema.sql_identifier AS collation_catalog,
    (nc.nspname)::information_schema.sql_identifier AS collation_schema,
    (c.collname)::information_schema.sql_identifier AS collation_name,
    ('NO PAD'::character varying)::information_schema.character_data AS pad_attribute
   FROM pg_collation c,
    pg_namespace nc
  WHERE ((c.collnamespace = nc.oid) AND (c.collencoding = ANY (ARRAY[(-1), ( SELECT pg_database.encoding
           FROM pg_database
          WHERE (pg_database.datname = current_database()))])));


ALTER TABLE collations OWNER TO portaladmin;

--
-- Name: column_domain_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW column_domain_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS domain_catalog,
    (nt.nspname)::information_schema.sql_identifier AS domain_schema,
    (t.typname)::information_schema.sql_identifier AS domain_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (c.relname)::information_schema.sql_identifier AS table_name,
    (a.attname)::information_schema.sql_identifier AS column_name
   FROM pg_type t,
    pg_namespace nt,
    pg_class c,
    pg_namespace nc,
    pg_attribute a
  WHERE (((((((((t.typnamespace = nt.oid) AND (c.relnamespace = nc.oid)) AND (a.attrelid = c.oid)) AND (a.atttypid = t.oid)) AND (t.typtype = 'd'::"char")) AND (c.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"]))) AND (a.attnum > 0)) AND (NOT a.attisdropped)) AND pg_has_role(t.typowner, 'USAGE'::text));


ALTER TABLE column_domain_usage OWNER TO portaladmin;

--
-- Name: column_options; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW column_options AS
 SELECT (current_database())::information_schema.sql_identifier AS table_catalog,
    c.nspname AS table_schema,
    c.relname AS table_name,
    c.attname AS column_name,
    ((pg_options_to_table(c.attfdwoptions)).option_name)::information_schema.sql_identifier AS option_name,
    ((pg_options_to_table(c.attfdwoptions)).option_value)::information_schema.character_data AS option_value
   FROM information_schema._pg_foreign_table_columns c;


ALTER TABLE column_options OWNER TO portaladmin;

--
-- Name: column_privileges; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW column_privileges AS
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (x.relname)::information_schema.sql_identifier AS table_name,
    (x.attname)::information_schema.sql_identifier AS column_name,
    (x.prtype)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(x.grantee, x.relowner, 'USAGE'::text) OR x.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pr_c.grantor,
            pr_c.grantee,
            a.attname,
            pr_c.relname,
            pr_c.relnamespace,
            pr_c.prtype,
            pr_c.grantable,
            pr_c.relowner
           FROM ( SELECT pg_class.oid,
                    pg_class.relname,
                    pg_class.relnamespace,
                    pg_class.relowner,
                    (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor AS grantor,
                    (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantee AS grantee,
                    (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).privilege_type AS privilege_type,
                    (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).is_grantable AS is_grantable
                   FROM pg_class
                  WHERE (pg_class.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"]))) pr_c(oid, relname, relnamespace, relowner, grantor, grantee, prtype, grantable),
            pg_attribute a
          WHERE (((a.attrelid = pr_c.oid) AND (a.attnum > 0)) AND (NOT a.attisdropped))
        UNION
         SELECT pr_a.grantor,
            pr_a.grantee,
            pr_a.attname,
            c.relname,
            c.relnamespace,
            pr_a.prtype,
            pr_a.grantable,
            c.relowner
           FROM ( SELECT a.attrelid,
                    a.attname,
                    (aclexplode(COALESCE(a.attacl, acldefault('c'::"char", cc.relowner)))).grantor AS grantor,
                    (aclexplode(COALESCE(a.attacl, acldefault('c'::"char", cc.relowner)))).grantee AS grantee,
                    (aclexplode(COALESCE(a.attacl, acldefault('c'::"char", cc.relowner)))).privilege_type AS privilege_type,
                    (aclexplode(COALESCE(a.attacl, acldefault('c'::"char", cc.relowner)))).is_grantable AS is_grantable
                   FROM (pg_attribute a
                     JOIN pg_class cc ON ((a.attrelid = cc.oid)))
                  WHERE ((a.attnum > 0) AND (NOT a.attisdropped))) pr_a(attrelid, attname, grantor, grantee, prtype, grantable),
            pg_class c
          WHERE ((pr_a.attrelid = c.oid) AND (c.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"])))) x,
    pg_namespace nc,
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE (((((x.relnamespace = nc.oid) AND (x.grantee = grantee.oid)) AND (x.grantor = u_grantor.oid)) AND (x.prtype = ANY (ARRAY['INSERT'::text, 'SELECT'::text, 'UPDATE'::text, 'REFERENCES'::text]))) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)));


ALTER TABLE column_privileges OWNER TO portaladmin;

--
-- Name: column_udt_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW column_udt_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS udt_catalog,
    (COALESCE(nbt.nspname, nt.nspname))::information_schema.sql_identifier AS udt_schema,
    (COALESCE(bt.typname, t.typname))::information_schema.sql_identifier AS udt_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (c.relname)::information_schema.sql_identifier AS table_name,
    (a.attname)::information_schema.sql_identifier AS column_name
   FROM pg_attribute a,
    pg_class c,
    pg_namespace nc,
    ((pg_type t
     JOIN pg_namespace nt ON ((t.typnamespace = nt.oid)))
     LEFT JOIN (pg_type bt
     JOIN pg_namespace nbt ON ((bt.typnamespace = nbt.oid))) ON (((t.typtype = 'd'::"char") AND (t.typbasetype = bt.oid))))
  WHERE (((((((a.attrelid = c.oid) AND (a.atttypid = t.oid)) AND (nc.oid = c.relnamespace)) AND (a.attnum > 0)) AND (NOT a.attisdropped)) AND (c.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"]))) AND pg_has_role(COALESCE(bt.typowner, t.typowner), 'USAGE'::text));


ALTER TABLE column_udt_usage OWNER TO portaladmin;

--
-- Name: columns; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW columns AS
 SELECT (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (c.relname)::information_schema.sql_identifier AS table_name,
    (a.attname)::information_schema.sql_identifier AS column_name,
    (a.attnum)::information_schema.cardinal_number AS ordinal_position,
    (pg_get_expr(ad.adbin, ad.adrelid))::information_schema.character_data AS column_default,
    (
        CASE
            WHEN (a.attnotnull OR ((t.typtype = 'd'::"char") AND t.typnotnull)) THEN 'NO'::text
            ELSE 'YES'::text
        END)::information_schema.yes_or_no AS is_nullable,
    (
        CASE
            WHEN (t.typtype = 'd'::"char") THEN
            CASE
                WHEN ((bt.typelem <> (0)::oid) AND (bt.typlen = (-1))) THEN 'ARRAY'::text
                WHEN (nbt.nspname = 'pg_catalog'::name) THEN format_type(t.typbasetype, NULL::integer)
                ELSE 'USER-DEFINED'::text
            END
            ELSE
            CASE
                WHEN ((t.typelem <> (0)::oid) AND (t.typlen = (-1))) THEN 'ARRAY'::text
                WHEN (nt.nspname = 'pg_catalog'::name) THEN format_type(a.atttypid, NULL::integer)
                ELSE 'USER-DEFINED'::text
            END
        END)::information_schema.character_data AS data_type,
    (information_schema._pg_char_max_length(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS character_maximum_length,
    (information_schema._pg_char_octet_length(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS character_octet_length,
    (information_schema._pg_numeric_precision(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS numeric_precision,
    (information_schema._pg_numeric_precision_radix(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS numeric_precision_radix,
    (information_schema._pg_numeric_scale(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS numeric_scale,
    (information_schema._pg_datetime_precision(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.cardinal_number AS datetime_precision,
    (information_schema._pg_interval_type(information_schema._pg_truetypid(a.*, t.*), information_schema._pg_truetypmod(a.*, t.*)))::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (
        CASE
            WHEN (nco.nspname IS NOT NULL) THEN current_database()
            ELSE NULL::name
        END)::information_schema.sql_identifier AS collation_catalog,
    (nco.nspname)::information_schema.sql_identifier AS collation_schema,
    (co.collname)::information_schema.sql_identifier AS collation_name,
    (
        CASE
            WHEN (t.typtype = 'd'::"char") THEN current_database()
            ELSE NULL::name
        END)::information_schema.sql_identifier AS domain_catalog,
    (
        CASE
            WHEN (t.typtype = 'd'::"char") THEN nt.nspname
            ELSE NULL::name
        END)::information_schema.sql_identifier AS domain_schema,
    (
        CASE
            WHEN (t.typtype = 'd'::"char") THEN t.typname
            ELSE NULL::name
        END)::information_schema.sql_identifier AS domain_name,
    (current_database())::information_schema.sql_identifier AS udt_catalog,
    (COALESCE(nbt.nspname, nt.nspname))::information_schema.sql_identifier AS udt_schema,
    (COALESCE(bt.typname, t.typname))::information_schema.sql_identifier AS udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS scope_name,
    (NULL::integer)::information_schema.cardinal_number AS maximum_cardinality,
    (a.attnum)::information_schema.sql_identifier AS dtd_identifier,
    ('NO'::character varying)::information_schema.yes_or_no AS is_self_referencing,
    ('NO'::character varying)::information_schema.yes_or_no AS is_identity,
    (NULL::character varying)::information_schema.character_data AS identity_generation,
    (NULL::character varying)::information_schema.character_data AS identity_start,
    (NULL::character varying)::information_schema.character_data AS identity_increment,
    (NULL::character varying)::information_schema.character_data AS identity_maximum,
    (NULL::character varying)::information_schema.character_data AS identity_minimum,
    (NULL::character varying)::information_schema.yes_or_no AS identity_cycle,
    ('NEVER'::character varying)::information_schema.character_data AS is_generated,
    (NULL::character varying)::information_schema.character_data AS generation_expression,
    (
        CASE
            WHEN ((c.relkind = 'r'::"char") OR ((c.relkind = ANY (ARRAY['v'::"char", 'f'::"char"])) AND pg_column_is_updatable((c.oid)::regclass, a.attnum, false))) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_updatable
   FROM (((((pg_attribute a
     LEFT JOIN pg_attrdef ad ON (((a.attrelid = ad.adrelid) AND (a.attnum = ad.adnum))))
     JOIN (pg_class c
     JOIN pg_namespace nc ON ((c.relnamespace = nc.oid))) ON ((a.attrelid = c.oid)))
     JOIN (pg_type t
     JOIN pg_namespace nt ON ((t.typnamespace = nt.oid))) ON ((a.atttypid = t.oid)))
     LEFT JOIN (pg_type bt
     JOIN pg_namespace nbt ON ((bt.typnamespace = nbt.oid))) ON (((t.typtype = 'd'::"char") AND (t.typbasetype = bt.oid))))
     LEFT JOIN (pg_collation co
     JOIN pg_namespace nco ON ((co.collnamespace = nco.oid))) ON (((a.attcollation = co.oid) AND ((nco.nspname <> 'pg_catalog'::name) OR (co.collname <> 'default'::name)))))
  WHERE (((((NOT pg_is_other_temp_schema(nc.oid)) AND (a.attnum > 0)) AND (NOT a.attisdropped)) AND (c.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"]))) AND (pg_has_role(c.relowner, 'USAGE'::text) OR has_column_privilege(c.oid, a.attnum, 'SELECT, INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE columns OWNER TO portaladmin;

--
-- Name: config_info; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE config_info (
    name character varying(128) NOT NULL,
    value character varying(128),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE config_info OWNER TO portaladmin;

--
-- Name: constraint_column_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW constraint_column_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS table_catalog,
    (x.tblschema)::information_schema.sql_identifier AS table_schema,
    (x.tblname)::information_schema.sql_identifier AS table_name,
    (x.colname)::information_schema.sql_identifier AS column_name,
    (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (x.cstrschema)::information_schema.sql_identifier AS constraint_schema,
    (x.cstrname)::information_schema.sql_identifier AS constraint_name
   FROM ( SELECT DISTINCT nr.nspname,
            r.relname,
            r.relowner,
            a.attname,
            nc.nspname,
            c.conname
           FROM pg_namespace nr,
            pg_class r,
            pg_attribute a,
            pg_depend d,
            pg_namespace nc,
            pg_constraint c
          WHERE (((((((((((nr.oid = r.relnamespace) AND (r.oid = a.attrelid)) AND (d.refclassid = ('pg_class'::regclass)::oid)) AND (d.refobjid = r.oid)) AND (d.refobjsubid = a.attnum)) AND (d.classid = ('pg_constraint'::regclass)::oid)) AND (d.objid = c.oid)) AND (c.connamespace = nc.oid)) AND (c.contype = 'c'::"char")) AND (r.relkind = 'r'::"char")) AND (NOT a.attisdropped))
        UNION ALL
         SELECT nr.nspname,
            r.relname,
            r.relowner,
            a.attname,
            nc.nspname,
            c.conname
           FROM pg_namespace nr,
            pg_class r,
            pg_attribute a,
            pg_namespace nc,
            pg_constraint c
          WHERE (((((((nr.oid = r.relnamespace) AND (r.oid = a.attrelid)) AND (nc.oid = c.connamespace)) AND
                CASE
                    WHEN (c.contype = 'f'::"char") THEN ((r.oid = c.confrelid) AND (a.attnum = ANY (c.confkey)))
                    ELSE ((r.oid = c.conrelid) AND (a.attnum = ANY (c.conkey)))
                END) AND (NOT a.attisdropped)) AND (c.contype = ANY (ARRAY['p'::"char", 'u'::"char", 'f'::"char"]))) AND (r.relkind = 'r'::"char"))) x(tblschema, tblname, tblowner, colname, cstrschema, cstrname)
  WHERE pg_has_role(x.tblowner, 'USAGE'::text);


ALTER TABLE constraint_column_usage OWNER TO portaladmin;

--
-- Name: constraint_table_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW constraint_table_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS table_catalog,
    (nr.nspname)::information_schema.sql_identifier AS table_schema,
    (r.relname)::information_schema.sql_identifier AS table_name,
    (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (nc.nspname)::information_schema.sql_identifier AS constraint_schema,
    (c.conname)::information_schema.sql_identifier AS constraint_name
   FROM pg_constraint c,
    pg_namespace nc,
    pg_class r,
    pg_namespace nr
  WHERE (((((c.connamespace = nc.oid) AND (r.relnamespace = nr.oid)) AND (((c.contype = 'f'::"char") AND (c.confrelid = r.oid)) OR ((c.contype = ANY (ARRAY['p'::"char", 'u'::"char"])) AND (c.conrelid = r.oid)))) AND (r.relkind = 'r'::"char")) AND pg_has_role(r.relowner, 'USAGE'::text));


ALTER TABLE constraint_table_usage OWNER TO portaladmin;

--
-- Name: data_type_privileges; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW data_type_privileges AS
 SELECT (current_database())::information_schema.sql_identifier AS object_catalog,
    x.objschema AS object_schema,
    x.objname AS object_name,
    (x.objtype)::information_schema.character_data AS object_type,
    x.objdtdid AS dtd_identifier
   FROM ( SELECT attributes.udt_schema,
            attributes.udt_name,
            'USER-DEFINED TYPE'::text AS text,
            attributes.dtd_identifier
           FROM information_schema.attributes
        UNION ALL
         SELECT columns.table_schema,
            columns.table_name,
            'TABLE'::text AS text,
            columns.dtd_identifier
           FROM information_schema.columns
        UNION ALL
         SELECT domains.domain_schema,
            domains.domain_name,
            'DOMAIN'::text AS text,
            domains.dtd_identifier
           FROM information_schema.domains
        UNION ALL
         SELECT parameters.specific_schema,
            parameters.specific_name,
            'ROUTINE'::text AS text,
            parameters.dtd_identifier
           FROM information_schema.parameters
        UNION ALL
         SELECT routines.specific_schema,
            routines.specific_name,
            'ROUTINE'::text AS text,
            routines.dtd_identifier
           FROM information_schema.routines) x(objschema, objname, objtype, objdtdid);


ALTER TABLE data_type_privileges OWNER TO portaladmin;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE documents (
    no integer NOT NULL,
    title character varying(255) NOT NULL,
    user_id character varying(128) NOT NULL,
    classification character varying(36) NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    content text,
    file_name character varying(255),
    file_path character varying(512),
    file_size bigint,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE documents OWNER TO portaladmin;

--
-- Name: COLUMN documents.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.no IS '고유번호';


--
-- Name: COLUMN documents.title; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.title IS '제목';


--
-- Name: COLUMN documents.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.user_id IS '사용자_아이디';


--
-- Name: COLUMN documents.classification; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.classification IS '분류';


--
-- Name: COLUMN documents.use_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.use_yn IS '공개_여부';


--
-- Name: COLUMN documents.content; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.content IS '내용';


--
-- Name: COLUMN documents.file_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.file_name IS '첨부파일_이름';


--
-- Name: COLUMN documents.file_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.file_path IS '첨부파일_주소';


--
-- Name: COLUMN documents.file_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.file_size IS '첨부파일_크기';


--
-- Name: COLUMN documents.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.created IS '생성시간';


--
-- Name: COLUMN documents.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN documents.lastmodified IS '마지막_수정_시간';


--
-- Name: documents_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE documents_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE documents_no_seq OWNER TO portaladmin;

--
-- Name: documents_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE documents_no_seq OWNED BY documents.no;


--
-- Name: domain_constraints; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW domain_constraints AS
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (rs.nspname)::information_schema.sql_identifier AS constraint_schema,
    (con.conname)::information_schema.sql_identifier AS constraint_name,
    (current_database())::information_schema.sql_identifier AS domain_catalog,
    (n.nspname)::information_schema.sql_identifier AS domain_schema,
    (t.typname)::information_schema.sql_identifier AS domain_name,
    (
        CASE
            WHEN con.condeferrable THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_deferrable,
    (
        CASE
            WHEN con.condeferred THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS initially_deferred
   FROM pg_namespace rs,
    pg_namespace n,
    pg_constraint con,
    pg_type t
  WHERE ((((rs.oid = con.connamespace) AND (n.oid = t.typnamespace)) AND (t.oid = con.contypid)) AND (pg_has_role(t.typowner, 'USAGE'::text) OR has_type_privilege(t.oid, 'USAGE'::text)));


ALTER TABLE domain_constraints OWNER TO portaladmin;

--
-- Name: domain_udt_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW domain_udt_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS udt_catalog,
    (nbt.nspname)::information_schema.sql_identifier AS udt_schema,
    (bt.typname)::information_schema.sql_identifier AS udt_name,
    (current_database())::information_schema.sql_identifier AS domain_catalog,
    (nt.nspname)::information_schema.sql_identifier AS domain_schema,
    (t.typname)::information_schema.sql_identifier AS domain_name
   FROM pg_type t,
    pg_namespace nt,
    pg_type bt,
    pg_namespace nbt
  WHERE (((((t.typnamespace = nt.oid) AND (t.typbasetype = bt.oid)) AND (bt.typnamespace = nbt.oid)) AND (t.typtype = 'd'::"char")) AND pg_has_role(bt.typowner, 'USAGE'::text));


ALTER TABLE domain_udt_usage OWNER TO portaladmin;

--
-- Name: domains; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW domains AS
 SELECT (current_database())::information_schema.sql_identifier AS domain_catalog,
    (nt.nspname)::information_schema.sql_identifier AS domain_schema,
    (t.typname)::information_schema.sql_identifier AS domain_name,
    (
        CASE
            WHEN ((t.typelem <> (0)::oid) AND (t.typlen = (-1))) THEN 'ARRAY'::text
            WHEN (nbt.nspname = 'pg_catalog'::name) THEN format_type(t.typbasetype, NULL::integer)
            ELSE 'USER-DEFINED'::text
        END)::information_schema.character_data AS data_type,
    (information_schema._pg_char_max_length(t.typbasetype, t.typtypmod))::information_schema.cardinal_number AS character_maximum_length,
    (information_schema._pg_char_octet_length(t.typbasetype, t.typtypmod))::information_schema.cardinal_number AS character_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (
        CASE
            WHEN (nco.nspname IS NOT NULL) THEN current_database()
            ELSE NULL::name
        END)::information_schema.sql_identifier AS collation_catalog,
    (nco.nspname)::information_schema.sql_identifier AS collation_schema,
    (co.collname)::information_schema.sql_identifier AS collation_name,
    (information_schema._pg_numeric_precision(t.typbasetype, t.typtypmod))::information_schema.cardinal_number AS numeric_precision,
    (information_schema._pg_numeric_precision_radix(t.typbasetype, t.typtypmod))::information_schema.cardinal_number AS numeric_precision_radix,
    (information_schema._pg_numeric_scale(t.typbasetype, t.typtypmod))::information_schema.cardinal_number AS numeric_scale,
    (information_schema._pg_datetime_precision(t.typbasetype, t.typtypmod))::information_schema.cardinal_number AS datetime_precision,
    (information_schema._pg_interval_type(t.typbasetype, t.typtypmod))::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (t.typdefault)::information_schema.character_data AS domain_default,
    (current_database())::information_schema.sql_identifier AS udt_catalog,
    (nbt.nspname)::information_schema.sql_identifier AS udt_schema,
    (bt.typname)::information_schema.sql_identifier AS udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS scope_name,
    (NULL::integer)::information_schema.cardinal_number AS maximum_cardinality,
    (1)::information_schema.sql_identifier AS dtd_identifier
   FROM (((pg_type t
     JOIN pg_namespace nt ON ((t.typnamespace = nt.oid)))
     JOIN (pg_type bt
     JOIN pg_namespace nbt ON ((bt.typnamespace = nbt.oid))) ON (((t.typbasetype = bt.oid) AND (t.typtype = 'd'::"char"))))
     LEFT JOIN (pg_collation co
     JOIN pg_namespace nco ON ((co.collnamespace = nco.oid))) ON (((t.typcollation = co.oid) AND ((nco.nspname <> 'pg_catalog'::name) OR (co.collname <> 'default'::name)))))
  WHERE (pg_has_role(t.typowner, 'USAGE'::text) OR has_type_privilege(t.oid, 'USAGE'::text));


ALTER TABLE domains OWNER TO portaladmin;

--
-- Name: element_types; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW element_types AS
 SELECT (current_database())::information_schema.sql_identifier AS object_catalog,
    (n.nspname)::information_schema.sql_identifier AS object_schema,
    x.objname AS object_name,
    (x.objtype)::information_schema.character_data AS object_type,
    (x.objdtdid)::information_schema.sql_identifier AS collection_type_identifier,
    (
        CASE
            WHEN (nbt.nspname = 'pg_catalog'::name) THEN format_type(bt.oid, NULL::integer)
            ELSE 'USER-DEFINED'::text
        END)::information_schema.character_data AS data_type,
    (NULL::integer)::information_schema.cardinal_number AS character_maximum_length,
    (NULL::integer)::information_schema.cardinal_number AS character_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (
        CASE
            WHEN (nco.nspname IS NOT NULL) THEN current_database()
            ELSE NULL::name
        END)::information_schema.sql_identifier AS collation_catalog,
    (nco.nspname)::information_schema.sql_identifier AS collation_schema,
    (co.collname)::information_schema.sql_identifier AS collation_name,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision_radix,
    (NULL::integer)::information_schema.cardinal_number AS numeric_scale,
    (NULL::integer)::information_schema.cardinal_number AS datetime_precision,
    (NULL::character varying)::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (NULL::character varying)::information_schema.character_data AS domain_default,
    (current_database())::information_schema.sql_identifier AS udt_catalog,
    (nbt.nspname)::information_schema.sql_identifier AS udt_schema,
    (bt.typname)::information_schema.sql_identifier AS udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS scope_name,
    (NULL::integer)::information_schema.cardinal_number AS maximum_cardinality,
    (('a'::text || (x.objdtdid)::text))::information_schema.sql_identifier AS dtd_identifier
   FROM pg_namespace n,
    pg_type at,
    pg_namespace nbt,
    pg_type bt,
    (( SELECT c.relnamespace,
            (c.relname)::information_schema.sql_identifier AS relname,
                CASE
                    WHEN (c.relkind = 'c'::"char") THEN 'USER-DEFINED TYPE'::text
                    ELSE 'TABLE'::text
                END AS "case",
            a.attnum,
            a.atttypid,
            a.attcollation
           FROM pg_class c,
            pg_attribute a
          WHERE ((((c.oid = a.attrelid) AND (c.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char", 'c'::"char"]))) AND (a.attnum > 0)) AND (NOT a.attisdropped))
        UNION ALL
         SELECT t.typnamespace,
            (t.typname)::information_schema.sql_identifier AS typname,
            'DOMAIN'::text AS text,
            1,
            t.typbasetype,
            t.typcollation
           FROM pg_type t
          WHERE (t.typtype = 'd'::"char")
        UNION ALL
         SELECT ss.pronamespace,
            ((((ss.proname)::text || '_'::text) || (ss.oid)::text))::information_schema.sql_identifier AS sql_identifier,
            'ROUTINE'::text AS text,
            (ss.x).n AS n,
            (ss.x).x AS x,
            0
           FROM ( SELECT p.pronamespace,
                    p.proname,
                    p.oid,
                    information_schema._pg_expandarray(COALESCE(p.proallargtypes, (p.proargtypes)::oid[])) AS x
                   FROM pg_proc p) ss
        UNION ALL
         SELECT p.pronamespace,
            ((((p.proname)::text || '_'::text) || (p.oid)::text))::information_schema.sql_identifier AS sql_identifier,
            'ROUTINE'::text AS text,
            0,
            p.prorettype,
            0
           FROM pg_proc p) x(objschema, objname, objtype, objdtdid, objtypeid, objcollation)
     LEFT JOIN (pg_collation co
     JOIN pg_namespace nco ON ((co.collnamespace = nco.oid))) ON (((x.objcollation = co.oid) AND ((nco.nspname <> 'pg_catalog'::name) OR (co.collname <> 'default'::name)))))
  WHERE ((((((n.oid = x.objschema) AND (at.oid = x.objtypeid)) AND ((at.typelem <> (0)::oid) AND (at.typlen = (-1)))) AND (at.typelem = bt.oid)) AND (nbt.oid = bt.typnamespace)) AND ((n.nspname, (x.objname)::text, x.objtype, ((x.objdtdid)::information_schema.sql_identifier)::text) IN ( SELECT data_type_privileges.object_schema,
            data_type_privileges.object_name,
            data_type_privileges.object_type,
            data_type_privileges.dtd_identifier
           FROM information_schema.data_type_privileges)));


ALTER TABLE element_types OWNER TO portaladmin;

--
-- Name: enabled_roles; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW enabled_roles AS
 SELECT (a.rolname)::information_schema.sql_identifier AS role_name
   FROM pg_authid a
  WHERE pg_has_role(a.oid, 'USAGE'::text);


ALTER TABLE enabled_roles OWNER TO portaladmin;

--
-- Name: foreign_data_wrapper_options; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW foreign_data_wrapper_options AS
 SELECT w.foreign_data_wrapper_catalog,
    w.foreign_data_wrapper_name,
    ((pg_options_to_table(w.fdwoptions)).option_name)::information_schema.sql_identifier AS option_name,
    ((pg_options_to_table(w.fdwoptions)).option_value)::information_schema.character_data AS option_value
   FROM information_schema._pg_foreign_data_wrappers w;


ALTER TABLE foreign_data_wrapper_options OWNER TO portaladmin;

--
-- Name: foreign_data_wrappers; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW foreign_data_wrappers AS
 SELECT w.foreign_data_wrapper_catalog,
    w.foreign_data_wrapper_name,
    w.authorization_identifier,
    (NULL::character varying)::information_schema.character_data AS library_name,
    w.foreign_data_wrapper_language
   FROM information_schema._pg_foreign_data_wrappers w;


ALTER TABLE foreign_data_wrappers OWNER TO portaladmin;

--
-- Name: foreign_server_options; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW foreign_server_options AS
 SELECT s.foreign_server_catalog,
    s.foreign_server_name,
    ((pg_options_to_table(s.srvoptions)).option_name)::information_schema.sql_identifier AS option_name,
    ((pg_options_to_table(s.srvoptions)).option_value)::information_schema.character_data AS option_value
   FROM information_schema._pg_foreign_servers s;


ALTER TABLE foreign_server_options OWNER TO portaladmin;

--
-- Name: foreign_servers; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW foreign_servers AS
 SELECT _pg_foreign_servers.foreign_server_catalog,
    _pg_foreign_servers.foreign_server_name,
    _pg_foreign_servers.foreign_data_wrapper_catalog,
    _pg_foreign_servers.foreign_data_wrapper_name,
    _pg_foreign_servers.foreign_server_type,
    _pg_foreign_servers.foreign_server_version,
    _pg_foreign_servers.authorization_identifier
   FROM information_schema._pg_foreign_servers;


ALTER TABLE foreign_servers OWNER TO portaladmin;

--
-- Name: foreign_table_options; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW foreign_table_options AS
 SELECT t.foreign_table_catalog,
    t.foreign_table_schema,
    t.foreign_table_name,
    ((pg_options_to_table(t.ftoptions)).option_name)::information_schema.sql_identifier AS option_name,
    ((pg_options_to_table(t.ftoptions)).option_value)::information_schema.character_data AS option_value
   FROM information_schema._pg_foreign_tables t;


ALTER TABLE foreign_table_options OWNER TO portaladmin;

--
-- Name: foreign_tables; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW foreign_tables AS
 SELECT _pg_foreign_tables.foreign_table_catalog,
    _pg_foreign_tables.foreign_table_schema,
    _pg_foreign_tables.foreign_table_name,
    _pg_foreign_tables.foreign_server_catalog,
    _pg_foreign_tables.foreign_server_name
   FROM information_schema._pg_foreign_tables;


ALTER TABLE foreign_tables OWNER TO portaladmin;

--
-- Name: information_schema_catalog_name; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW information_schema_catalog_name AS
 SELECT (current_database())::information_schema.sql_identifier AS catalog_name;


ALTER TABLE information_schema_catalog_name OWNER TO portaladmin;

--
-- Name: invite_org_space; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE invite_org_space (
    id integer NOT NULL,
    token character varying(128) NOT NULL,
    gubun character varying(35) NOT NULL,
    invite_id numeric NOT NULL,
    role_name character varying(35) NOT NULL,
    invite_user_id character varying(128) NOT NULL,
    user_id character varying(128) NOT NULL,
    create_time timestamp without time zone DEFAULT now(),
    access_cnt numeric DEFAULT 0 NOT NULL,
    invite_name character varying NOT NULL,
    setyn character(1) DEFAULT 'N'::bpchar NOT NULL
);
ALTER TABLE ONLY invite_org_space ALTER COLUMN setyn SET STORAGE PLAIN;


ALTER TABLE invite_org_space OWNER TO portaladmin;

--
-- Name: invite_org_space_id_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE invite_org_space_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE invite_org_space_id_seq OWNER TO portaladmin;

--
-- Name: invite_org_space_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE invite_org_space_id_seq OWNED BY invite_org_space.id;


--
-- Name: key_column_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW key_column_usage AS
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (ss.nc_nspname)::information_schema.sql_identifier AS constraint_schema,
    (ss.conname)::information_schema.sql_identifier AS constraint_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (ss.nr_nspname)::information_schema.sql_identifier AS table_schema,
    (ss.relname)::information_schema.sql_identifier AS table_name,
    (a.attname)::information_schema.sql_identifier AS column_name,
    ((ss.x).n)::information_schema.cardinal_number AS ordinal_position,
    (
        CASE
            WHEN (ss.contype = 'f'::"char") THEN information_schema._pg_index_position(ss.conindid, ss.confkey[(ss.x).n])
            ELSE NULL::integer
        END)::information_schema.cardinal_number AS position_in_unique_constraint
   FROM pg_attribute a,
    ( SELECT r.oid AS roid,
            r.relname,
            r.relowner,
            nc.nspname AS nc_nspname,
            nr.nspname AS nr_nspname,
            c.oid AS coid,
            c.conname,
            c.contype,
            c.conindid,
            c.confkey,
            c.confrelid,
            information_schema._pg_expandarray(c.conkey) AS x
           FROM pg_namespace nr,
            pg_class r,
            pg_namespace nc,
            pg_constraint c
          WHERE ((((((nr.oid = r.relnamespace) AND (r.oid = c.conrelid)) AND (nc.oid = c.connamespace)) AND (c.contype = ANY (ARRAY['p'::"char", 'u'::"char", 'f'::"char"]))) AND (r.relkind = 'r'::"char")) AND (NOT pg_is_other_temp_schema(nr.oid)))) ss
  WHERE ((((ss.roid = a.attrelid) AND (a.attnum = (ss.x).x)) AND (NOT a.attisdropped)) AND (pg_has_role(ss.relowner, 'USAGE'::text) OR has_column_privilege(ss.roid, a.attnum, 'SELECT, INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE key_column_usage OWNER TO portaladmin;

--
-- Name: menu; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE menu (
    no integer NOT NULL,
    parent_no integer NOT NULL,
    sort_no integer NOT NULL,
    menu_name character varying(255) NOT NULL,
    menu_path character varying(512) NOT NULL,
    image_path character varying(512),
    open_window_yn character varying(1) DEFAULT 'N'::character varying NOT NULL,
    login_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    description text,
    user_id character varying(128) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE menu OWNER TO portaladmin;

--
-- Name: COLUMN menu.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.no IS '고유번호';


--
-- Name: COLUMN menu.parent_no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.parent_no IS '상위_고유번호';


--
-- Name: COLUMN menu.sort_no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.sort_no IS '정렬_순번';


--
-- Name: COLUMN menu.menu_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.menu_name IS '메뉴_이름';


--
-- Name: COLUMN menu.menu_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.menu_path IS '메뉴_주소';


--
-- Name: COLUMN menu.image_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.image_path IS '이미지_경로';


--
-- Name: COLUMN menu.open_window_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.open_window_yn IS '새창_여부';


--
-- Name: COLUMN menu.login_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.login_yn IS '로그인_여부';


--
-- Name: COLUMN menu.use_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.use_yn IS '사용_여부';


--
-- Name: COLUMN menu.description; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.description IS '설명';


--
-- Name: COLUMN menu.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.user_id IS '사용자_아이디';


--
-- Name: COLUMN menu.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.created IS '생성시간';


--
-- Name: COLUMN menu.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN menu.lastmodified IS '마지막_수정시간';


--
-- Name: menu_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE menu_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE menu_no_seq OWNER TO portaladmin;

--
-- Name: menu_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE menu_no_seq OWNED BY menu.no;


--
-- Name: notice; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE notice (
    no integer NOT NULL,
    title character varying(255) NOT NULL,
    important character varying(5) NOT NULL,
    classification character varying(36) NOT NULL,
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    content text,
    file_name character varying(255),
    file_path character varying(512),
    file_size bigint,
    start_date character varying(20) NOT NULL,
    end_date character varying(20) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE notice OWNER TO portaladmin;

--
-- Name: COLUMN notice.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.no IS '고유번호';


--
-- Name: COLUMN notice.title; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.title IS '제목';


--
-- Name: COLUMN notice.important; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.important IS '중요_공지';


--
-- Name: COLUMN notice.classification; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.classification IS '분류';


--
-- Name: COLUMN notice.use_yn; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.use_yn IS '공개_여부';


--
-- Name: COLUMN notice.content; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.content IS '내용';


--
-- Name: COLUMN notice.file_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.file_name IS '첨부파일_이름';


--
-- Name: COLUMN notice.file_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.file_path IS '첨부파일_주소';


--
-- Name: COLUMN notice.file_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.file_size IS '첨부파일_크기';


--
-- Name: COLUMN notice.start_date; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.start_date IS '게시일_시작';


--
-- Name: COLUMN notice.end_date; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.end_date IS '게시일_종료';


--
-- Name: COLUMN notice.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.created IS '생성시간';


--
-- Name: COLUMN notice.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN notice.lastmodified IS '마지막_수정_시간';


--
-- Name: notice_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE notice_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE notice_no_seq OWNER TO portaladmin;

--
-- Name: notice_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE notice_no_seq OWNED BY notice.no;


--
-- Name: parameters; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW parameters AS
 SELECT (current_database())::information_schema.sql_identifier AS specific_catalog,
    (ss.n_nspname)::information_schema.sql_identifier AS specific_schema,
    ((((ss.proname)::text || '_'::text) || (ss.p_oid)::text))::information_schema.sql_identifier AS specific_name,
    ((ss.x).n)::information_schema.cardinal_number AS ordinal_position,
    (
        CASE
            WHEN (ss.proargmodes IS NULL) THEN 'IN'::text
            WHEN (ss.proargmodes[(ss.x).n] = 'i'::"char") THEN 'IN'::text
            WHEN (ss.proargmodes[(ss.x).n] = 'o'::"char") THEN 'OUT'::text
            WHEN (ss.proargmodes[(ss.x).n] = 'b'::"char") THEN 'INOUT'::text
            WHEN (ss.proargmodes[(ss.x).n] = 'v'::"char") THEN 'IN'::text
            WHEN (ss.proargmodes[(ss.x).n] = 't'::"char") THEN 'OUT'::text
            ELSE NULL::text
        END)::information_schema.character_data AS parameter_mode,
    ('NO'::character varying)::information_schema.yes_or_no AS is_result,
    ('NO'::character varying)::information_schema.yes_or_no AS as_locator,
    (NULLIF(ss.proargnames[(ss.x).n], ''::text))::information_schema.sql_identifier AS parameter_name,
    (
        CASE
            WHEN ((t.typelem <> (0)::oid) AND (t.typlen = (-1))) THEN 'ARRAY'::text
            WHEN (nt.nspname = 'pg_catalog'::name) THEN format_type(t.oid, NULL::integer)
            ELSE 'USER-DEFINED'::text
        END)::information_schema.character_data AS data_type,
    (NULL::integer)::information_schema.cardinal_number AS character_maximum_length,
    (NULL::integer)::information_schema.cardinal_number AS character_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (NULL::character varying)::information_schema.sql_identifier AS collation_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS collation_schema,
    (NULL::character varying)::information_schema.sql_identifier AS collation_name,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision_radix,
    (NULL::integer)::information_schema.cardinal_number AS numeric_scale,
    (NULL::integer)::information_schema.cardinal_number AS datetime_precision,
    (NULL::character varying)::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (current_database())::information_schema.sql_identifier AS udt_catalog,
    (nt.nspname)::information_schema.sql_identifier AS udt_schema,
    (t.typname)::information_schema.sql_identifier AS udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS scope_name,
    (NULL::integer)::information_schema.cardinal_number AS maximum_cardinality,
    ((ss.x).n)::information_schema.sql_identifier AS dtd_identifier,
    (
        CASE
            WHEN pg_has_role(ss.proowner, 'USAGE'::text) THEN pg_get_function_arg_default(ss.p_oid, (ss.x).n)
            ELSE NULL::text
        END)::information_schema.character_data AS parameter_default
   FROM pg_type t,
    pg_namespace nt,
    ( SELECT n.nspname AS n_nspname,
            p.proname,
            p.oid AS p_oid,
            p.proowner,
            p.proargnames,
            p.proargmodes,
            information_schema._pg_expandarray(COALESCE(p.proallargtypes, (p.proargtypes)::oid[])) AS x
           FROM pg_namespace n,
            pg_proc p
          WHERE ((n.oid = p.pronamespace) AND (pg_has_role(p.proowner, 'USAGE'::text) OR has_function_privilege(p.oid, 'EXECUTE'::text)))) ss
  WHERE ((t.oid = (ss.x).x) AND (t.typnamespace = nt.oid));


ALTER TABLE parameters OWNER TO portaladmin;

--
-- Name: pg_available_extensions; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW pg_available_extensions AS
 SELECT e.name,
    e.default_version,
    x.extversion AS installed_version,
    e.comment
   FROM (pg_available_extensions() e(name, default_version, comment)
     LEFT JOIN pg_extension x ON ((e.name = x.extname)));


ALTER TABLE pg_available_extensions OWNER TO portaladmin;

--
-- Name: question; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE question (
    no integer NOT NULL,
    title character varying(255) NOT NULL,
    classification character varying(36) NOT NULL,
    user_id character varying(128) NOT NULL,
    content text NOT NULL,
    cell_phone character varying(11),
    status character varying(8) NOT NULL,
    file_name character varying(255),
    file_path character varying(512),
    file_size bigint,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE question OWNER TO portaladmin;

--
-- Name: COLUMN question.no; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.no IS '고유번호';


--
-- Name: COLUMN question.title; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.title IS '제목';


--
-- Name: COLUMN question.classification; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.classification IS '분류';


--
-- Name: COLUMN question.user_id; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.user_id IS '사용자_아이디';


--
-- Name: COLUMN question.content; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.content IS '내용';


--
-- Name: COLUMN question.cell_phone; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.cell_phone IS '휴대폰';


--
-- Name: COLUMN question.status; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.status IS '진행상태';


--
-- Name: COLUMN question.file_name; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.file_name IS '첨부파일_이름';


--
-- Name: COLUMN question.file_path; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.file_path IS '첨부파일_주소';


--
-- Name: COLUMN question.file_size; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.file_size IS '첨부파일_크기';


--
-- Name: COLUMN question.created; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.created IS '생성시간';


--
-- Name: COLUMN question.lastmodified; Type: COMMENT; Schema: public; Owner: portaladmin
--

COMMENT ON COLUMN question.lastmodified IS '마지막_수정_시간';


--
-- Name: question_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE question_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE question_no_seq OWNER TO portaladmin;

--
-- Name: question_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE question_no_seq OWNED BY question.no;


--
-- Name: referential_constraints; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW referential_constraints AS
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (ncon.nspname)::information_schema.sql_identifier AS constraint_schema,
    (con.conname)::information_schema.sql_identifier AS constraint_name,
    (
        CASE
            WHEN (npkc.nspname IS NULL) THEN NULL::name
            ELSE current_database()
        END)::information_schema.sql_identifier AS unique_constraint_catalog,
    (npkc.nspname)::information_schema.sql_identifier AS unique_constraint_schema,
    (pkc.conname)::information_schema.sql_identifier AS unique_constraint_name,
    (
        CASE con.confmatchtype
            WHEN 'f'::"char" THEN 'FULL'::text
            WHEN 'p'::"char" THEN 'PARTIAL'::text
            WHEN 's'::"char" THEN 'NONE'::text
            ELSE NULL::text
        END)::information_schema.character_data AS match_option,
    (
        CASE con.confupdtype
            WHEN 'c'::"char" THEN 'CASCADE'::text
            WHEN 'n'::"char" THEN 'SET NULL'::text
            WHEN 'd'::"char" THEN 'SET DEFAULT'::text
            WHEN 'r'::"char" THEN 'RESTRICT'::text
            WHEN 'a'::"char" THEN 'NO ACTION'::text
            ELSE NULL::text
        END)::information_schema.character_data AS update_rule,
    (
        CASE con.confdeltype
            WHEN 'c'::"char" THEN 'CASCADE'::text
            WHEN 'n'::"char" THEN 'SET NULL'::text
            WHEN 'd'::"char" THEN 'SET DEFAULT'::text
            WHEN 'r'::"char" THEN 'RESTRICT'::text
            WHEN 'a'::"char" THEN 'NO ACTION'::text
            ELSE NULL::text
        END)::information_schema.character_data AS delete_rule
   FROM ((((((pg_namespace ncon
     JOIN pg_constraint con ON ((ncon.oid = con.connamespace)))
     JOIN pg_class c ON (((con.conrelid = c.oid) AND (con.contype = 'f'::"char"))))
     LEFT JOIN pg_depend d1 ON (((((d1.objid = con.oid) AND (d1.classid = ('pg_constraint'::regclass)::oid)) AND (d1.refclassid = ('pg_class'::regclass)::oid)) AND (d1.refobjsubid = 0))))
     LEFT JOIN pg_depend d2 ON ((((((d2.refclassid = ('pg_constraint'::regclass)::oid) AND (d2.classid = ('pg_class'::regclass)::oid)) AND (d2.objid = d1.refobjid)) AND (d2.objsubid = 0)) AND (d2.deptype = 'i'::"char"))))
     LEFT JOIN pg_constraint pkc ON ((((pkc.oid = d2.refobjid) AND (pkc.contype = ANY (ARRAY['p'::"char", 'u'::"char"]))) AND (pkc.conrelid = con.confrelid))))
     LEFT JOIN pg_namespace npkc ON ((pkc.connamespace = npkc.oid)))
  WHERE ((pg_has_role(c.relowner, 'USAGE'::text) OR has_table_privilege(c.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)) OR has_any_column_privilege(c.oid, 'INSERT, UPDATE, REFERENCES'::text));


ALTER TABLE referential_constraints OWNER TO portaladmin;

--
-- Name: role_column_grants; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW role_column_grants AS
 SELECT column_privileges.grantor,
    column_privileges.grantee,
    column_privileges.table_catalog,
    column_privileges.table_schema,
    column_privileges.table_name,
    column_privileges.column_name,
    column_privileges.privilege_type,
    column_privileges.is_grantable
   FROM information_schema.column_privileges
  WHERE (((column_privileges.grantor)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)) OR ((column_privileges.grantee)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)));


ALTER TABLE role_column_grants OWNER TO portaladmin;

--
-- Name: role_routine_grants; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW role_routine_grants AS
 SELECT routine_privileges.grantor,
    routine_privileges.grantee,
    routine_privileges.specific_catalog,
    routine_privileges.specific_schema,
    routine_privileges.specific_name,
    routine_privileges.routine_catalog,
    routine_privileges.routine_schema,
    routine_privileges.routine_name,
    routine_privileges.privilege_type,
    routine_privileges.is_grantable
   FROM information_schema.routine_privileges
  WHERE (((routine_privileges.grantor)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)) OR ((routine_privileges.grantee)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)));


ALTER TABLE role_routine_grants OWNER TO portaladmin;

--
-- Name: role_table_grants; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW role_table_grants AS
 SELECT table_privileges.grantor,
    table_privileges.grantee,
    table_privileges.table_catalog,
    table_privileges.table_schema,
    table_privileges.table_name,
    table_privileges.privilege_type,
    table_privileges.is_grantable,
    table_privileges.with_hierarchy
   FROM information_schema.table_privileges
  WHERE (((table_privileges.grantor)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)) OR ((table_privileges.grantee)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)));


ALTER TABLE role_table_grants OWNER TO portaladmin;

--
-- Name: role_udt_grants; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW role_udt_grants AS
 SELECT udt_privileges.grantor,
    udt_privileges.grantee,
    udt_privileges.udt_catalog,
    udt_privileges.udt_schema,
    udt_privileges.udt_name,
    udt_privileges.privilege_type,
    udt_privileges.is_grantable
   FROM information_schema.udt_privileges
  WHERE (((udt_privileges.grantor)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)) OR ((udt_privileges.grantee)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)));


ALTER TABLE role_udt_grants OWNER TO portaladmin;

--
-- Name: role_usage_grants; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW role_usage_grants AS
 SELECT usage_privileges.grantor,
    usage_privileges.grantee,
    usage_privileges.object_catalog,
    usage_privileges.object_schema,
    usage_privileges.object_name,
    usage_privileges.object_type,
    usage_privileges.privilege_type,
    usage_privileges.is_grantable
   FROM information_schema.usage_privileges
  WHERE (((usage_privileges.grantor)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)) OR ((usage_privileges.grantee)::text IN ( SELECT enabled_roles.role_name
           FROM information_schema.enabled_roles)));


ALTER TABLE role_usage_grants OWNER TO portaladmin;

--
-- Name: routine_privileges; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW routine_privileges AS
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS specific_catalog,
    (n.nspname)::information_schema.sql_identifier AS specific_schema,
    ((((p.proname)::text || '_'::text) || (p.oid)::text))::information_schema.sql_identifier AS specific_name,
    (current_database())::information_schema.sql_identifier AS routine_catalog,
    (n.nspname)::information_schema.sql_identifier AS routine_schema,
    (p.proname)::information_schema.sql_identifier AS routine_name,
    ('EXECUTE'::character varying)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, p.proowner, 'USAGE'::text) OR p.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pg_proc.oid,
            pg_proc.proname,
            pg_proc.proowner,
            pg_proc.pronamespace,
            (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).is_grantable AS is_grantable
           FROM pg_proc) p(oid, proname, proowner, pronamespace, grantor, grantee, prtype, grantable),
    pg_namespace n,
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE (((((p.pronamespace = n.oid) AND (grantee.oid = p.grantee)) AND (u_grantor.oid = p.grantor)) AND (p.prtype = 'EXECUTE'::text)) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)));


ALTER TABLE routine_privileges OWNER TO portaladmin;

--
-- Name: routines; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW routines AS
 SELECT (current_database())::information_schema.sql_identifier AS specific_catalog,
    (n.nspname)::information_schema.sql_identifier AS specific_schema,
    ((((p.proname)::text || '_'::text) || (p.oid)::text))::information_schema.sql_identifier AS specific_name,
    (current_database())::information_schema.sql_identifier AS routine_catalog,
    (n.nspname)::information_schema.sql_identifier AS routine_schema,
    (p.proname)::information_schema.sql_identifier AS routine_name,
    ('FUNCTION'::character varying)::information_schema.character_data AS routine_type,
    (NULL::character varying)::information_schema.sql_identifier AS module_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS module_schema,
    (NULL::character varying)::information_schema.sql_identifier AS module_name,
    (NULL::character varying)::information_schema.sql_identifier AS udt_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS udt_schema,
    (NULL::character varying)::information_schema.sql_identifier AS udt_name,
    (
        CASE
            WHEN ((t.typelem <> (0)::oid) AND (t.typlen = (-1))) THEN 'ARRAY'::text
            WHEN (nt.nspname = 'pg_catalog'::name) THEN format_type(t.oid, NULL::integer)
            ELSE 'USER-DEFINED'::text
        END)::information_schema.character_data AS data_type,
    (NULL::integer)::information_schema.cardinal_number AS character_maximum_length,
    (NULL::integer)::information_schema.cardinal_number AS character_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (NULL::character varying)::information_schema.sql_identifier AS collation_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS collation_schema,
    (NULL::character varying)::information_schema.sql_identifier AS collation_name,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision_radix,
    (NULL::integer)::information_schema.cardinal_number AS numeric_scale,
    (NULL::integer)::information_schema.cardinal_number AS datetime_precision,
    (NULL::character varying)::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (current_database())::information_schema.sql_identifier AS type_udt_catalog,
    (nt.nspname)::information_schema.sql_identifier AS type_udt_schema,
    (t.typname)::information_schema.sql_identifier AS type_udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS scope_name,
    (NULL::integer)::information_schema.cardinal_number AS maximum_cardinality,
    (0)::information_schema.sql_identifier AS dtd_identifier,
    (
        CASE
            WHEN (l.lanname = 'sql'::name) THEN 'SQL'::text
            ELSE 'EXTERNAL'::text
        END)::information_schema.character_data AS routine_body,
    (
        CASE
            WHEN pg_has_role(p.proowner, 'USAGE'::text) THEN p.prosrc
            ELSE NULL::text
        END)::information_schema.character_data AS routine_definition,
    (
        CASE
            WHEN (l.lanname = 'c'::name) THEN p.prosrc
            ELSE NULL::text
        END)::information_schema.character_data AS external_name,
    (upper((l.lanname)::text))::information_schema.character_data AS external_language,
    ('GENERAL'::character varying)::information_schema.character_data AS parameter_style,
    (
        CASE
            WHEN (p.provolatile = 'i'::"char") THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_deterministic,
    ('MODIFIES'::character varying)::information_schema.character_data AS sql_data_access,
    (
        CASE
            WHEN p.proisstrict THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_null_call,
    (NULL::character varying)::information_schema.character_data AS sql_path,
    ('YES'::character varying)::information_schema.yes_or_no AS schema_level_routine,
    (0)::information_schema.cardinal_number AS max_dynamic_result_sets,
    (NULL::character varying)::information_schema.yes_or_no AS is_user_defined_cast,
    (NULL::character varying)::information_schema.yes_or_no AS is_implicitly_invocable,
    (
        CASE
            WHEN p.prosecdef THEN 'DEFINER'::text
            ELSE 'INVOKER'::text
        END)::information_schema.character_data AS security_type,
    (NULL::character varying)::information_schema.sql_identifier AS to_sql_specific_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS to_sql_specific_schema,
    (NULL::character varying)::information_schema.sql_identifier AS to_sql_specific_name,
    ('NO'::character varying)::information_schema.yes_or_no AS as_locator,
    (NULL::timestamp with time zone)::information_schema.time_stamp AS created,
    (NULL::timestamp with time zone)::information_schema.time_stamp AS last_altered,
    (NULL::character varying)::information_schema.yes_or_no AS new_savepoint_level,
    ('NO'::character varying)::information_schema.yes_or_no AS is_udt_dependent,
    (NULL::character varying)::information_schema.character_data AS result_cast_from_data_type,
    (NULL::character varying)::information_schema.yes_or_no AS result_cast_as_locator,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_char_max_length,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_char_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_char_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_char_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_character_set_name,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_collation_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_collation_schema,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_collation_name,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_numeric_precision,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_numeric_precision_radix,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_numeric_scale,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_datetime_precision,
    (NULL::character varying)::information_schema.character_data AS result_cast_interval_type,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_interval_precision,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_type_udt_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_type_udt_schema,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_type_udt_name,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_scope_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_scope_schema,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_scope_name,
    (NULL::integer)::information_schema.cardinal_number AS result_cast_maximum_cardinality,
    (NULL::character varying)::information_schema.sql_identifier AS result_cast_dtd_identifier
   FROM pg_namespace n,
    pg_proc p,
    pg_language l,
    pg_type t,
    pg_namespace nt
  WHERE (((((n.oid = p.pronamespace) AND (p.prolang = l.oid)) AND (p.prorettype = t.oid)) AND (t.typnamespace = nt.oid)) AND (pg_has_role(p.proowner, 'USAGE'::text) OR has_function_privilege(p.oid, 'EXECUTE'::text)));


ALTER TABLE routines OWNER TO portaladmin;

--
-- Name: schemata; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW schemata AS
 SELECT (current_database())::information_schema.sql_identifier AS catalog_name,
    (n.nspname)::information_schema.sql_identifier AS schema_name,
    (u.rolname)::information_schema.sql_identifier AS schema_owner,
    (NULL::character varying)::information_schema.sql_identifier AS default_character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS default_character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS default_character_set_name,
    (NULL::character varying)::information_schema.character_data AS sql_path
   FROM pg_namespace n,
    pg_authid u
  WHERE ((n.nspowner = u.oid) AND (pg_has_role(n.nspowner, 'USAGE'::text) OR has_schema_privilege(n.oid, 'CREATE, USAGE'::text)));


ALTER TABLE schemata OWNER TO portaladmin;

--
-- Name: sequences; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW sequences AS
 SELECT (current_database())::information_schema.sql_identifier AS sequence_catalog,
    (nc.nspname)::information_schema.sql_identifier AS sequence_schema,
    (c.relname)::information_schema.sql_identifier AS sequence_name,
    ('bigint'::character varying)::information_schema.character_data AS data_type,
    (64)::information_schema.cardinal_number AS numeric_precision,
    (2)::information_schema.cardinal_number AS numeric_precision_radix,
    (0)::information_schema.cardinal_number AS numeric_scale,
    (p.start_value)::information_schema.character_data AS start_value,
    (p.minimum_value)::information_schema.character_data AS minimum_value,
    (p.maximum_value)::information_schema.character_data AS maximum_value,
    (p.increment)::information_schema.character_data AS increment,
    (
        CASE
            WHEN p.cycle_option THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS cycle_option
   FROM pg_namespace nc,
    pg_class c,
    LATERAL pg_sequence_parameters(c.oid) p(start_value, minimum_value, maximum_value, increment, cycle_option)
  WHERE ((((c.relnamespace = nc.oid) AND (c.relkind = 'S'::"char")) AND (NOT pg_is_other_temp_schema(nc.oid))) AND (pg_has_role(c.relowner, 'USAGE'::text) OR has_sequence_privilege(c.oid, 'SELECT, UPDATE, USAGE'::text)));


ALTER TABLE sequences OWNER TO portaladmin;

--
-- Name: servicepack_category; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE servicepack_category (
    no integer NOT NULL,
    name character varying(255) NOT NULL,
    classification character varying(36) NOT NULL,
    summary character varying(255) NOT NULL,
    description text,
    service_name character varying(255) NOT NULL,
    thumb_img_name character varying(255),
    thumb_img_path character varying(512),
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    user_id character varying(128) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE servicepack_category OWNER TO portaladmin;

--
-- Name: servicepack_category_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE servicepack_category_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE servicepack_category_no_seq OWNER TO portaladmin;

--
-- Name: servicepack_category_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE servicepack_category_no_seq OWNED BY servicepack_category.no;


--
-- Name: starter_buildpack_relation; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE starter_buildpack_relation (
    no integer NOT NULL,
    starter_category_no integer NOT NULL,
    buildpack_category_no integer NOT NULL
);


ALTER TABLE starter_buildpack_relation OWNER TO portaladmin;

--
-- Name: starter_buildpack_relation_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE starter_buildpack_relation_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE starter_buildpack_relation_no_seq OWNER TO portaladmin;

--
-- Name: starter_buildpack_relation_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE starter_buildpack_relation_no_seq OWNED BY starter_buildpack_relation.no;


--
-- Name: starter_category; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE starter_category (
    no integer NOT NULL,
    name character varying(255) NOT NULL,
    classification character varying(36) NOT NULL,
    summary character varying(255) NOT NULL,
    description text,
    thumb_img_name character varying(255),
    thumb_img_path character varying(512),
    use_yn character varying(1) DEFAULT 'Y'::character varying NOT NULL,
    user_id character varying(128) NOT NULL,
    created timestamp without time zone DEFAULT now() NOT NULL,
    lastmodified timestamp without time zone
);


ALTER TABLE starter_category OWNER TO portaladmin;

--
-- Name: starter_category_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE starter_category_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE starter_category_no_seq OWNER TO portaladmin;

--
-- Name: starter_category_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE starter_category_no_seq OWNED BY starter_category.no;


--
-- Name: starter_servicepack_relation; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE starter_servicepack_relation (
    no integer NOT NULL,
    starter_category_no integer NOT NULL,
    servicepack_category_no integer NOT NULL
);


ALTER TABLE starter_servicepack_relation OWNER TO portaladmin;

--
-- Name: starter_servicepack_relation_no_seq; Type: SEQUENCE; Schema: public; Owner: portaladmin
--

CREATE SEQUENCE starter_servicepack_relation_no_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE starter_servicepack_relation_no_seq OWNER TO portaladmin;

--
-- Name: starter_servicepack_relation_no_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: portaladmin
--

ALTER SEQUENCE starter_servicepack_relation_no_seq OWNED BY starter_servicepack_relation.no;


--
-- Name: table_constraints; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW table_constraints AS
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (nc.nspname)::information_schema.sql_identifier AS constraint_schema,
    (c.conname)::information_schema.sql_identifier AS constraint_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nr.nspname)::information_schema.sql_identifier AS table_schema,
    (r.relname)::information_schema.sql_identifier AS table_name,
    (
        CASE c.contype
            WHEN 'c'::"char" THEN 'CHECK'::text
            WHEN 'f'::"char" THEN 'FOREIGN KEY'::text
            WHEN 'p'::"char" THEN 'PRIMARY KEY'::text
            WHEN 'u'::"char" THEN 'UNIQUE'::text
            ELSE NULL::text
        END)::information_schema.character_data AS constraint_type,
    (
        CASE
            WHEN c.condeferrable THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_deferrable,
    (
        CASE
            WHEN c.condeferred THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS initially_deferred
   FROM pg_namespace nc,
    pg_namespace nr,
    pg_constraint c,
    pg_class r
  WHERE (((((((nc.oid = c.connamespace) AND (nr.oid = r.relnamespace)) AND (c.conrelid = r.oid)) AND (c.contype <> ALL (ARRAY['t'::"char", 'x'::"char"]))) AND (r.relkind = 'r'::"char")) AND (NOT pg_is_other_temp_schema(nr.oid))) AND ((pg_has_role(r.relowner, 'USAGE'::text) OR has_table_privilege(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)) OR has_any_column_privilege(r.oid, 'INSERT, UPDATE, REFERENCES'::text)))
UNION ALL
 SELECT (current_database())::information_schema.sql_identifier AS constraint_catalog,
    (nr.nspname)::information_schema.sql_identifier AS constraint_schema,
    (((((((nr.oid)::text || '_'::text) || (r.oid)::text) || '_'::text) || (a.attnum)::text) || '_not_null'::text))::information_schema.sql_identifier AS constraint_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nr.nspname)::information_schema.sql_identifier AS table_schema,
    (r.relname)::information_schema.sql_identifier AS table_name,
    ('CHECK'::character varying)::information_schema.character_data AS constraint_type,
    ('NO'::character varying)::information_schema.yes_or_no AS is_deferrable,
    ('NO'::character varying)::information_schema.yes_or_no AS initially_deferred
   FROM pg_namespace nr,
    pg_class r,
    pg_attribute a
  WHERE ((((((((nr.oid = r.relnamespace) AND (r.oid = a.attrelid)) AND a.attnotnull) AND (a.attnum > 0)) AND (NOT a.attisdropped)) AND (r.relkind = 'r'::"char")) AND (NOT pg_is_other_temp_schema(nr.oid))) AND ((pg_has_role(r.relowner, 'USAGE'::text) OR has_table_privilege(r.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)) OR has_any_column_privilege(r.oid, 'INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE table_constraints OWNER TO portaladmin;

--
-- Name: table_privileges; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW table_privileges AS
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (c.relname)::information_schema.sql_identifier AS table_name,
    (c.prtype)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, c.relowner, 'USAGE'::text) OR c.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable,
    (
        CASE
            WHEN (c.prtype = 'SELECT'::text) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS with_hierarchy
   FROM ( SELECT pg_class.oid,
            pg_class.relname,
            pg_class.relnamespace,
            pg_class.relkind,
            pg_class.relowner,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).is_grantable AS is_grantable
           FROM pg_class) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
    pg_namespace nc,
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE ((((((c.relnamespace = nc.oid) AND (c.relkind = ANY (ARRAY['r'::"char", 'v'::"char"]))) AND (c.grantee = grantee.oid)) AND (c.grantor = u_grantor.oid)) AND (c.prtype = ANY (ARRAY['INSERT'::text, 'SELECT'::text, 'UPDATE'::text, 'DELETE'::text, 'TRUNCATE'::text, 'REFERENCES'::text, 'TRIGGER'::text]))) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)));


ALTER TABLE table_privileges OWNER TO portaladmin;

--
-- Name: tables; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW tables AS
 SELECT (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (c.relname)::information_schema.sql_identifier AS table_name,
    (
        CASE
            WHEN (nc.oid = pg_my_temp_schema()) THEN 'LOCAL TEMPORARY'::text
            WHEN (c.relkind = 'r'::"char") THEN 'BASE TABLE'::text
            WHEN (c.relkind = 'v'::"char") THEN 'VIEW'::text
            WHEN (c.relkind = 'f'::"char") THEN 'FOREIGN TABLE'::text
            ELSE NULL::text
        END)::information_schema.character_data AS table_type,
    (NULL::character varying)::information_schema.sql_identifier AS self_referencing_column_name,
    (NULL::character varying)::information_schema.character_data AS reference_generation,
    (
        CASE
            WHEN (t.typname IS NOT NULL) THEN current_database()
            ELSE NULL::name
        END)::information_schema.sql_identifier AS user_defined_type_catalog,
    (nt.nspname)::information_schema.sql_identifier AS user_defined_type_schema,
    (t.typname)::information_schema.sql_identifier AS user_defined_type_name,
    (
        CASE
            WHEN ((c.relkind = 'r'::"char") OR ((c.relkind = ANY (ARRAY['v'::"char", 'f'::"char"])) AND ((pg_relation_is_updatable((c.oid)::regclass, false) & 8) = 8))) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_insertable_into,
    (
        CASE
            WHEN (t.typname IS NOT NULL) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_typed,
    (NULL::character varying)::information_schema.character_data AS commit_action
   FROM ((pg_namespace nc
     JOIN pg_class c ON ((nc.oid = c.relnamespace)))
     LEFT JOIN (pg_type t
     JOIN pg_namespace nt ON ((t.typnamespace = nt.oid))) ON ((c.reloftype = t.oid)))
  WHERE (((c.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"])) AND (NOT pg_is_other_temp_schema(nc.oid))) AND ((pg_has_role(c.relowner, 'USAGE'::text) OR has_table_privilege(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)) OR has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE tables OWNER TO portaladmin;

--
-- Name: triggered_update_columns; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW triggered_update_columns AS
 SELECT (current_database())::information_schema.sql_identifier AS trigger_catalog,
    (n.nspname)::information_schema.sql_identifier AS trigger_schema,
    (t.tgname)::information_schema.sql_identifier AS trigger_name,
    (current_database())::information_schema.sql_identifier AS event_object_catalog,
    (n.nspname)::information_schema.sql_identifier AS event_object_schema,
    (c.relname)::information_schema.sql_identifier AS event_object_table,
    (a.attname)::information_schema.sql_identifier AS event_object_column
   FROM pg_namespace n,
    pg_class c,
    pg_trigger t,
    ( SELECT ta0.tgoid,
            (ta0.tgat).x AS tgattnum,
            (ta0.tgat).n AS tgattpos
           FROM ( SELECT pg_trigger.oid AS tgoid,
                    information_schema._pg_expandarray(pg_trigger.tgattr) AS tgat
                   FROM pg_trigger) ta0) ta,
    pg_attribute a
  WHERE (((((((n.oid = c.relnamespace) AND (c.oid = t.tgrelid)) AND (t.oid = ta.tgoid)) AND ((a.attrelid = t.tgrelid) AND (a.attnum = ta.tgattnum))) AND (NOT t.tgisinternal)) AND (NOT pg_is_other_temp_schema(n.oid))) AND (pg_has_role(c.relowner, 'USAGE'::text) OR has_column_privilege(c.oid, a.attnum, 'INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE triggered_update_columns OWNER TO portaladmin;

--
-- Name: triggers; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW triggers AS
 SELECT (current_database())::information_schema.sql_identifier AS trigger_catalog,
    (n.nspname)::information_schema.sql_identifier AS trigger_schema,
    (t.tgname)::information_schema.sql_identifier AS trigger_name,
    (em.text)::information_schema.character_data AS event_manipulation,
    (current_database())::information_schema.sql_identifier AS event_object_catalog,
    (n.nspname)::information_schema.sql_identifier AS event_object_schema,
    (c.relname)::information_schema.sql_identifier AS event_object_table,
    (NULL::integer)::information_schema.cardinal_number AS action_order,
    (
        CASE
            WHEN pg_has_role(c.relowner, 'USAGE'::text) THEN ( SELECT rm.m[1] AS m
               FROM regexp_matches(pg_get_triggerdef(t.oid), '.{35,} WHEN \((.+)\) EXECUTE PROCEDURE'::text) rm(m)
             LIMIT 1)
            ELSE NULL::text
        END)::information_schema.character_data AS action_condition,
    ("substring"(pg_get_triggerdef(t.oid), ("position"("substring"(pg_get_triggerdef(t.oid), 48), 'EXECUTE PROCEDURE'::text) + 47)))::information_schema.character_data AS action_statement,
    (
        CASE ((t.tgtype)::integer & 1)
            WHEN 1 THEN 'ROW'::text
            ELSE 'STATEMENT'::text
        END)::information_schema.character_data AS action_orientation,
    (
        CASE ((t.tgtype)::integer & 66)
            WHEN 2 THEN 'BEFORE'::text
            WHEN 64 THEN 'INSTEAD OF'::text
            ELSE 'AFTER'::text
        END)::information_schema.character_data AS action_timing,
    (NULL::character varying)::information_schema.sql_identifier AS action_reference_old_table,
    (NULL::character varying)::information_schema.sql_identifier AS action_reference_new_table,
    (NULL::character varying)::information_schema.sql_identifier AS action_reference_old_row,
    (NULL::character varying)::information_schema.sql_identifier AS action_reference_new_row,
    (NULL::timestamp with time zone)::information_schema.time_stamp AS created
   FROM pg_namespace n,
    pg_class c,
    pg_trigger t,
    ( VALUES (4,'INSERT'::text), (8,'DELETE'::text), (16,'UPDATE'::text)) em(num, text)
  WHERE ((((((n.oid = c.relnamespace) AND (c.oid = t.tgrelid)) AND (((t.tgtype)::integer & em.num) <> 0)) AND (NOT t.tgisinternal)) AND (NOT pg_is_other_temp_schema(n.oid))) AND ((pg_has_role(c.relowner, 'USAGE'::text) OR has_table_privilege(c.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)) OR has_any_column_privilege(c.oid, 'INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE triggers OWNER TO portaladmin;

--
-- Name: udt_privileges; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW udt_privileges AS
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS udt_catalog,
    (n.nspname)::information_schema.sql_identifier AS udt_schema,
    (t.typname)::information_schema.sql_identifier AS udt_name,
    ('TYPE USAGE'::character varying)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, t.typowner, 'USAGE'::text) OR t.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pg_type.oid,
            pg_type.typname,
            pg_type.typnamespace,
            pg_type.typtype,
            pg_type.typowner,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).is_grantable AS is_grantable
           FROM pg_type) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable),
    pg_namespace n,
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE ((((((t.typnamespace = n.oid) AND (t.typtype = 'c'::"char")) AND (t.grantee = grantee.oid)) AND (t.grantor = u_grantor.oid)) AND (t.prtype = 'USAGE'::text)) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)));


ALTER TABLE udt_privileges OWNER TO portaladmin;

--
-- Name: usage_privileges; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW usage_privileges AS
 SELECT (u.rolname)::information_schema.sql_identifier AS grantor,
    ('PUBLIC'::character varying)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS object_catalog,
    (n.nspname)::information_schema.sql_identifier AS object_schema,
    (c.collname)::information_schema.sql_identifier AS object_name,
    ('COLLATION'::character varying)::information_schema.character_data AS object_type,
    ('USAGE'::character varying)::information_schema.character_data AS privilege_type,
    ('NO'::character varying)::information_schema.yes_or_no AS is_grantable
   FROM pg_authid u,
    pg_namespace n,
    pg_collation c
  WHERE (((u.oid = c.collowner) AND (c.collnamespace = n.oid)) AND (c.collencoding = ANY (ARRAY[(-1), ( SELECT pg_database.encoding
           FROM pg_database
          WHERE (pg_database.datname = current_database()))])))
UNION ALL
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS object_catalog,
    (n.nspname)::information_schema.sql_identifier AS object_schema,
    (t.typname)::information_schema.sql_identifier AS object_name,
    ('DOMAIN'::character varying)::information_schema.character_data AS object_type,
    ('USAGE'::character varying)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, t.typowner, 'USAGE'::text) OR t.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pg_type.oid,
            pg_type.typname,
            pg_type.typnamespace,
            pg_type.typtype,
            pg_type.typowner,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).is_grantable AS is_grantable
           FROM pg_type) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable),
    pg_namespace n,
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE ((((((t.typnamespace = n.oid) AND (t.typtype = 'd'::"char")) AND (t.grantee = grantee.oid)) AND (t.grantor = u_grantor.oid)) AND (t.prtype = 'USAGE'::text)) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)))
UNION ALL
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS object_catalog,
    (''::character varying)::information_schema.sql_identifier AS object_schema,
    (fdw.fdwname)::information_schema.sql_identifier AS object_name,
    ('FOREIGN DATA WRAPPER'::character varying)::information_schema.character_data AS object_type,
    ('USAGE'::character varying)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, fdw.fdwowner, 'USAGE'::text) OR fdw.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pg_foreign_data_wrapper.fdwname,
            pg_foreign_data_wrapper.fdwowner,
            (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl, acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl, acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl, acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_foreign_data_wrapper.fdwacl, acldefault('F'::"char", pg_foreign_data_wrapper.fdwowner)))).is_grantable AS is_grantable
           FROM pg_foreign_data_wrapper) fdw(fdwname, fdwowner, grantor, grantee, prtype, grantable),
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE ((((u_grantor.oid = fdw.grantor) AND (grantee.oid = fdw.grantee)) AND (fdw.prtype = 'USAGE'::text)) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)))
UNION ALL
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS object_catalog,
    (''::character varying)::information_schema.sql_identifier AS object_schema,
    (srv.srvname)::information_schema.sql_identifier AS object_name,
    ('FOREIGN SERVER'::character varying)::information_schema.character_data AS object_type,
    ('USAGE'::character varying)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, srv.srvowner, 'USAGE'::text) OR srv.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pg_foreign_server.srvname,
            pg_foreign_server.srvowner,
            (aclexplode(COALESCE(pg_foreign_server.srvacl, acldefault('S'::"char", pg_foreign_server.srvowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_foreign_server.srvacl, acldefault('S'::"char", pg_foreign_server.srvowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_foreign_server.srvacl, acldefault('S'::"char", pg_foreign_server.srvowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_foreign_server.srvacl, acldefault('S'::"char", pg_foreign_server.srvowner)))).is_grantable AS is_grantable
           FROM pg_foreign_server) srv(srvname, srvowner, grantor, grantee, prtype, grantable),
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE ((((u_grantor.oid = srv.grantor) AND (grantee.oid = srv.grantee)) AND (srv.prtype = 'USAGE'::text)) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)))
UNION ALL
 SELECT (u_grantor.rolname)::information_schema.sql_identifier AS grantor,
    (grantee.rolname)::information_schema.sql_identifier AS grantee,
    (current_database())::information_schema.sql_identifier AS object_catalog,
    (n.nspname)::information_schema.sql_identifier AS object_schema,
    (c.relname)::information_schema.sql_identifier AS object_name,
    ('SEQUENCE'::character varying)::information_schema.character_data AS object_type,
    ('USAGE'::character varying)::information_schema.character_data AS privilege_type,
    (
        CASE
            WHEN (pg_has_role(grantee.oid, c.relowner, 'USAGE'::text) OR c.grantable) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_grantable
   FROM ( SELECT pg_class.oid,
            pg_class.relname,
            pg_class.relnamespace,
            pg_class.relkind,
            pg_class.relowner,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantor AS grantor,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).grantee AS grantee,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).privilege_type AS privilege_type,
            (aclexplode(COALESCE(pg_class.relacl, acldefault('r'::"char", pg_class.relowner)))).is_grantable AS is_grantable
           FROM pg_class) c(oid, relname, relnamespace, relkind, relowner, grantor, grantee, prtype, grantable),
    pg_namespace n,
    pg_authid u_grantor,
    ( SELECT pg_authid.oid,
            pg_authid.rolname
           FROM pg_authid
        UNION ALL
         SELECT (0)::oid AS oid,
            'PUBLIC'::name AS name) grantee(oid, rolname)
  WHERE ((((((c.relnamespace = n.oid) AND (c.relkind = 'S'::"char")) AND (c.grantee = grantee.oid)) AND (c.grantor = u_grantor.oid)) AND (c.prtype = 'USAGE'::text)) AND ((pg_has_role(u_grantor.oid, 'USAGE'::text) OR pg_has_role(grantee.oid, 'USAGE'::text)) OR (grantee.rolname = 'PUBLIC'::name)));


ALTER TABLE usage_privileges OWNER TO portaladmin;

--
-- Name: user_defined_types; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW user_defined_types AS
 SELECT (current_database())::information_schema.sql_identifier AS user_defined_type_catalog,
    (n.nspname)::information_schema.sql_identifier AS user_defined_type_schema,
    (c.relname)::information_schema.sql_identifier AS user_defined_type_name,
    ('STRUCTURED'::character varying)::information_schema.character_data AS user_defined_type_category,
    ('YES'::character varying)::information_schema.yes_or_no AS is_instantiable,
    (NULL::character varying)::information_schema.yes_or_no AS is_final,
    (NULL::character varying)::information_schema.character_data AS ordering_form,
    (NULL::character varying)::information_schema.character_data AS ordering_category,
    (NULL::character varying)::information_schema.sql_identifier AS ordering_routine_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS ordering_routine_schema,
    (NULL::character varying)::information_schema.sql_identifier AS ordering_routine_name,
    (NULL::character varying)::information_schema.character_data AS reference_type,
    (NULL::character varying)::information_schema.character_data AS data_type,
    (NULL::integer)::information_schema.cardinal_number AS character_maximum_length,
    (NULL::integer)::information_schema.cardinal_number AS character_octet_length,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_schema,
    (NULL::character varying)::information_schema.sql_identifier AS character_set_name,
    (NULL::character varying)::information_schema.sql_identifier AS collation_catalog,
    (NULL::character varying)::information_schema.sql_identifier AS collation_schema,
    (NULL::character varying)::information_schema.sql_identifier AS collation_name,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision,
    (NULL::integer)::information_schema.cardinal_number AS numeric_precision_radix,
    (NULL::integer)::information_schema.cardinal_number AS numeric_scale,
    (NULL::integer)::information_schema.cardinal_number AS datetime_precision,
    (NULL::character varying)::information_schema.character_data AS interval_type,
    (NULL::integer)::information_schema.cardinal_number AS interval_precision,
    (NULL::character varying)::information_schema.sql_identifier AS source_dtd_identifier,
    (NULL::character varying)::information_schema.sql_identifier AS ref_dtd_identifier
   FROM pg_namespace n,
    pg_class c,
    pg_type t
  WHERE ((((n.oid = c.relnamespace) AND (t.typrelid = c.oid)) AND (c.relkind = 'c'::"char")) AND (pg_has_role(t.typowner, 'USAGE'::text) OR has_type_privilege(t.oid, 'USAGE'::text)));


ALTER TABLE user_defined_types OWNER TO portaladmin;

--
-- Name: user_detail; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE user_detail (
    user_id character varying(128) NOT NULL,
    status character varying(8) NOT NULL,
    tell_phone character varying(11),
    zip_code character varying(6),
    address character varying(256),
    address_detail character varying(256),
    user_name character varying(128),
    admin_yn character varying(1) DEFAULT 'N'::character varying NOT NULL,
    refresh_token character varying(128),
    auth_access_cnt numeric DEFAULT 0,
    auth_access_time date,
    img_path character varying(512)
);


ALTER TABLE user_detail OWNER TO portaladmin;

--
-- Name: user_mapping_options; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW user_mapping_options AS
 SELECT um.authorization_identifier,
    um.foreign_server_catalog,
    um.foreign_server_name,
    ((pg_options_to_table(um.umoptions)).option_name)::information_schema.sql_identifier AS option_name,
    (
        CASE
            WHEN ((((um.umuser <> (0)::oid) AND ((um.authorization_identifier)::name = "current_user"())) OR ((um.umuser = (0)::oid) AND pg_has_role((um.srvowner)::name, 'USAGE'::text))) OR ( SELECT pg_authid.rolsuper
               FROM pg_authid
              WHERE (pg_authid.rolname = "current_user"()))) THEN (pg_options_to_table(um.umoptions)).option_value
            ELSE NULL::text
        END)::information_schema.character_data AS option_value
   FROM information_schema._pg_user_mappings um;


ALTER TABLE user_mapping_options OWNER TO portaladmin;

--
-- Name: user_mappings; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW user_mappings AS
 SELECT _pg_user_mappings.authorization_identifier,
    _pg_user_mappings.foreign_server_catalog,
    _pg_user_mappings.foreign_server_name
   FROM information_schema._pg_user_mappings;


ALTER TABLE user_mappings OWNER TO portaladmin;

--
-- Name: view_column_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW view_column_usage AS
 SELECT DISTINCT (current_database())::information_schema.sql_identifier AS view_catalog,
    (nv.nspname)::information_schema.sql_identifier AS view_schema,
    (v.relname)::information_schema.sql_identifier AS view_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nt.nspname)::information_schema.sql_identifier AS table_schema,
    (t.relname)::information_schema.sql_identifier AS table_name,
    (a.attname)::information_schema.sql_identifier AS column_name
   FROM pg_namespace nv,
    pg_class v,
    pg_depend dv,
    pg_depend dt,
    pg_class t,
    pg_namespace nt,
    pg_attribute a
  WHERE ((((((((((((((((nv.oid = v.relnamespace) AND (v.relkind = 'v'::"char")) AND (v.oid = dv.refobjid)) AND (dv.refclassid = ('pg_class'::regclass)::oid)) AND (dv.classid = ('pg_rewrite'::regclass)::oid)) AND (dv.deptype = 'i'::"char")) AND (dv.objid = dt.objid)) AND (dv.refobjid <> dt.refobjid)) AND (dt.classid = ('pg_rewrite'::regclass)::oid)) AND (dt.refclassid = ('pg_class'::regclass)::oid)) AND (dt.refobjid = t.oid)) AND (t.relnamespace = nt.oid)) AND (t.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"]))) AND (t.oid = a.attrelid)) AND (dt.refobjsubid = a.attnum)) AND pg_has_role(t.relowner, 'USAGE'::text));


ALTER TABLE view_column_usage OWNER TO portaladmin;

--
-- Name: view_routine_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW view_routine_usage AS
 SELECT DISTINCT (current_database())::information_schema.sql_identifier AS table_catalog,
    (nv.nspname)::information_schema.sql_identifier AS table_schema,
    (v.relname)::information_schema.sql_identifier AS table_name,
    (current_database())::information_schema.sql_identifier AS specific_catalog,
    (np.nspname)::information_schema.sql_identifier AS specific_schema,
    ((((p.proname)::text || '_'::text) || (p.oid)::text))::information_schema.sql_identifier AS specific_name
   FROM pg_namespace nv,
    pg_class v,
    pg_depend dv,
    pg_depend dp,
    pg_proc p,
    pg_namespace np
  WHERE ((((((((((((nv.oid = v.relnamespace) AND (v.relkind = 'v'::"char")) AND (v.oid = dv.refobjid)) AND (dv.refclassid = ('pg_class'::regclass)::oid)) AND (dv.classid = ('pg_rewrite'::regclass)::oid)) AND (dv.deptype = 'i'::"char")) AND (dv.objid = dp.objid)) AND (dp.classid = ('pg_rewrite'::regclass)::oid)) AND (dp.refclassid = ('pg_proc'::regclass)::oid)) AND (dp.refobjid = p.oid)) AND (p.pronamespace = np.oid)) AND pg_has_role(p.proowner, 'USAGE'::text));


ALTER TABLE view_routine_usage OWNER TO portaladmin;

--
-- Name: view_table_usage; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW view_table_usage AS
 SELECT DISTINCT (current_database())::information_schema.sql_identifier AS view_catalog,
    (nv.nspname)::information_schema.sql_identifier AS view_schema,
    (v.relname)::information_schema.sql_identifier AS view_name,
    (current_database())::information_schema.sql_identifier AS table_catalog,
    (nt.nspname)::information_schema.sql_identifier AS table_schema,
    (t.relname)::information_schema.sql_identifier AS table_name
   FROM pg_namespace nv,
    pg_class v,
    pg_depend dv,
    pg_depend dt,
    pg_class t,
    pg_namespace nt
  WHERE ((((((((((((((nv.oid = v.relnamespace) AND (v.relkind = 'v'::"char")) AND (v.oid = dv.refobjid)) AND (dv.refclassid = ('pg_class'::regclass)::oid)) AND (dv.classid = ('pg_rewrite'::regclass)::oid)) AND (dv.deptype = 'i'::"char")) AND (dv.objid = dt.objid)) AND (dv.refobjid <> dt.refobjid)) AND (dt.classid = ('pg_rewrite'::regclass)::oid)) AND (dt.refclassid = ('pg_class'::regclass)::oid)) AND (dt.refobjid = t.oid)) AND (t.relnamespace = nt.oid)) AND (t.relkind = ANY (ARRAY['r'::"char", 'v'::"char", 'f'::"char"]))) AND pg_has_role(t.relowner, 'USAGE'::text));


ALTER TABLE view_table_usage OWNER TO portaladmin;

--
-- Name: views; Type: VIEW; Schema: public; Owner: portaladmin
--

CREATE VIEW views AS
 SELECT (current_database())::information_schema.sql_identifier AS table_catalog,
    (nc.nspname)::information_schema.sql_identifier AS table_schema,
    (c.relname)::information_schema.sql_identifier AS table_name,
    (
        CASE
            WHEN pg_has_role(c.relowner, 'USAGE'::text) THEN pg_get_viewdef(c.oid)
            ELSE NULL::text
        END)::information_schema.character_data AS view_definition,
    (
        CASE
            WHEN ('check_option=cascaded'::text = ANY (c.reloptions)) THEN 'CASCADED'::text
            WHEN ('check_option=local'::text = ANY (c.reloptions)) THEN 'LOCAL'::text
            ELSE 'NONE'::text
        END)::information_schema.character_data AS check_option,
    (
        CASE
            WHEN ((pg_relation_is_updatable((c.oid)::regclass, false) & 20) = 20) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_updatable,
    (
        CASE
            WHEN ((pg_relation_is_updatable((c.oid)::regclass, false) & 8) = 8) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_insertable_into,
    (
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM pg_trigger
              WHERE ((pg_trigger.tgrelid = c.oid) AND (((pg_trigger.tgtype)::integer & 81) = 81)))) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_trigger_updatable,
    (
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM pg_trigger
              WHERE ((pg_trigger.tgrelid = c.oid) AND (((pg_trigger.tgtype)::integer & 73) = 73)))) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_trigger_deletable,
    (
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM pg_trigger
              WHERE ((pg_trigger.tgrelid = c.oid) AND (((pg_trigger.tgtype)::integer & 69) = 69)))) THEN 'YES'::text
            ELSE 'NO'::text
        END)::information_schema.yes_or_no AS is_trigger_insertable_into
   FROM pg_namespace nc,
    pg_class c
  WHERE ((((c.relnamespace = nc.oid) AND (c.relkind = 'v'::"char")) AND (NOT pg_is_other_temp_schema(nc.oid))) AND ((pg_has_role(c.relowner, 'USAGE'::text) OR has_table_privilege(c.oid, 'SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::text)) OR has_any_column_privilege(c.oid, 'SELECT, INSERT, UPDATE, REFERENCES'::text)));


ALTER TABLE views OWNER TO portaladmin;

--
-- Name: web_ide_user; Type: TABLE; Schema: public; Owner: portaladmin
--

CREATE TABLE web_ide_user (
    user_id character varying(128) NOT NULL,
    org_name character varying(128) NOT NULL,
    url character varying(128),
    use_yn character varying(1) DEFAULT 'N'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone
);


ALTER TABLE web_ide_user OWNER TO portaladmin;

--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY answer ALTER COLUMN no SET DEFAULT nextval('answer_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY board ALTER COLUMN no SET DEFAULT nextval('board_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY board_comment ALTER COLUMN no SET DEFAULT nextval('board_comment_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY buildpack_category ALTER COLUMN no SET DEFAULT nextval('buildpack_category_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY catalog_history ALTER COLUMN no SET DEFAULT nextval('catalog_history_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY documents ALTER COLUMN no SET DEFAULT nextval('documents_no_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY invite_org_space ALTER COLUMN id SET DEFAULT nextval('invite_org_space_id_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY menu ALTER COLUMN no SET DEFAULT nextval('menu_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY notice ALTER COLUMN no SET DEFAULT nextval('notice_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY question ALTER COLUMN no SET DEFAULT nextval('question_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY servicepack_category ALTER COLUMN no SET DEFAULT nextval('servicepack_category_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY starter_buildpack_relation ALTER COLUMN no SET DEFAULT nextval('starter_buildpack_relation_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY starter_category ALTER COLUMN no SET DEFAULT nextval('starter_category_no_seq'::regclass);


--
-- Name: no; Type: DEFAULT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY starter_servicepack_relation ALTER COLUMN no SET DEFAULT nextval('starter_servicepack_relation_no_seq'::regclass);


--
-- Data for Name: answer; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (2392, '답다ㅏ다다다ㅏㄷㅂ', 'MTR_Map.gif', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/3af6c7a6582044aa91673f500c1ab15e.gif', 105686, '2016-11-03 16:21:42.052506', '2016-11-03 16:21:49.371066', 2371, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (2393, 'ㅎㅎㅎㅎㅎㅎㅎ', 'MTR_Map.gif', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/db8d433d288249d8aa1a33e49634f15f.gif', 105686, '2016-11-03 16:25:33.349967', '2016-11-03 16:25:33.349967', 2383, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (2395, 'ㅓㅗㅓㅗㅓㅗ', '', '', 0, '2016-11-03 16:31:01.813954', '2016-11-03 16:31:01.813954', 2384, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (729, 'ㅇㅇㅇ', '개방형플랫폼_사용자포탈_3차sprint 화면설계_0.2.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/7f1983ee0f5f428088b4f3598c28b463.pptx', 854891, '2016-09-26 15:29:55.863462', '2016-09-26 15:29:55.863462', 236, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (22, '답변입니다', 'git-sayong-gaideu-v01.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/f577448b6a1d494cbefc74960059891e.docx', 4698321, '2016-09-01 14:41:20.75258', '2016-09-26 15:30:16.360479', 239, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (726, '답변입니다', 'Jenkins 설치 및 사용 가이드 v0.1.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/cdb6a523cdb94b6ea65f29b44b5ce37b.docx', 3732233, '2016-09-26 15:23:24.786862', '2016-09-26 15:30:28.945596', 238, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (727, '답변', 'Intellij_IDEA_Module_추가가이드.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/214f5ba677d34399a168bc94699719b0.docx', 3355930, '2016-09-26 15:25:28.629767', '2016-09-26 15:30:40.328935', 237, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (542, 'test', '개방형플랫폼_사용자포탈_2차sprint 화면설계_0.2.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/4ca153c67e72419aa2548c2b53d3332e.pptx', 919839, '2016-09-12 14:44:29.502675', '2016-09-26 15:32:44.850354', 234, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (1577, '222', 'img7406960927791723656.png', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/d9ec02bc83e04daeb1891e68aa605aab.png', 7714, '2016-10-18 15:02:57.284196', '2016-10-18 15:02:57.284196', 2300, 'admin');
INSERT INTO answer (no, content, file_name, file_path, file_size, created, lastmodified, question_no, answerer) VALUES (2041, '답변입니다~', '시범사업_Help_Desk_준공_보고서.pdf', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/77a6a227125d46188697f499efb3cdbd.pdf', 3816381, '2016-10-27 06:29:04.327034', '2016-10-27 06:29:04.327034', 2355, 'admin');


--
-- Name: answer_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('answer_no_seq', 2466, true);


--
-- Data for Name: auto_scaling_config; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO auto_scaling_config (no, guid, org, space, app, instance_min_cnt, instance_max_cnt, cpu_threshold_min_per, cpu_threshold_max_per, memory_min_size, memory_max_size, check_time_sec, auto_increase_yn, auto_decrease_yn) VALUES (2, '4403434e-2fe0-4177-a984-596b37115431', 'OCP', 'dev', 'portal-web-admin', 2, 20, 0.2, 0.8, 256, 2048, 10, 'N', 'N');
INSERT INTO auto_scaling_config (no, guid, org, space, app, instance_min_cnt, instance_max_cnt, cpu_threshold_min_per, cpu_threshold_max_per, memory_min_size, memory_max_size, check_time_sec, auto_increase_yn, auto_decrease_yn) VALUES (1, '500e4896-a3de-423d-8c7b-bb0a55faae11', 'OCP', 'dev', 'portal-web-user', 2, 20, 0.2, 0.8, 256, 2048, 12, 'Y', 'N');


--
-- Data for Name: board; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (330, '다른 사용자 글 테스트', 'junit-test-user', '다른 사용자 글 테스트', '', '', 0, '2016-10-25 18:05:19.795145', '2016-10-25 18:05:19.795145', -1, 330);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (331, '다른 사용자 글 테스트2', 'junit-test-user', '다른 사용자 글 테스트2


-------------------------------------------------------------------------------------------------------

다른 사용자 글 테스트', '', '', 0, '2016-10-25 18:05:37.090577', '2016-10-25 18:05:37.090577', 330, 330);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (351, 'aaa', 'admin', 'bbb', '', '', 0, '2016-10-28 14:43:51.941662', '2016-10-28 14:44:14.251117', -1, 351);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (386, 'das', 'admin', 'das', 'manifest-dev.yml', 'http://blobstore.115.68.46.29.xip.io/tmp/nameOfFile.jpg', 360, '2016-11-03 17:17:14.291159', '2016-11-03 17:17:14.291159', -1, 386);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (273, '댓글 테스트 ', 'admin', '댓글 테스트 ', '', '', 0, '2016-10-25 10:52:23.39774', '2016-10-25 10:52:23.39774', -1, 273);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (300, '댓글테스트', 'admin', '댓글테스트', '', '', 0, '2016-10-25 11:04:39.410102', '2016-10-25 11:04:39.410102', -1, 300);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (309, '답글 테스트의 답글3', 'admin', '


-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:18:00.252301', '2016-10-25 17:18:00.252301', 306, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (312, '답글 테스트의 답글2의 답글1', 'admin', '


-------------------------------------------------------------------------------------------------------




-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:18:32.110743', '2016-10-25 17:18:32.110743', 308, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (101, '새글 테스트1', 'admin', 'ㅛㅛㅛaaaaaggggttt', '', '', 0, '2016-09-26 14:00:21.491443', '2016-10-24 11:15:08.51944', -1, 101);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (71, '새글1', 'admin', '새글1', '', '', 0, '2016-09-21 15:43:06.716425', '2016-09-21 15:43:06.716425', -1, 71);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (72, '새글2', 'admin', '새글2', '', '', 0, '2016-09-21 15:43:16.168016', '2016-09-21 15:43:16.168016', -1, 72);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (75, '새글2의 답글2', 'admin', '새글2의 답글2


----------------------------------------------------------------------------

새글2', '', '', 0, '2016-09-21 15:44:00.915488', '2016-09-21 15:44:00.915488', 72, 72);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (76, '새글2의 답글1의 답글1', 'admin', '
새글2의 답글1의 답글1

----------------------------------------------------------------------------


새글2의 답글1

----------------------------------------------------------------------------

새글2', '', '', 0, '2016-09-21 15:44:16.773212', '2016-09-21 15:44:16.773212', 74, 72);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (78, '새글4', 'admin', '새글4', '개방형플랫폼_사용자포탈_3차sprint 화면설계_0.2.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/9f266331f3864449b78b500b2c175256.pptx', 854891, '2016-09-22 00:14:43.884462', '2016-09-22 00:14:43.884462', -1, 78);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (80, '새글4의 답글1', 'admin', '새글4의 답글1

----------------------------------------------------------------------------

새글4', '', '', 0, '2016-09-22 00:18:52.584171', '2016-09-22 00:18:52.584171', 78, 78);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (82, '답글 ', 'admin', '안녕하세요. 

답글입니다. 

----------------------------------------------------------------------------


새글2의 답글1의 답글1

----------------------------------------------------------------------------


새글2의 답글1

----------------------------------------------------------------------------

새글2', '', '', 0, '2016-09-22 00:29:22.096463', '2016-09-22 00:29:22.096463', 76, 72);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (92, '새글5 수정1', 'admin', 'ㄹ', '개방형플랫폼_사용자포탈_2차sprint 화면설계_0.2.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/e62d24e0a276472f80744fa4858fd116.pptx', 919839, '2016-09-22 17:53:25.276047', '2016-09-26 13:58:55.355655', -1, 92);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (86, '새글 테스트.', 'admin', '테스트.', '', '', 0, '2016-09-22 01:53:06.779223', '2016-09-22 01:53:06.779223', -1, 86);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (74, '새글2의 답글1 ', 'admin', '
새글2의 답글1 11

----------------------------------------------------------------------------

새글2', '', '', 0, '2016-09-21 15:43:48.988861', '2016-09-22 13:32:48.798047', 72, 72);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (352, 'ccccccc', 'admin', '

', '', '', 0, '2016-10-28 14:44:42.321679', '2016-10-28 14:44:42.321679', 351, 351);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (152, '새 파일 테스트', 'admin', '새 파일 테스트', '서비스데스크 운영관리지침.PDF', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/46332d0bd5e842328c4275359273be88.PDF', 4314146, '2016-10-05 14:01:16.569589', '2016-10-24 17:20:34.602398', -1, 152);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (248, '게시판 테스트입니다', 'admin', '게시판 테스트입니다', '서비스데스크 운영관리지침 (1) (1).PDF', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/8b25b18a48134b0fbc65c304fa0d61cb.PDF', 4314146, '2016-10-25 10:00:21.856792', '2016-10-25 10:00:21.856792', -1, 248);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (251, '답글', 'admin', '
답글

----------------------------------------------------------------------------

게시판 테스트입니다', '', '', 0, '2016-10-25 10:15:25.172442', '2016-10-25 10:15:25.172442', 248, 248);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (277, '질문있어요', 'admin', '질문있어요', '', '', 0, '2016-10-25 10:58:36.320522', '2016-10-27 04:45:25.084635', -1, 277);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (307, '답글 테스트의 답글1', 'admin', '


-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:17:44.999958', '2016-10-25 17:17:44.999958', 306, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (308, '답글 테스트의 답글2', 'admin', '


-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:17:52.906277', '2016-10-25 17:17:52.906277', 306, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (310, '답글 테스트의 답글4', 'admin', '


-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:18:08.784827', '2016-10-25 17:18:08.784827', 306, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (311, '답글 테스트의 답글5', 'admin', '


-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:18:17.104017', '2016-10-25 17:18:17.104017', 306, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (313, '답글 테스트의 답글2의 답글2', 'admin', '


-------------------------------------------------------------------------------------------------------




-------------------------------------------------------------------------------------------------------

답글 테스트', '', '', 0, '2016-10-25 17:18:39.990624', '2016-10-25 17:18:39.990624', 308, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (353, 'abc', 'admin', 'def', '', '', 0, '2016-10-28 17:06:56.426549', '2016-10-28 17:06:56.426549', -1, 353);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (306, '답글 테스트', 'admin', '답글 테스트', '', '', 0, '2016-10-25 17:17:31.759237', '2016-10-25 17:55:06.564536', -1, 306);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (278, '파스타 사용해보니~', 'admin', '파스타 사용해보니~', '', '', 0, '2016-10-25 10:58:44.924859', '2016-10-27 04:45:48.268273', -1, 278);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (279, '관리자님~', 'admin', '관리자님~', '', '', 0, '2016-10-25 10:58:52.639764', '2016-10-27 04:46:13.255503', -1, 279);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (288, '게시판 테스트합니다', 'admin', '게시판 테스트합니다', '', '', 0, '2016-10-25 11:00:37.835875', '2016-10-27 04:46:48.844493', -1, 288);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (354, 'ABC', 'admin', 'DEF', '', '', 0, '2016-10-28 17:07:10.26509', '2016-10-28 17:07:10.26509', -1, 354);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (280, '안녕하세요', 'admin', '안녕하세요', '', '', 0, '2016-10-25 10:59:00.730854', '2016-10-25 10:59:00.730854', -1, 280);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (281, '글 리스트', 'admin', '글 리스트', '', '', 0, '2016-10-25 10:59:12.230354', '2016-10-25 10:59:12.230354', -1, 281);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (282, '많이많이', 'admin', '많이많이', '', '', 0, '2016-10-25 10:59:20.647355', '2016-10-25 10:59:20.647355', -1, 282);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (274, '안녕하세요', 'admin', '안녕하세요', '', '', 0, '2016-10-25 10:58:08.577365', '2016-10-25 10:58:08.577365', -1, 274);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (275, '반갑습니다', 'admin', '반갑습니다', '', '', 0, '2016-10-25 10:58:17.858769', '2016-10-25 10:58:17.858769', -1, 275);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (276, '파스타가 뭔가요', 'admin', '파스타가 뭔가요', '', '', 0, '2016-10-25 10:58:27.803817', '2016-10-25 10:58:27.803817', -1, 276);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (355, 'aBc', 'admin', 'dEf', '', '', 0, '2016-10-28 17:07:19.418393', '2016-10-28 17:07:19.418393', -1, 355);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (283, '글글글', 'admin', '글글글', '', '', 0, '2016-10-25 10:59:29.506697', '2016-10-25 10:59:29.506697', -1, 283);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (284, '파스타 파스 타 파스-타 팟스타', 'admin', '파스타 파스 타 파스-타 팟스타', '', '', 0, '2016-10-25 10:59:47.517288', '2016-10-25 10:59:47.517288', -1, 284);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (285, '파스타ㅏㅏㅏㅏㅏ', 'admin', '파스타ㅏㅏㅏㅏㅏ', '', '', 0, '2016-10-25 11:00:01.209824', '2016-10-25 11:00:01.209824', -1, 285);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (287, '답글이 많을때', 'admin', '답글이 많을때', '', '', 0, '2016-10-25 11:00:26.584499', '2016-10-25 11:00:26.584499', -1, 287);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (289, '테ㅔㅔㅔㅔㅔㅔ스트', 'admin', '테ㅔㅔㅔㅔㅔㅔ스트', '', '', 0, '2016-10-25 11:00:51.355328', '2016-10-25 11:00:51.355328', -1, 289);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (290, '테스ㅡㅡㅡㅡㅡㅡㅡㅡ트', 'admin', '테스ㅡㅡㅡㅡㅡㅡㅡㅡ트', '', '', 0, '2016-10-25 11:01:00.501908', '2016-10-25 11:01:00.501908', -1, 290);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (291, '테에ㅔㅔㅔㅔㅔㅔ스트', 'admin', '테에ㅔㅔㅔㅔㅔㅔ스트', '', '', 0, '2016-10-25 11:01:11.759139', '2016-10-25 11:01:11.759139', -1, 291);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (292, '더더더더ㅓㅓㅓㅓ', 'admin', '더더더더ㅓㅓㅓㅓ', '', '', 0, '2016-10-25 11:01:26.488237', '2016-10-25 11:01:26.488237', -1, 292);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (293, '마니마니', 'admin', '마니마니', '', '', 0, '2016-10-25 11:01:33.601205', '2016-10-25 11:01:33.601205', -1, 293);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (295, '봉골레', 'admin', '까르보나라', '', '', 0, '2016-10-25 11:01:49.354425', '2016-10-25 11:01:49.354425', -1, 295);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (296, '토마토', 'admin', '토마토', '', '', 0, '2016-10-25 11:01:56.472996', '2016-10-25 11:01:56.472996', -1, 296);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (297, '난 로제', 'admin', '난 로제', '', '', 0, '2016-10-25 11:02:03.327311', '2016-10-25 11:02:03.327311', -1, 297);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (298, '핏자', 'admin', '핏자', '', '', 0, '2016-10-25 11:02:17.185541', '2016-10-25 11:02:17.185541', -1, 298);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (299, '파슷타 파스타', 'admin', '파슷타 파스타', '', '', 0, '2016-10-25 11:03:22.403265', '2016-10-25 11:03:22.403265', -1, 299);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (302, '테스트2', 'admin', 'ㄴㅁㅇ', '', '', 0, '2016-10-25 06:35:52.158539', '2016-10-25 06:35:52.158539', -1, 302);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (301, '커뮤니티 새글', 'admin', '내용', '', '', 0, '2016-10-25 06:22:18.468765', '2016-10-25 06:22:18.468765', -1, 301);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (294, '까르보나라', 'admin', '까르보나라 핏자', '', '', 0, '2016-10-25 11:01:42.762978', '2016-10-25 15:50:58.607271', -1, 294);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (382, 'dd', 'admin', 'dd', 'manifest-dev.yml', 'http://blobstore.115.68.46.29.xip.io/adirectory/nameOfFile.jpg', 360, '2016-11-03 16:41:01.779014', '2016-11-03 16:41:01.779014', -1, 382);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (383, 'ddd', 'admin', 'sad', 'manifest-dev.yml', 'http://blobstore.115.68.46.29.xip.io/tmp/nameOfFile.jpg', 360, '2016-11-03 16:43:41.539505', '2016-11-03 16:43:41.539505', -1, 383);
INSERT INTO board (no, title, user_id, content, file_name, file_path, file_size, created, lastmodified, parent_no, group_no) VALUES (384, 'ddasd', 'admin', 'dsa', 'manifest-dev.yml', 'http://blobstore.115.68.46.29.xip.io/tmp/nameOfFile.jpg', 360, '2016-11-03 17:01:58.927646', '2016-11-03 17:01:58.927646', -1, 384);


--
-- Data for Name: board_comment; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (1, '1userid', '1test_content', '2016-07-28 01:55:10.254995', '2016-07-28 01:55:10.254995', 71, -1, 1);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (2, '2userid', '1test_content', '2016-07-28 01:55:31.636353', '2016-07-28 01:55:31.636353', 71, -1, 2);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (3, '3userid', '1test_content', '2016-07-28 01:55:34.618202', '2016-07-28 01:55:34.618202', 71, -1, 3);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (4, 'test_id00', 'comment content test 111 222 333 444 555', '2016-08-16 05:55:00.431866', NULL, 72, -1, 4);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (5, 'test_id00', 'comment content test 111 222 333 444 555', '2016-08-16 05:55:06.737624', NULL, 72, -1, 5);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (6, 'test_id00', 'comment content test 111 222 333 444 555', '2016-08-16 05:55:07.388805', NULL, 72, -1, 6);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (7, 'test_id00', 'comment content test 111 222 333 444 555', '2016-08-16 05:55:08.007686', NULL, 72, -1, 7);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (8, 'test_id00', 'comment content test 111 222 333 444 555', '2016-08-16 05:55:09.03593', NULL, 72, -1, 8);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (9, 'test_id00', 'reply - comment content test 111 222 333 444 555', '2016-08-16 05:55:55.158466', NULL, 72, 5, 5);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (10, 'test_id00', 'reply - comment content test 111 222 333 444 555', '2016-08-16 05:55:55.703505', NULL, 72, 5, 5);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (11, 'test_id00', 'reply - comment content test 111 222 333 444 555', '2016-08-16 05:55:56.149662', NULL, 72, 5, 5);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (13, 'test 01', 'reply of reply', '2016-08-17 05:21:54.268886', NULL, 72, 10, 5);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (12, 'test 01', 'reply of reply -- kkkkkkkk kkkkkkkkkkkk kkkkkkkkkkkkkkkk ffffffffffffff fffffffffffffffff ffffffffff kkkkkkkkk kkkkkkkk kkkkkkkkkkkkkkk kkkdddddddddddd ddddddddddd djjjjjjjj jjjjjjjjjjjjjj jjjjjjjjjj jjjjjggggggg ggggggg gggggg gggggg', '2016-08-17 05:21:53.069071', NULL, 72, 10, 5);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (117, 'chsong', 'ㅇㅇㅇㅇ', '2016-09-23 05:53:39.023359', '2016-09-23 05:53:39.023359', 92, -1, 0);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (450, 'admin', 'ㄴㄴㄴ', '2016-11-02 14:58:06.386831', '2016-11-02 14:58:06.386831', 355, -1, 450);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (15, 'admin', '222', '2016-09-22 11:29:43.379695', '2016-09-22 11:29:43.379695', 72, -1, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (451, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:10.000667', '2016-11-02 14:58:10.000667', 355, -1, 451);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (19, 'admin', '111', '2016-09-22 11:37:12.649519', '2016-09-22 11:37:12.649519', 78, -1, 19);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (20, 'admin', '222', '2016-09-22 11:37:16.381509', '2016-09-22 11:37:16.381509', 78, -1, 20);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (21, 'admin', '333', '2016-09-22 11:37:22.708266', '2016-09-22 11:37:22.708266', 78, -1, 21);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (22, 'admin', '444', '2016-09-22 11:37:28.965259', '2016-09-22 11:37:28.965259', 78, -1, 22);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (23, 'admin', '555', '2016-09-22 11:40:02.414329', '2016-09-22 11:40:02.414329', 78, -1, 23);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (24, 'admin', '666', '2016-09-22 11:42:55.882949', '2016-09-22 11:42:55.882949', 78, -1, 24);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (25, 'admin', '777', '2016-09-22 11:44:08.584084', '2016-09-22 11:44:08.584084', 78, -1, 25);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (26, 'admin', '888', '2016-09-22 11:44:16.815242', '2016-09-22 11:44:16.815242', 78, -1, 26);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (27, 'admin', '999', '2016-09-22 11:44:26.753994', '2016-09-22 11:44:26.753994', 78, -1, 27);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (28, 'admin', '10', '2016-09-22 11:45:01.292018', '2016-09-22 11:45:01.292018', 78, -1, 28);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (29, 'admin', '11', '2016-09-22 11:45:10.390167', '2016-09-22 11:45:10.390167', 78, -1, 29);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (30, 'admin', '12', '2016-09-22 11:45:29.696439', '2016-09-22 11:45:29.696439', 78, -1, 30);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (31, 'admin', '13', '2016-09-22 11:47:26.907841', '2016-09-22 11:47:26.907841', 78, -1, 31);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (32, 'admin', '14', '2016-09-22 11:48:46.718551', '2016-09-22 11:48:46.718551', 78, -1, 32);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (33, 'admin', '15', '2016-09-22 11:48:59.022012', '2016-09-22 11:48:59.022012', 78, -1, 33);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (34, 'admin', '16', '2016-09-22 11:49:16.947508', '2016-09-22 11:49:16.947508', 78, -1, 34);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (35, 'admin', '666', '2016-09-22 14:55:45.460595', '2016-09-22 14:55:45.460595', 72, -1, 35);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (39, 'admin', '111111111111', '2016-09-22 16:55:36.58996', '2016-09-22 16:55:36.58996', 72, 15, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (40, 'admin', '2222222222222', '2016-09-22 16:55:52.863628', '2016-09-22 16:55:52.863628', 72, 15, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (42, 'admin', '33333333', '2016-09-22 16:56:03.605568', '2016-09-22 16:56:03.605568', 72, 15, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (43, 'admin', '33333333', '2016-09-22 16:56:03.607624', '2016-09-22 16:56:03.607624', 72, 15, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (44, 'admin', '33333333', '2016-09-22 16:56:03.612094', '2016-09-22 16:56:03.612094', 72, 15, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (45, 'admin', '11111', '2016-09-22 16:57:06.286832', '2016-09-22 16:57:06.286832', 76, 36, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (46, 'admin', '111112222', '2016-09-22 16:57:10.229008', '2016-09-22 16:57:10.229008', 76, 36, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (47, 'admin', '111112222', '2016-09-22 16:57:10.229757', '2016-09-22 16:57:10.229757', 76, 36, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (329, 'admin', '1의 답 댓글 입니당', '2016-10-25 11:24:52.657126', '2016-10-25 11:24:52.657126', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (444, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:57:45.856324', '2016-11-02 14:57:45.856324', 355, -1, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (36, 'admin', '댓1 수정', '2016-09-22 14:57:37.762104', '2016-09-23 18:11:51.918979', 76, -1, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (41, 'admin', '2222222222222 수정', '2016-09-22 16:55:52.865832', '2016-09-26 09:21:13.306045', 72, 15, 15);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (295, 'admin', '안녕ㅋㅋㅋㅋ', '2016-10-25 09:58:42.809398', '2016-10-25 09:58:42.809398', 152, -1, 295);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (120, 'admin', '댓1', '2016-09-26 09:58:31.364811', '2016-09-26 09:58:31.364811', 82, -1, 120);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (121, 'admin', '댓2', '2016-09-26 09:58:36.693503', '2016-09-26 09:58:44.289804', 82, -1, 121);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (122, 'admin', '대댓1', '2016-09-26 09:58:51.466615', '2016-09-26 09:58:51.466615', 82, 120, 120);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (445, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:57:48.703426', '2016-11-02 14:57:48.703426', 355, -1, 445);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (397, 'junit-test-user', 'dddd', '2016-10-26 10:07:26.243863', '2016-10-26 10:07:26.243863', 330, 392, 392);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (127, 'admin', '댓글', '2016-09-26 14:09:24.411391', '2016-09-26 14:09:24.411391', 101, -1, 127);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (178, 'admin', '테스트.', '2016-09-29 08:42:32.864572', '2016-09-29 08:42:32.864572', 101, 133, 133);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (179, 'admin', '안녕하세요..', '2016-09-29 08:42:45.168494', '2016-09-29 08:42:45.168494', 101, 178, 133);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (129, 'admin', '댓글', '2016-09-26 14:12:50.12423', '2016-09-26 14:12:50.12423', 101, -1, 129);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (130, 'admin', '111', '2016-09-26 14:17:21.363299', '2016-09-26 14:17:21.363299', 101, 127, 127);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (131, 'admin', '222', '2016-09-26 14:17:25.11895', '2016-09-26 14:17:25.11895', 101, 130, 127);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (132, 'admin', '111', '2016-09-26 14:17:29.549022', '2016-09-26 14:17:29.549022', 101, 127, 127);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (133, 'admin', '댓글', '2016-09-26 14:21:05.157211', '2016-09-26 14:21:05.157211', 101, -1, 133);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (446, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:57:53.693918', '2016-11-02 14:57:53.693918', 355, -1, 446);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (180, 'admin', '안녕하세요..', '2016-09-29 08:43:02.809822', '2016-09-29 08:43:02.809822', 101, -1, 180);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (384, 'junit-test-user', '다른 사용자 글 테스트', '2016-10-25 18:06:19.751148', '2016-10-25 18:06:19.751148', 331, -1, 384);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (447, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:57:57.046508', '2016-11-02 14:57:57.046508', 355, -1, 447);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (418, 'admin', '아캔멬유퓔굿', '2016-10-28 13:37:41.678708', '2016-10-28 13:37:54.87339', 330, 417, 417);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (417, 'admin', '시간을 넘어ㅇㅇㅇ', '2016-10-28 13:37:08.53071', '2016-10-28 13:38:07.293637', 330, -1, 417);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (448, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:00.232093', '2016-11-02 14:58:00.232093', 355, -1, 448);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (449, 'admin', 'ㄴㄴㄴ', '2016-11-02 14:58:02.712663', '2016-11-02 14:58:02.712663', 355, -1, 449);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (419, 'admin', '.', '2016-10-28 13:52:42.349907', '2016-10-28 14:02:29.639729', 306, -1, 419);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (452, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:13.004636', '2016-11-02 14:58:13.004636', 355, -1, 452);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (420, 'admin', '.', '2016-10-28 14:04:03.70019', '2016-10-28 14:04:21.587431', 306, -1, 420);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (453, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:16.068539', '2016-11-02 14:58:16.068539', 355, -1, 453);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (426, 'admin', 'b', '2016-10-28 14:35:39.69826', '2016-10-28 14:35:58.487152', 331, -1, 426);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (427, 'admin', 'd', '2016-10-28 14:36:07.219306', '2016-10-28 14:36:21.505267', 331, 426, 426);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (454, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:19.585466', '2016-11-02 14:58:19.585466', 355, -1, 454);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (455, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:22.452125', '2016-11-02 14:58:22.452125', 355, -1, 455);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (456, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:25.750952', '2016-11-02 14:58:25.750952', 355, -1, 456);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (457, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:31.55386', '2016-11-02 14:58:31.55386', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (458, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:38.287903', '2016-11-02 14:58:38.287903', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (459, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:58:42.765693', '2016-11-02 14:58:42.765693', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (460, 'admin', 'ㅁㅁㅁ', '2016-11-02 14:59:09.971879', '2016-11-02 14:59:09.971879', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (461, 'admin', 'ㅓㅓ', '2016-11-02 15:02:36.955181', '2016-11-02 15:02:36.955181', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (462, 'admin', 'ㅏㅏ', '2016-11-02 15:06:42.50777', '2016-11-02 15:06:42.50777', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (463, 'admin', 'ㅎㅎ', '2016-11-02 15:06:48.769096', '2016-11-02 15:06:48.769096', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (464, 'admin', 'ㅎㅎ', '2016-11-02 15:06:52.69702', '2016-11-02 15:06:52.69702', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (465, 'admin', 'ㅎㅎ', '2016-11-02 15:06:56.859791', '2016-11-02 15:06:56.859791', 355, 457, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (466, 'admin', 'ㅎㅎ', '2016-11-02 15:07:00.765102', '2016-11-02 15:07:00.765102', 355, 444, 444);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (136, 'admin', '댓글', '2016-09-26 05:35:43.425427', '2016-09-26 05:35:43.425427', 86, -1, -1);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (335, 'admin', '1의 답 댓', '2016-10-25 11:28:52.028711', '2016-10-25 11:28:52.028711', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (336, 'admin', '1의 답 댓 3', '2016-10-25 11:29:01.582507', '2016-10-25 11:29:01.582507', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (337, 'admin', '1의 답 댓4', '2016-10-25 11:29:07.508312', '2016-10-25 11:29:07.508312', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (338, 'admin', '1의 답 댓5', '2016-10-25 11:29:11.807692', '2016-10-25 11:29:11.807692', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (339, 'admin', '1의 답 댓6', '2016-10-25 11:29:16.540333', '2016-10-25 11:29:16.540333', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (340, 'admin', '1의 답 댓7', '2016-10-25 11:29:22.001888', '2016-10-25 11:29:22.001888', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (298, 'admin', '댓글입니다 3', '2016-10-25 11:09:07.144504', '2016-10-25 11:09:07.144504', 300, -1, 298);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (373, 'admin', '댓', '2016-10-25 13:24:10.391823', '2016-10-25 13:24:10.391823', 299, -1, 373);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (301, 'admin', '댓글입니다 6', '2016-10-25 11:11:39.530383', '2016-10-25 11:11:39.530383', 300, -1, 301);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (302, 'admin', '댓글입니다 7', '2016-10-25 11:11:43.119243', '2016-10-25 11:11:43.119243', 300, -1, 302);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (305, 'admin', '댓글입니다 10', '2016-10-25 11:11:53.383865', '2016-10-25 11:11:53.383865', 300, -1, 305);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (374, 'admin', 'ㄷㄷ11', '2016-10-25 13:24:28.336296', '2016-10-25 13:24:32.459404', 299, 373, 373);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (307, 'admin', '댓글입니다 12', '2016-10-25 11:12:01.781777', '2016-10-25 11:12:01.781777', 300, -1, 307);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (308, 'admin', '댓글입니다 13', '2016-10-25 11:12:05.446374', '2016-10-25 11:12:05.446374', 300, -1, 308);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (309, 'admin', '댓글입니다 14', '2016-10-25 11:12:08.832984', '2016-10-25 11:12:08.832984', 300, -1, 309);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (310, 'admin', '댓글입니다 15', '2016-10-25 11:12:11.796861', '2016-10-25 11:12:11.796861', 300, -1, 310);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (311, 'admin', '댓글입니다 16', '2016-10-25 11:12:14.898453', '2016-10-25 11:12:14.898453', 300, -1, 311);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (312, 'admin', '댓글입니다 17', '2016-10-25 11:12:18.493122', '2016-10-25 11:12:18.493122', 300, -1, 312);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (313, 'admin', '댓글입니다 18', '2016-10-25 11:12:22.960928', '2016-10-25 11:12:22.960928', 300, -1, 313);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (296, 'admin', '댓글입니다 1 수정', '2016-10-25 11:06:39.846659', '2016-10-25 11:13:46.008609', 300, -1, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (303, 'admin', '댓글입니다 8 수정
', '2016-10-25 11:11:46.20636', '2016-10-25 11:13:53.515874', 300, -1, 303);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (379, 'junit-test-user', '다른 사용자 글 테스트', '2016-10-25 18:05:44.226655', '2016-10-25 18:05:44.226655', 330, -1, 379);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (380, 'junit-test-user', '다른 사용자 글 테스트', '2016-10-25 18:05:46.482548', '2016-10-25 18:05:46.482548', 330, -1, 380);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (421, 'admin', '', '2016-10-28 14:04:31.292983', '2016-10-28 14:04:31.292983', 306, -1, 421);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (422, 'admin', '', '2016-10-28 14:04:34.634811', '2016-10-28 14:04:34.634811', 306, -1, 422);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (423, 'admin', '.', '2016-10-28 14:08:40.874144', '2016-10-28 14:08:40.874144', 306, 422, 422);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (424, 'admin', '', '2016-10-28 14:09:22.302382', '2016-10-28 14:09:22.302382', 306, -1, 424);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (114, 'admin', '1234  수정~~
ㅋㅋㅋㅋ', '2016-09-23 13:57:25.599846', '2016-09-23 18:12:01.56385', 76, 46, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (341, 'admin', '1의 답 댓 8', '2016-10-25 13:04:15.331729', '2016-10-25 13:04:15.331729', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (342, 'admin', '1의 답 댓 9', '2016-10-25 13:04:24.341053', '2016-10-25 13:04:24.341053', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (343, 'admin', '1의 답 댓 10', '2016-10-25 13:05:08.977829', '2016-10-25 13:05:08.977829', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (344, 'admin', '1의 답 댓 11', '2016-10-25 13:05:15.725056', '2016-10-25 13:05:15.725056', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (345, 'admin', '답 댓 5의 답 댓 1', '2016-10-25 13:05:40.164426', '2016-10-25 13:05:40.164426', 300, 338, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (346, 'admin', '답 댓 5의 답 댓 2', '2016-10-25 13:05:47.651973', '2016-10-25 13:05:47.651973', 300, 338, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (99, 'admin', '댓글1', '2016-09-23 09:30:47.435085', '2016-09-23 09:30:47.435085', 86, -1, 99);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (100, 'admin', '댓글2', '2016-09-23 09:30:53.209538', '2016-09-23 09:30:53.209538', 86, -1, 100);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (347, 'admin', '답 댓 5의 답 댓 3', '2016-10-25 13:05:53.157654', '2016-10-25 13:05:53.157654', 300, 338, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (348, 'admin', '답 댓 5의 답 댓 4', '2016-10-25 13:05:58.471039', '2016-10-25 13:05:58.471039', 300, 338, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (102, 'admin', '대댓1', '2016-09-23 09:31:03.422191', '2016-09-23 09:31:03.422191', 86, 99, 99);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (103, 'admin', '대댓2', '2016-09-23 09:31:11.271273', '2016-09-23 09:31:11.271273', 86, 99, 99);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (105, 'admin', '대대댓1', '2016-09-23 09:31:29.876877', '2016-09-23 09:31:29.876877', 86, 102, 99);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (314, 'admin', '댓글입니다 19', '2016-10-25 11:12:27.826663', '2016-10-25 11:12:27.826663', 300, -1, 314);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (315, 'admin', '댓글입니다 20', '2016-10-25 11:12:32.782413', '2016-10-25 11:12:32.782413', 300, -1, 315);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (316, 'admin', '댓글입니다 21', '2016-10-25 11:12:36.511766', '2016-10-25 11:12:36.511766', 300, -1, 316);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (110, 'admin', '댓댓', '2016-09-23 13:57:01.281237', '2016-09-23 13:57:01.281237', 76, 36, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (111, 'admin', 'ㅂㅂㅂ11', '2016-09-23 13:57:09.862728', '2016-09-23 13:57:09.862728', 76, 110, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (112, 'admin', '111', '2016-09-23 13:57:14.269066', '2016-09-23 13:57:14.269066', 76, 110, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (113, 'admin', 'ㅁㅁㅁ', '2016-09-23 13:57:19.092291', '2016-09-23 13:57:19.092291', 76, 111, 36);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (116, 'chsong', 'ㅇㅇㅇㅇ', '2016-09-23 05:53:23.255423', '2016-09-23 05:53:23.255423', 92, -1, 0);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (317, 'admin', '댓글입니다 22', '2016-10-25 11:12:41.242171', '2016-10-25 11:12:41.242171', 300, -1, 317);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (318, 'admin', '댓글입니다 23', '2016-10-25 11:12:44.953245', '2016-10-25 11:12:44.953245', 300, -1, 318);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (319, 'admin', '댓글입니다 24', '2016-10-25 11:12:51.136787', '2016-10-25 11:12:51.136787', 300, -1, 319);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (320, 'admin', '댓글입니다 25', '2016-10-25 11:12:55.252767', '2016-10-25 11:12:55.252767', 300, -1, 320);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (321, 'admin', '댓글입니다 26', '2016-10-25 11:12:59.930362', '2016-10-25 11:12:59.930362', 300, -1, 321);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (322, 'admin', '댓글입니다 27', '2016-10-25 11:13:03.442807', '2016-10-25 11:13:03.442807', 300, -1, 322);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (323, 'admin', '댓글입니다 28', '2016-10-25 11:13:07.599485', '2016-10-25 11:13:07.599485', 300, -1, 323);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (324, 'admin', '댓글입니다 29', '2016-10-25 11:13:11.829199', '2016-10-25 11:13:11.829199', 300, -1, 324);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (325, 'admin', '댓글입니다 30', '2016-10-25 11:13:16.305363', '2016-10-25 11:13:16.305363', 300, -1, 325);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (349, 'admin', '답 댓 5의 답 댓 5', '2016-10-25 13:06:04.608795', '2016-10-25 13:06:04.608795', 300, 338, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (350, 'admin', '답 댓 5의 답 댓 2의 답 댓1', '2016-10-25 13:06:18.419252', '2016-10-25 13:06:18.419252', 300, 346, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (351, 'admin', '답 댓 5의 답 댓 2의 답 댓1', '2016-10-25 13:06:24.547821', '2016-10-25 13:06:24.547821', 300, 346, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (352, 'admin', '답 댓 5의 답 댓 2의 답 댓3', '2016-10-25 13:06:35.189341', '2016-10-25 13:06:35.189341', 300, 346, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (353, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓1', '2016-10-25 13:06:49.344219', '2016-10-25 13:06:49.344219', 300, 351, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (354, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓2', '2016-10-25 13:06:56.262598', '2016-10-25 13:06:56.262598', 300, 351, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (355, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓3', '2016-10-25 13:07:01.802302', '2016-10-25 13:07:01.802302', 300, 351, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (356, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓4', '2016-10-25 13:07:07.743943', '2016-10-25 13:07:07.743943', 300, 351, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (357, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓3의 답 대새 1', '2016-10-25 13:07:20.327531', '2016-10-25 13:07:20.327531', 300, 355, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (358, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓3의 답 댓2', '2016-10-25 13:07:30.022173', '2016-10-25 13:07:30.022173', 300, 355, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (359, 'admin', '답 댓 5의 답 댓 2의 답 댓3의 답 댓3의 답 댓2의 답 댓 1', '2016-10-25 13:07:58.875038', '2016-10-25 13:07:58.875038', 300, 358, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (360, 'admin', '댓글입니다 31', '2016-10-25 13:08:10.439703', '2016-10-25 13:08:10.439703', 300, -1, 360);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (361, 'admin', '1의 답 댓2의 답 댓1', '2016-10-25 13:08:31.101021', '2016-10-25 13:08:31.101021', 300, 335, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (362, 'admin', '1의 답 댓2의 답 댓2', '2016-10-25 13:08:37.682289', '2016-10-25 13:08:37.682289', 300, 335, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (363, 'admin', '1의 답 댓2의 답 댓3', '2016-10-25 13:08:44.388346', '2016-10-25 13:08:44.388346', 300, 335, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (364, 'admin', '1의 답 댓2의 답 댓4', '2016-10-25 13:08:50.696518', '2016-10-25 13:08:50.696518', 300, 335, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (372, 'admin', '1의 답댓~', '2016-10-25 13:15:02.666169', '2016-10-25 13:15:02.666169', 300, 296, 296);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (381, 'junit-test-user', '다른 사용자 글 테스트', '2016-10-25 18:05:48.847889', '2016-10-25 18:05:48.847889', 330, -1, 381);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (382, 'junit-test-user', '다른 사용자 글 테스트 111', '2016-10-25 18:05:51.806454', '2016-10-25 18:06:02.4868', 330, 379, 379);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (383, 'junit-test-user', '다른 사용자 글 테스트222', '2016-10-25 18:05:57.559237', '2016-10-25 18:06:07.280613', 330, 380, 380);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (385, 'junit-test-user', '안녕하세요', '2016-10-25 18:06:33.357417', '2016-10-25 18:06:33.357417', 306, -1, 385);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (386, 'junit-test-user', '안녕하세요2', '2016-10-25 18:06:36.092266', '2016-10-25 18:06:36.092266', 306, -1, 386);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (387, 'junit-test-user', '안녕하세요3', '2016-10-25 18:06:41.635491', '2016-10-25 18:06:41.635491', 306, -1, 387);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (392, 'admin', '안녕하세요', '2016-10-26 09:56:32.233861', '2016-10-26 09:56:32.233861', 330, -1, 392);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (393, 'admin', '답 댓 글 달기', '2016-10-26 09:56:44.014615', '2016-10-26 09:56:44.014615', 330, 381, 381);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (394, 'admin', '댓~글~ 댓~~', '2016-10-26 09:57:48.672213', '2016-10-28 13:31:11.777546', 330, 383, 380);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (416, 'admin', 'ㅁㅁㅁㅁㅁㅁㅁ', '2016-10-28 13:34:37.9763', '2016-10-28 13:34:37.9763', 330, -1, 416);
INSERT INTO board_comment (no, user_id, content, created, lastmodified, board_no, parent_no, group_no) VALUES (425, 'admin', '.', '2016-10-28 14:14:45.363463', '2016-10-28 14:14:45.363463', 306, -1, 425);


--
-- Name: board_comment_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('board_comment_no_seq', 476, true);


--
-- Name: board_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('board_no_seq', 390, true);


--
-- Data for Name: bom; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1001, NULL, '컴퓨터', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1002, 1001, '본체', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1003, 1001, '모니터', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1004, 1001, '프린터', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1005, 1002, '메인보드', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1006, 1002, '렌카드', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1007, 1002, '파워', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1008, 1005, 'RAM', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1009, 1005, 'CPU', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1010, 1005, '그래픽카드', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1011, 1005, '기타장치', 1);
INSERT INTO bom (item_id, parent_id, item_name, item_qty) VALUES (1012, 1002, '기타장치', 1);


--
-- Data for Name: buildpack_category; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (772, 'Ruby 앱 개발환경', 'buildpack_system', 'Ruby 오프라인 앱 개발환경', 'Ruby on Rails 웹 앱을 쉽게 개발, 배치, 스케일링합니다.', 'ruby_buildpack', 'ruby빌드팩.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/04193080254d4a01b84f346d7c3793be.jpg', 'Y', NULL, NULL, NULL, 'admin', '2016-07-21 01:32:10.512154', '2016-08-23 05:12:34.237005');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3160, 'PHP 앱 개발환경', 'buildpack_system', 'PHP 오프라인 앱 개발환경', 'PHP 웹 앱을 쉽게 개발, 배치, 스케일링합니다.', 'php_buildpack', 'php빌드팩.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/7ef3ee7bf15243438e15131fcc082b19.jpg', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:45:11.818279', '2016-08-23 17:46:40.524146');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3161, 'Java Pinpoint 오프라인 앱 개발환경', 'buildpack_custom', 'Java Pinpoint 오프라인 APM 앱 개발환경', 'Java 어플이케이션 모니터링을 위한 Pinpoint 오프라인 개발환경입니다.
Naver 에서 만든 분산환경 애플리케이션 모니터링입니다.
', 'java_buildpack_pinpoint', 'pinpoint빌드팩.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/413abc95642f456b9a5013c248cbd996.png', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:47:17.486118', '2016-08-23 04:50:56.639711');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3159, 'Python 앱 개발환경', 'buildpack_system', 'Python 오프라인 앱 개발환경', 'Python 웹 앱을 쉽게 개발, 배치, 스케일링합니다.', 'python_buildpack', 'python-logo.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/b6421dfbdced4409b01a6de6ce469adc.png', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:44:40.598132', '2016-08-23 04:55:42.65644');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3158, 'GO 앱 개발환경', 'buildpack_system', 'GO 오프라인 앱 개발환경', 'Go 웹 앱을 쉽게 개발, 배치, 스케일링합니다.', 'go_buildpack', 'Go언어.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/c15ad542981d4523ad3da9b387de44c8.jpg', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:41:23.425005', '2016-08-23 04:58:35.086938');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3157, 'Nodejs 앱 개발환경', 'buildpack_system', 'Nodejs 오프라인 앱 개발환경', 'Node.js 웹 앱을 쉽게 개발, 배치, 스케일링합니다.', 'nodejs_buildpack', 'nodejs_logo.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/3d7ce8f77a05434181585ba96dddee8c.png', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:40:26.810202', '2016-08-23 05:00:50.216614');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3156, 'Java8 온라인 앱 개발환경', 'buildpack_system', 'Java8 온라인 앱 개발환경', 'Java8 온라인 빌드팩은 실행환경 구성시 자바8및 Tomcat을 다운받아서 구성한다.', 'java_buildpack', '자바8.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/933839a63e7745a58d0f60b25ce9e389.jpg', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:27:43.459598', '2016-08-23 05:07:23.245005');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (3155, '전자정부 프레임워크 앱 개발환경', 'buildpack_system', '전자정부 프레임워크 오프라인 앱 개발환경', '전자정부 프레임워크 오프라인 앱 개발환경으로 Tomcat 및  Jboss 애플리케이션 서버를 선택하여 구성할수 있다.', 'egov_buildpack', '전자정부프레임워크빌드팩.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/7dc514c8a7654d66a0ad53a244daa49a.png', 'Y', NULL, NULL, NULL, 'admin', '2016-07-26 07:25:25.575551', '2016-08-23 05:10:32.313804');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (20, 'Java8 오프라인 앱 개발환경', 'buildpack_system', 'Java8 오프라인 앱 개발환경', 'Java8 오프라인 환경에서 Tomcat 애플리케이션 서버로 자바 웹 어플리케이션 설행 환경을 구성해준다.', 'java_buildpack_offline', '자바8.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/ffdd1501c768402aace317354f7459e1.jpg', 'Y', 'sample.war', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/37b499d75def458cb91832a8755c0731.war', 9478983, 'admin', '2016-07-19 09:08:43.036086', '2016-09-05 13:52:56.265072');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (1150, 'ruby test 1', 'buildpack_system', 'ruby test 11', 'ruby test 21', 'ruby_buildpack', '', '', 'Y', 'ruby-sample.zip', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/35517571f8ef4e3fb6f3ff4660d108a5.zip', 56951, 'admin', '2016-09-06 15:39:08.176694', '2016-10-28 13:45:03.09071');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (665, 'mysql test 12', 'buildpack_system', 'mysql test 112', 'mysql test 212', 'java_buildpack_offline', '', '', 'Y', 'hello-spring-mysql.war', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/7aad407fee54477ba01a40346be3d84d.war', 8700607, 'admin', '2016-09-05 17:55:39.670537', '2016-10-28 13:47:38.274788');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (14953, 'Star Test', 'buildpack_system', '테스트 스타', '', 'java_buildpack_offline', '', '', 'N', '', '', 0, 'admin', '2016-11-03 15:52:52.23903', '2016-11-03 16:37:41.592109');
INSERT INTO buildpack_category (no, name, classification, summary, description, buildpack_name, thumb_img_name, thumb_img_path, use_yn, app_sample_file_name, app_sample_file_path, app_sample_file_size, user_id, created, lastmodified) VALUES (14952, '개발환경 테스트', 'buildpack_system', '개발환경 테스트', '', 'java_buildpack_offline', 'earth-day-2016.jpg', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/7a2e416d1caf411fbbf10e6baa16ced2.jpg', 'N', '', '', 0, 'admin', '2016-11-03 15:43:55.555335', '2016-11-03 16:38:00.031043');


--
-- Name: buildpack_category_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('buildpack_category_no_seq', 15228, true);


--
-- Data for Name: catalog_history; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (475, 127, 'starter', 'admin', '2016-08-18 16:38:11.99585', '2016-08-18 16:38:11.99585');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (476, 5976, 'starter', 'admin', '2016-08-18 16:47:29.125667', '2016-08-18 16:47:29.125667');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (477, 127, 'starter', 'testUser', '2016-08-18 08:10:25.348811', '2016-08-18 08:10:25.348811');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (478, 3155, 'buildPack', 'testUser', '2016-08-18 08:11:21.856179', '2016-08-18 08:11:21.856179');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1037, 127, 'starter', 'admin', '2016-09-05 17:20:08.107929', '2016-09-05 17:20:08.107929');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1041, 127, 'starter', 'admin', '2016-09-05 17:23:47.003758', '2016-09-05 17:23:47.003758');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (481, 3158, 'buildPack', 'testUser', '2016-08-18 08:12:13.813294', '2016-08-18 08:12:13.813294');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1042, 127, 'starter', 'admin', '2016-09-05 17:46:47.754913', '2016-09-05 17:46:47.754913');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1044, 16893, 'starter', 'admin', '2016-09-05 18:09:21.925647', '2016-09-05 18:09:21.925647');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (422, 1756, 'servicePack', 'admin', '2016-08-16 05:12:14.425728', '2016-08-16 05:12:14.425728');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (486, 3160, 'buildPack', 'testUser', '2016-08-18 08:19:31.935282', '2016-08-18 08:19:31.935282');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (550, 127, 'starter', 'admin', '2016-08-19 05:31:29.232546', '2016-08-19 05:31:29.232546');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (551, 8783, 'buildPack', 'admin', '2016-08-19 05:35:20.974577', '2016-08-19 05:35:20.974577');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (552, 8748, 'servicePack', 'admin', '2016-08-19 05:36:20.488177', '2016-08-19 05:36:20.488177');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (553, 8748, 'servicePack', 'admin', '2016-08-19 05:37:02.43426', '2016-08-19 05:37:02.43426');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (554, 8748, 'servicePack', 'admin', '2016-08-19 17:54:31.216015', '2016-08-19 17:54:31.216015');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (555, 8748, 'servicePack', 'admin', '2016-08-19 17:57:45.839631', '2016-08-19 17:57:45.839631');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (556, 8748, 'servicePack', 'admin', '2016-08-19 17:59:56.183026', '2016-08-19 17:59:56.183026');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (557, 127, 'starter', 'admin', '2016-08-19 18:10:17.991861', '2016-08-19 18:10:17.991861');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (558, 3161, 'buildPack', 'admin', '2016-08-19 18:10:45.848207', '2016-08-19 18:10:45.848207');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (620, 9609, 'starter', 'nia', '2016-08-23 06:55:50.20659', '2016-08-23 06:55:50.20659');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (621, 9609, 'starter', 'nia', '2016-08-23 06:58:47.332919', '2016-08-23 06:58:47.332919');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (622, 20, 'buildPack', 'nia', '2016-08-23 07:00:16.144271', '2016-08-23 07:00:16.144271');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (438, 8783, 'buildPack', 'admin', '2016-08-17 09:57:22.747979', '2016-08-17 09:57:22.747979');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (439, 8783, 'buildPack', 'admin', '2016-08-17 09:58:31.848234', '2016-08-17 09:58:31.848234');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (440, 8783, 'buildPack', 'admin', '2016-08-17 10:07:16.551692', '2016-08-17 10:07:16.551692');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (499, 127, 'starter', 'admin', '2016-08-18 18:19:43.390668', '2016-08-18 18:19:43.390668');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (623, 127, 'starter', 'nia', '2016-08-23 07:01:13.863478', '2016-08-23 07:01:13.863478');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (444, 8748, 'servicePack', 'admin', '2016-08-17 05:45:14.82515', '2016-08-17 05:45:14.82515');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (626, 128, 'starter', 'admin', '2016-08-23 07:11:24.233292', '2016-08-23 07:11:24.233292');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (451, 8748, 'servicePack', 'admin', '2016-08-18 10:55:15.059586', '2016-08-18 10:55:15.059586');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (452, 8748, 'servicePack', 'admin', '2016-08-18 10:55:51.192109', '2016-08-18 10:55:51.192109');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (453, 8783, 'buildPack', 'admin', '2016-08-18 13:01:29.617431', '2016-08-18 13:01:29.617431');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (454, 8783, 'buildPack', 'admin', '2016-08-18 13:23:05.809181', '2016-08-18 13:23:05.809181');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (509, 5976, 'starter', 'admin', '2016-08-18 19:12:56.932705', '2016-08-18 19:12:56.932705');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (510, 8783, 'buildPack', 'admin', '2016-08-18 19:14:29.663118', '2016-08-18 19:14:29.663118');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (511, 8748, 'servicePack', 'admin', '2016-08-18 19:14:54.873846', '2016-08-18 19:14:54.873846');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (512, 3123, 'servicePack', 'admin', '2016-08-18 19:15:20.366679', '2016-08-18 19:15:20.366679');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (407, 8, 'servicePack', 'admin', '2016-08-12 10:27:53.299998', '2016-08-12 10:27:53.299998');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (408, 8783, 'buildPack', 'admin', '2016-08-12 10:29:08.808227', '2016-08-12 10:29:08.808227');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (409, 5976, 'starter', 'admin', '2016-08-12 10:30:23.569517', '2016-08-12 10:30:23.569517');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1070, 16893, 'starter', 'admin', '2016-09-06 12:49:48.538405', '2016-09-06 12:49:48.538405');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (464, 127, 'starter', 'admin', '2016-08-18 16:07:28.876976', '2016-08-18 16:07:28.876976');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1072, 16893, 'starter', 'admin', '2016-09-06 12:51:57.628323', '2016-09-06 12:51:57.628323');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (637, 9609, 'starter', 'admin', '2016-08-24 01:11:10.675445', '2016-08-24 01:11:10.675445');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1074, 665, 'buildPack', 'admin', '2016-09-06 12:53:36.100273', '2016-09-06 12:53:36.100273');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (468, 127, 'starter', 'admin', '2016-08-18 16:16:38.670262', '2016-08-18 16:16:38.670262');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1081, 1150, 'buildPack', 'admin', '2016-09-06 15:40:11.103241', '2016-09-06 15:40:11.103241');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1083, 1150, 'buildPack', 'admin', '2016-09-06 16:08:06.614991', '2016-09-06 16:08:06.614991');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (641, 8, 'servicePack', 'admin', '2016-08-24 01:49:49.493635', '2016-08-24 01:49:49.493635');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (583, 127, 'starter', 'admin', '2016-08-22 06:51:50.228674', '2016-08-22 06:51:50.228674');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (584, 3158, 'buildPack', 'admin', '2016-08-22 07:11:05.69553', '2016-08-22 07:11:05.69553');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (585, 9609, 'starter', 'admin', '2016-08-22 07:22:00.432381', '2016-08-22 07:22:00.432381');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (950, 9609, 'starter', 'nia', '2016-09-02 10:12:39.180425', '2016-09-02 10:12:39.180425');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1021, 20, 'buildPack', 'admin', '2016-09-05 15:21:13.873096', '2016-09-05 15:21:13.873096');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (537, 127, 'starter', 'admin', '2016-08-19 01:15:03.050953', '2016-08-19 01:15:03.050953');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (538, 3159, 'buildPack', 'admin', '2016-08-19 01:18:29.243831', '2016-08-19 01:18:29.243831');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (539, 3125, 'servicePack', 'admin', '2016-08-19 01:20:21.755393', '2016-08-19 01:20:21.755393');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (540, 1130, 'servicePack', 'admin', '2016-08-19 01:21:12.424492', '2016-08-19 01:21:12.424492');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (598, 9609, 'starter', 'admin', '2016-08-23 02:39:25.680317', '2016-08-23 02:39:25.680317');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (657, 3160, 'buildPack', 'nia', '2016-08-24 06:11:02.781176', '2016-08-24 06:11:02.781176');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (658, 3125, 'servicePack', 'nia', '2016-08-24 06:25:59.381703', '2016-08-24 06:25:59.381703');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (659, 9609, 'starter', 'nia', '2016-08-24 06:27:26.086379', '2016-08-24 06:27:26.086379');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (672, 9609, 'starter', 'nia', '2016-08-24 09:11:15.216935', '2016-08-24 09:11:15.216935');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (673, 9609, 'starter', 'nia', '2016-08-24 10:34:10.150252', '2016-08-24 10:34:10.150252');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (674, 9609, 'starter', 'nia', '2016-08-25 00:44:46.323062', '2016-08-25 00:44:46.323062');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (678, 9609, 'starter', 'nia', '2016-08-25 03:03:45.486859', '2016-08-25 03:03:45.486859');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (679, 9609, 'starter', 'nia', '2016-08-25 03:35:35.978474', '2016-08-25 03:35:35.978474');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (680, 9609, 'starter', 'nia', '2016-08-25 03:36:27.932713', '2016-08-25 03:36:27.932713');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (681, 9609, 'starter', 'admin', '2016-08-25 12:51:17.92212', '2016-08-25 12:51:17.92212');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (682, 9609, 'starter', 'admin', '2016-08-25 12:53:10.630296', '2016-08-25 12:53:10.630296');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (683, 9609, 'starter', 'admin', '2016-08-25 12:56:18.98765', '2016-08-25 12:56:18.98765');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (684, 9609, 'starter', 'admin', '2016-08-25 13:06:40.281747', '2016-08-25 13:06:40.281747');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (685, 9609, 'starter', 'admin', '2016-08-25 13:07:21.752229', '2016-08-25 13:07:21.752229');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (686, 9609, 'starter', 'admin', '2016-08-25 13:08:18.838284', '2016-08-25 13:08:18.838284');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (687, 9609, 'starter', 'nia', '2016-08-25 04:10:12.923889', '2016-08-25 04:10:12.923889');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (688, 9609, 'starter', 'admin', '2016-08-25 13:14:36.702452', '2016-08-25 13:14:36.702452');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (689, 9609, 'starter', 'nia', '2016-08-25 04:33:23.576813', '2016-08-25 04:33:23.576813');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (690, 9609, 'starter', 'nia', '2016-08-25 04:42:54.795466', '2016-08-25 04:42:54.795466');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (691, 9609, 'starter', 'nia', '2016-08-25 05:01:05.614366', '2016-08-25 05:01:05.614366');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1043, 16893, 'starter', 'admin', '2016-09-05 17:57:29.841847', '2016-09-05 17:57:29.841847');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1045, 16893, 'starter', 'admin', '2016-09-05 18:14:11.085857', '2016-09-05 18:14:11.085857');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1071, 16893, 'starter', 'admin', '2016-09-06 12:51:09.547388', '2016-09-06 12:51:09.547388');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1073, 16893, 'starter', 'admin', '2016-09-06 12:52:35.39914', '2016-09-06 12:52:35.39914');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1075, 665, 'buildPack', 'admin', '2016-09-06 12:53:58.253672', '2016-09-06 12:53:58.253672');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1076, 3123, 'servicePack', 'admin', '2016-09-06 12:59:35.542912', '2016-09-06 12:59:35.542912');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1077, 3123, 'servicePack', 'admin', '2016-09-06 12:59:55.852544', '2016-09-06 12:59:55.852544');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1082, 1150, 'buildPack', 'admin', '2016-09-06 15:45:10.657097', '2016-09-06 15:45:10.657097');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1090, 1150, 'buildPack', 'admin', '2016-09-06 16:34:38.017759', '2016-09-06 16:34:38.017759');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1167, 1150, 'buildPack', 'admin', '2016-09-12 00:23:54.242077', '2016-09-12 00:23:54.242077');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1106, 127, 'starter', 'admin', '2016-09-06 08:28:29.932217', '2016-09-06 08:28:29.932217');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1808, 3125, 'servicePack', 'admin', '2016-11-01 09:31:12.667528', '2016-11-01 09:31:12.667528');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1809, 3125, 'servicePack', 'admin', '2016-11-01 09:31:41.76709', '2016-11-01 09:31:41.76709');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1812, 3126, 'servicePack', 'admin', '2016-11-01 09:40:36.838998', '2016-11-01 09:40:36.838998');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1813, 3160, 'buildPack', 'admin', '2016-11-01 09:53:48.498174', '2016-11-01 09:53:48.498174');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1815, 3159, 'buildPack', 'admin', '2016-11-01 09:59:13.429036', '2016-11-01 09:59:13.429036');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1817, 3157, 'buildPack', 'admin', '2016-11-01 09:59:54.135466', '2016-11-01 09:59:54.135466');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1820, 1150, 'buildPack', 'admin', '2016-11-01 10:01:58.474421', '2016-11-01 10:01:58.474421');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1821, 772, 'buildPack', 'admin', '2016-11-01 10:02:25.60284', '2016-11-01 10:02:25.60284');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1822, 665, 'buildPack', 'admin', '2016-11-01 10:03:01.775028', '2016-11-01 10:03:01.775028');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1823, 20, 'buildPack', 'admin', '2016-11-01 10:03:35.753384', '2016-11-01 10:03:35.753384');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1824, 3125, 'servicePack', 'admin', '2016-11-01 10:14:40.248075', '2016-11-01 10:14:40.248075');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1807, 3125, 'servicePack', 'admin', '2016-10-31 18:11:26.201126', '2016-10-31 18:11:26.201126');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1810, 3123, 'servicePack', 'admin', '2016-11-01 09:39:41.299956', '2016-11-01 09:39:41.299956');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1811, 3123, 'servicePack', 'admin', '2016-11-01 09:39:59.367485', '2016-11-01 09:39:59.367485');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1814, 3160, 'buildPack', 'admin', '2016-11-01 09:58:55.133684', '2016-11-01 09:58:55.133684');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1816, 3158, 'buildPack', 'admin', '2016-11-01 09:59:28.497403', '2016-11-01 09:59:28.497403');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1818, 3156, 'buildPack', 'admin', '2016-11-01 10:00:38.765593', '2016-11-01 10:00:38.765593');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1819, 3155, 'buildPack', 'admin', '2016-11-01 10:01:23.784724', '2016-11-01 10:01:23.784724');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1825, 3125, 'servicePack', 'admin', '2016-11-01 10:20:25.777023', '2016-11-01 10:20:25.777023');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1826, 3125, 'servicePack', 'admin', '2016-11-01 10:22:35.833391', '2016-11-01 10:22:35.833391');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1827, 3125, 'servicePack', 'admin', '2016-11-01 10:27:49.805096', '2016-11-01 10:27:49.805096');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1828, 3125, 'servicePack', 'admin', '2016-11-01 10:29:17.473015', '2016-11-01 10:29:17.473015');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1829, 3125, 'servicePack', 'admin', '2016-11-01 10:32:23.285207', '2016-11-01 10:32:23.285207');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1830, 3125, 'servicePack', 'admin', '2016-11-01 10:32:52.438833', '2016-11-01 10:32:52.438833');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1831, 3125, 'servicePack', 'admin', '2016-11-01 10:34:14.38841', '2016-11-01 10:34:14.38841');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1832, 3125, 'servicePack', 'admin', '2016-11-01 10:52:21.384334', '2016-11-01 10:52:21.384334');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1833, 3157, 'buildPack', 'admin', '2016-11-01 10:54:48.669309', '2016-11-01 10:54:48.669309');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1834, 16893, 'starter', 'admin', '2016-11-01 11:10:52.545658', '2016-11-01 11:10:52.545658');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1835, 127, 'starter', 'admin', '2016-11-01 11:13:24.514295', '2016-11-01 11:13:24.514295');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1836, 3125, 'servicePack', 'admin', '2016-11-01 11:21:00.500045', '2016-11-01 11:21:00.500045');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1840, 3160, 'buildPack', 'admin', '2016-11-01 13:05:42.362679', '2016-11-01 13:05:42.362679');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1841, 127, 'starter', 'admin', '2016-11-01 13:33:03.893848', '2016-11-01 13:33:03.893848');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1270, 3123, 'servicePack', 'chsong', '2016-09-23 06:05:54.065436', '2016-09-23 06:05:54.065436');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1271, 20, 'buildPack', 'chsong', '2016-09-23 06:39:04.508578', '2016-09-23 06:39:04.508578');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1851, 20, 'buildPack', 'admin', '2016-11-01 17:23:10.223179', '2016-11-01 17:23:10.223179');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1852, 665, 'buildPack', 'admin', '2016-11-01 17:27:52.622912', '2016-11-01 17:27:52.622912');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1278, 20, 'buildPack', 'admin', '2016-09-26 15:20:54.372107', '2016-09-26 15:20:54.372107');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1279, 20, 'buildPack', 'admin', '2016-09-26 15:26:27.096357', '2016-09-26 15:26:27.096357');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1280, 20, 'buildPack', 'admin', '2016-09-26 15:40:40.853379', '2016-09-26 15:40:40.853379');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1281, 20, 'buildPack', 'admin', '2016-09-26 15:43:34.646701', '2016-09-26 15:43:34.646701');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1856, 3123, 'servicePack', 'admin', '2016-11-02 11:15:00.660399', '2016-11-02 11:15:00.660399');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1857, 3125, 'servicePack', 'admin', '2016-11-02 11:17:06.159899', '2016-11-02 11:17:06.159899');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1858, 3123, 'servicePack', 'admin', '2016-11-02 11:18:34.119885', '2016-11-02 11:18:34.119885');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1859, 127, 'starter', 'admin', '2016-11-02 14:47:33.194277', '2016-11-02 14:47:33.194277');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1860, 3125, 'servicePack', 'admin', '2016-11-02 14:49:15.838052', '2016-11-02 14:49:15.838052');
INSERT INTO catalog_history (no, catalog_no, catalog_type, user_id, created, lastmodified) VALUES (1861, 20565, 'servicePack', 'admin', '2016-11-02 14:49:34.547094', '2016-11-02 14:49:34.547094');


--
-- Name: catalog_history_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('catalog_history_no_seq', 1891, true);


--
-- Data for Name: code_detail; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('documents_starter', '앱 템플릿', NULL, 'DOCUMENTS_CLASSIFICATION', 'Y', 1, 'admin', '2016-09-01 13:45:32.171665', '2016-09-01 13:45:32.171665');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('documents_build_pack', '앱 개발환경', NULL, 'DOCUMENTS_CLASSIFICATION', 'Y', 2, 'admin', '2016-09-01 13:45:32.179965', '2016-09-01 13:45:32.179965');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('documents_service_pack', '서비스', NULL, 'DOCUMENTS_CLASSIFICATION', 'Y', 3, 'admin', '2016-09-01 13:45:32.186455', '2016-09-01 13:45:32.186455');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('documents_etc', '기타', NULL, 'DOCUMENTS_CLASSIFICATION', 'Y', 4, 'admin', '2016-09-01 13:45:32.1928', '2016-09-01 13:45:32.1928');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('2', '거부', '이메일승인거부', 'USER_STATUS', 'Y', 3, 'admin', '2016-08-02 04:56:27.340761', '2016-08-02 04:56:27.340761');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('3', '삭제', '삭제회원', 'USER_STATUS', 'Y', 4, 'admin', '2016-08-02 04:56:27.36629', '2016-08-02 04:56:27.36629');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('minCpu', '20', 'cpu 최소', 'USER_AUTOSCAILE', 'Y', 4, 'admin', '2016-07-26 01:53:42.507291', '2016-07-26 08:02:02.716957');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('maxCpu', '80', 'cpu 최대', 'USER_AUTOSCAILE', 'Y', 3, 'admin', '2016-07-26 01:53:42.462987', '2016-07-26 08:02:02.719643');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('1', '승인', '이메일승인완료', 'USER_STATUS', 'Y', 2, 'admin', '2016-08-02 04:56:27.332792', '2016-08-02 04:56:27.332792');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('ORG MANAGER', '조직 관리자', 'Can invite users and manage user roles in the org ', 'ORG_ROLES', 'Y', 1, 'admin', '2016-09-02 01:17:19.128487', '2016-09-02 01:22:38.521334');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('0', '생성', '이메일승인대기', 'USER_STATUS', 'Y', 1, 'admin', '2016-08-02 04:56:27.324097', '2016-08-02 04:57:19.782847');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('minInstance', '2', '인스턴스 최소', 'USER_AUTOSCAILE', 'Y', 1, 'admin', '2016-07-26 01:44:17.735167', '2016-07-26 08:33:01.699048');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('maxInstance', '20', '인스턴스 최대', 'USER_AUTOSCAILE', 'Y', 2, 'admin', '2016-07-26 01:44:44.574386', '2016-07-26 08:33:29.53862');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('service_storage', '데이터 저장소', ' ', 'SERVICE_PACK_CATALOG', 'Y', 1, 'admin', '2016-07-25 17:06:24.897401', '2016-08-25 00:11:37.631676');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('service_message', '메시징', ' ', 'SERVICE_PACK_CATALOG', 'Y', 2, 'admin', '2016-07-25 17:06:24.932435', '2016-08-25 00:11:49.593386');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('service_nosql', 'NoSQL 데이터베이스', ' ', 'SERVICE_PACK_CATALOG', 'Y', 3, 'admin', '2016-07-25 17:06:24.938684', '2016-08-25 00:11:56.624406');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('service_rdbms', '관계형 데이터베이스', ' ', 'SERVICE_PACK_CATALOG', 'Y', 4, 'admin', '2016-07-25 17:06:24.945151', '2016-08-25 00:12:04.789125');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('starter_main', '기본유형', '제공되는 기본 유형으로 지금 앱을 시작합니다.', 'STARTER_CATALOG', 'Y', 1, 'admin', '2016-07-25 17:04:50.558865', '2016-08-23 03:40:43.153928');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('service_monitoring', '어플리케이션 모니터링', ' ', 'SERVICE_PACK_CATALOG', 'Y', 5, 'admin', '2016-07-26 05:49:10.975736', '2016-08-25 00:12:12.823414');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('buildpack_custom', '사용자 앱 개발환경', '사용자가 스스로 구성한 앱 개발 환경으로 지금 앱을 시작합니다.', 'BUILD_PACK_CATALOG', 'Y', 2, 'admin', '2016-07-25 17:05:32.184348', '2016-08-25 00:12:52.511166');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('buildpack_system', '시스템 앱 개발환경', '파스-타에서 기본적으로 제공하는 앱 개발 환경으로 지금 앱을 시작합니다.', 'BUILD_PACK_CATALOG', 'Y', 1, 'admin', '2016-07-25 17:05:32.177993', '2016-08-25 11:05:38.745528');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('notice_event', '이벤트', '이벤트 공지', 'SUPPORT_NOTICE', 'Y', 2, 'admin', '2016-08-23 17:55:10.727551', '2016-08-24 10:14:05.654559');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('notice_notice', '공지', '공지사항', 'SUPPORT_NOTICE', 'Y', 1, 'admin', '2016-08-23 17:54:47.472187', '2016-08-24 10:14:05.654559');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('notice_problem', '장애', '장애 공지', 'SUPPORT_NOTICE', 'Y', 3, 'admin', '2016-08-23 17:55:59.077886', '2016-08-24 10:14:05.654559');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('answered', '답변완료', '답변완료 상태', 'QUESTION_STATUS', 'Y', 2, 'admin', '2016-08-24 13:13:50.643281', '2016-08-24 13:14:39.54053');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('question_etc', '기타', NULL, 'QUESTION_CLASSIFICATION', 'Y', 4, 'admin', '2016-08-24 09:52:08.778328', '2016-08-24 09:56:39.728882');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('question_service_pack', '서비스', NULL, 'QUESTION_CLASSIFICATION', 'Y', 3, 'admin', '2016-08-24 09:52:01.159572', '2016-08-24 09:56:51.484846');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('question_build_pack', '앱 개발환경', NULL, 'QUESTION_CLASSIFICATION', 'Y', 2, 'admin', '2016-08-24 09:51:18.403822', '2016-08-24 09:56:59.866448');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('question_starter', '앱 템플릿', NULL, 'QUESTION_CLASSIFICATION', 'N', 1, 'admin', '2016-08-24 09:50:57.773279', '2016-08-24 09:57:08.986631');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('waiting', '미답변', '미답변 상태', 'QUESTION_STATUS', 'Y', 1, 'admin', '2016-08-24 13:11:39.384744', '2016-08-24 13:23:05.363826');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('TEST1', 'TEST1', 'TEST1', 'CODE_TEST', 'Y', 1, 'admin', '2016-11-02 07:23:22.573752', '2016-11-02 07:23:22.573752');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('TEST2', '2', '222', 'CODE_TEST', 'N', 2, 'admin', '2016-11-03 16:57:07.615695', '2016-11-03 16:57:20.27129');
INSERT INTO code_detail (key, value, summary, group_id, use_yn, "order", user_id, created, lastmodified) VALUES ('3', '33', '333', 'CODE_TEST', 'N', 3, 'admin', '2016-11-03 16:57:28.209872', '2016-11-03 16:57:28.209872');


--
-- Data for Name: code_group; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('USER_AUTOSCAILE', '사용자포탈 자동스케일 ', '2016-07-26 01:43:43.482944', '2016-07-26 01:43:43.482944', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('USER_STATUS', '사용자상태코드', '2016-08-02 04:50:15.804691', '2016-08-02 04:50:15.804691', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('STARTER_CATALOG', '앱 템플릿 카탈로그', '2016-07-25 17:03:16.220215', '2016-08-23 03:40:43.148592', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('SERVICE_PACK_CATALOG', '서비스 카탈로그', '2016-07-25 17:03:16.207154', '2016-08-23 03:40:57.199263', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('BUILD_PACK_CATALOG', '앱 개발환경 카탈로그', '2016-07-25 17:03:16.213604', '2016-08-23 03:41:16.341018', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('QUESTION_STATUS', '답변 상태 코드', '2016-08-24 13:10:39.413851', '2016-08-24 13:10:39.413851', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('DOCUMENTS_CLASSIFICATION', '문서 분류코드', '2016-09-01 13:43:04.460445', '2016-09-01 13:43:04.460445', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('ORG_ROLES', '조직 역할', '2016-09-02 01:16:18.330342', '2016-09-02 01:16:18.330342', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('QUESTION_CLASSIFICATION', '문의분류코드', '2016-08-24 09:38:21.470845', '2016-08-24 09:38:21.470845', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('SUPPORT_NOTICE', '공지사항 분류코드', '2016-08-24 09:42:12.075216', '2016-08-24 10:14:05.629027', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('CODE_TEST', '코드 테스트용', '2016-11-02 07:20:33.283396', '2016-11-02 07:20:33.283396', 'admin');
INSERT INTO code_group (id, name, created, lastmodified, user_id) VALUES ('CODE_TEST2', '222', '2016-11-03 16:55:52.34936', '2016-11-03 16:55:52.34936', 'admin');


--
-- Data for Name: config_info; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO config_info (name, value, created_at, updated_at) VALUES ('email_auth_yn', NULL, '2016-09-02 02:10:05.9632', NULL);
INSERT INTO config_info (name, value, created_at, updated_at) VALUES ('smtp_url', 'mail.google.com', '2016-09-02 02:09:45.232196', '2016-09-02 15:14:31.723424');
INSERT INTO config_info (name, value, created_at, updated_at) VALUES ('web_ide_url', 'http://115.68.46.183:8080,http://115.68.46.184:8080', '2016-09-02 02:10:29.642137', '2016-10-24 17:11:23.462236');
INSERT INTO config_info (name, value, created_at, updated_at) VALUES ('uaa_url', 'https://login.115.68.46.30.xip.io', '2016-09-02 02:09:15.062414', '2016-10-28 15:21:56.960926');
INSERT INTO config_info (name, value, created_at, updated_at) VALUES ('user_portal_url', '', '2016-09-02 02:09:31.22277', '2016-10-28 16:37:47.335271');
INSERT INTO config_info (name, value, created_at, updated_at) VALUES ('api_url', '', '2016-09-02 02:09:09.805788', '2016-11-02 07:13:04.768568');


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (2, 'JAVA + Tomcat 가이드 문서', 'admin', 'documents_service_pack', 'Y', 'JAVA + Tomcat 가이드 문서', 'PaaSTA 포털 코딩룰.docx', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/199ef2434de740768aed4bbf9e689522.docx', 83869, '2016-09-01 14:20:12.233966', '2016-09-01 15:11:31.391334');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (7, '앱 개발 환경 설정 가이드', 'admin', 'documents_build_pack', 'Y', '앱 개발 환경 설정 가이드', '캡처2.PNG', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/a7881cbce30143f184873db08238052d.PNG', 243132, '2016-09-01 15:00:47.745875', '2016-09-01 16:30:24.48031');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (121, 'git 사용 가이드', 'admin', 'documents_etc', 'Y', 'git 사용 가이드', 'git-sayong-gaideu-v01.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/2e3bd07634fa46b4bcba481274d0ea0a.docx', 4698321, '2016-09-28 15:36:15.885722', '2016-09-28 15:39:47.665958');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (122, '개발 가이드', 'admin', 'documents_build_pack', 'Y', '개발 가이드', '샘플 애플리케이션 개발 가이드 v1.1.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/219cf63da6b74a589732f941b9a77440.docx', 119809, '2016-09-28 15:40:15.025544', '2016-09-28 15:40:15.025544');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (123, '가이드 문서', 'admin', 'documents_starter', 'Y', '가이드 문서', 'Intellij_IDEA_Module_추가가이드.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/1aba9451cb3c4289b3bd08db1bd5f5f2.docx', 3355930, '2016-09-28 15:40:49.591178', '2016-09-28 15:40:49.591178');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (124, '개발 환경 가이드', 'admin', 'documents_build_pack', 'Y', '개발환경 가이드', '개발환경설치가이드v0.62.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/0a00e59448ff47a39853109b2c77be5a.docx', 3092432, '2016-09-28 15:41:19.468273', '2016-09-28 15:41:19.468273');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (125, '자바 코딩 가이드', 'admin', 'documents_etc', 'Y', '자바 코딩 가이드', '자바코딩가이드 v0.1.docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/1bd762fb15294f72967655ba5881c523.docx', 134069, '2016-09-28 15:41:48.841632', '2016-09-28 15:41:48.841632');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (126, '코드 관리 가이드', 'admin', 'documents_build_pack', 'Y', '코드 관리 가이드', '코드관리_테이블_생성_스크립트.txt', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/f5fc736c6fca4d698e405740f7c49866.txt', 1932, '2016-09-28 15:42:16.535301', '2016-09-28 15:42:16.535301');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (127, '앱 샘플', 'admin', 'documents_starter', 'Y', '앱 샘플', 'OpenPaaSSample-master.zip', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/aa46965754e34af4bc46ea702a1430b2.zip', 43387727, '2016-09-28 15:42:45.047072', '2016-09-28 15:42:45.047072');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (128, '앱 설계 가이드', 'admin', 'documents_starter', 'Y', '앱 설계 가이드', '개방형플랫폼_운영자포탈_v1.0.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/e9bf6ff40cdb48fcaaba8790c5b78d1e.pptx', 1091377, '2016-09-28 15:43:13.180399', '2016-09-28 15:43:13.180399');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (129, '앱 설계 가이드2', 'admin', 'documents_starter', 'Y', '', '개방형플랫폼_사용자포탈_4차sprint 화면설계_0.3.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/7baa4877d668444aa9a91d192374c028.pptx', 925853, '2016-09-28 15:43:24.112525', '2016-09-28 15:43:24.112525');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (130, '앱 설계 가이드3', 'admin', 'documents_starter', 'Y', '앱 설계 가이드', '개방형플랫폼_사용자포탈_5차sprint 화면설계_0.3.pptx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/7e18f980e52444278f35292b4575a386.pptx', 808512, '2016-09-28 15:43:36.606353', '2016-09-28 15:43:36.606353');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (304, 'ㅏㅏ', 'admin', 'documents_starter', 'Y', 'ㅏㅏ', '단위테스트 결과class분담.xlsx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/1d7741811f074984822bcf3072a173d7.xlsx', 13038, '2016-10-31 15:30:19.726565', '2016-10-31 15:30:19.726565');
INSERT INTO documents (no, title, user_id, classification, use_yn, content, file_name, file_path, file_size, created, lastmodified) VALUES (318, 'ㅇㅇ', 'admin', 'documents_starter', 'N', 'ㅇㅇ', '캡처2.PNG', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/a231d471587349c3ba492e8955eb0a57.PNG', 243132, '2016-11-03 16:35:03.090541', '2016-11-03 16:35:03.090541');


--
-- Name: documents_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('documents_no_seq', 323, true);


--
-- Data for Name: invite_org_space; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO invite_org_space (id, token, gubun, invite_id, role_name, invite_user_id, user_id, create_time, access_cnt, invite_name, setyn) VALUES (71, 'XDFPN4TT', '0', 1, 'BillingManager', 'yjasmin2@gmail.com', 'admin', '2016-11-01 16:49:26.511', 0, 'OCP', 'N');
INSERT INTO invite_org_space (id, token, gubun, invite_id, role_name, invite_user_id, user_id, create_time, access_cnt, invite_name, setyn) VALUES (72, 'XDFPN4TT', '1', 2, 'SpaceDeveloper', 'yjasmin2@gmail.com', 'admin', '2016-11-01 16:49:26.527', 0, 'dev', 'N');
INSERT INTO invite_org_space (id, token, gubun, invite_id, role_name, invite_user_id, user_id, create_time, access_cnt, invite_name, setyn) VALUES (69, 'XDFPN4TT', '1', 3, 'SpaceDeveloper', 'yjasmin2@gmail.com', 'admin', '2016-11-01 16:49:26.537', 0, 'stg', 'N');


--
-- Name: invite_org_space_id_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('invite_org_space_id_seq', 72, true);


--
-- Data for Name: menu; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (1, 0, 1, '대시보드', '/org/orgMain', NULL, 'N', 'Y', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.732952');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (7, 2, 1, 'test 2-1', '#', NULL, 'Y', 'Y', 'N', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.737535');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (111, 2, 2, 'test 2-2', '#', NULL, 'N', 'N', 'Y', NULL, 'admin', '2016-10-06 15:34:18.02377', '2016-11-03 15:40:49.742241');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (110, 2, 3, 'menu 1', '#', NULL, 'N', 'N', 'Y', NULL, 'admin', '2016-10-06 15:29:55.721264', '2016-11-03 15:40:49.750628');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (8, 2, 4, 'menu 2', '#', NULL, 'Y', 'N', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.751385');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (2, 0, 2, '카탈로그', '/catalog/catalogMain', NULL, 'N', 'Y', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.751611');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (3, 0, 3, '도움말', 'https://github.com/OpenPaaSRnD/Documents', NULL, 'Y', 'Y', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.963065');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (9, 5, 1, 'test 5-1', '#', NULL, 'Y', 'Y', 'N', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.965294');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (559, 0, 4, '신규메뉴', '#', NULL, 'N', 'Y', 'N', NULL, 'admin', '2016-10-14 05:22:30.594042', '2016-11-03 15:40:49.967618');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (10, 5, 2, 'test 5-2', '#', NULL, 'Y', 'N', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.969976');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (704, 6, 1, 'MENU', '#', NULL, 'N', 'Y', 'Y', NULL, 'admin', '2016-10-18 05:25:37.811237', '2016-11-03 15:40:49.97236');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (5, 0, 5, '문서', '/documents/documentsMain', NULL, 'N', 'Y', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:49.972523');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (6, 0, 6, '공지', '/notice/noticeMain', NULL, 'N', 'Y', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:50.088634');
INSERT INTO menu (no, parent_no, sort_no, menu_name, menu_path, image_path, open_window_yn, login_yn, use_yn, description, user_id, created, lastmodified) VALUES (4, 0, 7, '커뮤니티', '/board/boardMain', NULL, 'N', 'Y', 'Y', NULL, 'admin', '2016-09-29 02:30:28.484182', '2016-11-03 15:40:50.306504');


--
-- Name: menu_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('menu_no_seq', 1295, true);


--
-- Data for Name: notice; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (15, 'PaaS-TA 소개', 'false', 'notice_notice', 'Y', 'PaaS-TA 소개', '캡처2.PNG', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/628c994e21ee47f19a4afa3038c6c38a.PNG', 243132, '2016/09/01', '2016/12/01', '2016-09-01 14:39:46.726732', '2016-09-02 14:38:56.228524');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (128, 'PaaS-TA 오픈 안내', 'true', 'notice_notice', 'Y', 'PaaS-TA 오픈 안내', 'PaaSTA 포털 코딩룰.docx', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/deff0f4dccd141368235b7e16fafa59d.docx', 83869, '2016/09/02', '2016/10/31', '2016-09-02 13:29:19.002321', '2016-09-02 14:39:23.652577');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (138, 'PaaS-TA 공지', 'false', 'notice_notice', 'Y', 'PaaS-TA 공지', '자바코딩가이드 v0.1.docx', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/4bc3017b83a74b68bc6efdf2049daa1c.docx', 134069, '2016/09/02', '2016/10/02', '2016-09-02 14:46:03.802806', '2016-09-02 15:10:20.159089');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (139, 'PaaS-TA 공지2', 'false', 'notice_notice', 'Y', 'PaaS-TA 공지2', '설계_테이블설계서(논리_물리데이터)_Portal_v0.8 (6).docx', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/bd2e78afdf7c4228b3d156a4342bf590.docx', 77738, '2016/09/02', '2016/10/02', '2016-09-02 14:46:54.539784', '2016-09-02 15:10:31.359951');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1645, '업데이트 기간 이용 불가 안내', 'true', 'notice_problem', 'Y', '업데이트 기간 이용 불가 안내', '', '', 0, '2016/10/25', '2016/10/25', '2016-10-25 14:52:58.975503', '2016-10-25 14:52:58.975503');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (745, 'PaaS-TA TEST', 'false', 'notice_notice', 'Y', 'PaaS-TA TEST', '', '', 0, '2016/09/26', '2016/10/26', '2016-09-26 17:21:46.610047', '2016-09-26 17:21:46.610047');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (130, '비공개 공지사항', 'false', 'notice_problem', 'N', '비공개 공지사항', '', '', 0, '2016/09/02', '9999/12/31', '2016-09-02 13:31:12.963856', '2016-09-28 10:20:36.152836');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (753, '공지', 'false', 'notice_notice', 'Y', '공지', '', '', 0, '2016/09/28', '2016/10/28', '2016-09-28 09:13:25.115762', '2016-09-28 09:13:25.115762');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1628, '공지테스트 11111', 'true', 'notice_notice', 'Y', '공지테스트 11111', '', '', 0, '2016/10/24', '2016/10/24', '2016-10-24 18:10:07.226081', '2016-10-24 18:10:57.278757');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (142, '파일 테스트', 'false', 'notice_notice', 'Y', '파일 테스트', 'montblanc2.pdf', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/08d7682de02f4374bbb65cc016e08cb3.pdf', 27629496, '2016/09/22', '2016/09/22', '2016-09-02 15:28:09.859156', '2016-09-23 05:39:18.064443');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (140, 'PaaS-TA 공지3', 'false', 'notice_notice', 'N', 'PaaS-TA 공지3', 'PaaSTA 포털 코딩룰.docx', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/d5aa5c5269b24ff08519cf948a5b5836.docx', 83869, '2016/09/02', '2016/10/02', '2016-09-02 15:05:58.971948', '2016-09-23 05:39:30.91432');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (810, '공지테스트4', 'false', 'notice_notice', 'Y', '공지테스트4', '', '', 0, '2016/09/28', '2016/10/28', '2016-09-28 11:11:38.330346', '2016-09-28 11:11:38.330346');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (811, '공지테스트5', 'false', 'notice_notice', 'Y', '공지테스트5', '', '', 0, '2016/09/28', '2016/10/28', '2016-09-28 11:11:47.305943', '2016-09-28 11:11:47.305943');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1064, '공지테스트 6', 'false', 'notice_notice', 'Y', '공지테스트 6', '클라우드컴퓨팅_활성화계획.hwp', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/fc21a2d2df9746bf8a6b7cf61265ecfd.hwp', 3318784, '2016/09/25', '2016/09/25', '2016-10-05 14:09:04.941947', '2016-11-03 16:12:38.080293');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1646, '새로운 이벤트 안내', 'false', 'notice_event', 'Y', '새로운 이벤트 안내', '', '', 0, '2016/10/25', '2016/11/25', '2016-10-25 14:53:12.590031', '2016-10-25 14:53:12.590031');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (754, '공지 날짜 테스트', 'false', 'notice_notice', 'Y', '공지', '', '', 0, '2016/09/27', '9999/12/31', '2016-09-28 09:14:26.814098', '2016-09-28 10:02:20.901884');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (129, 'PaaS-TA 오픈 기념 이벤트', 'true', 'notice_event', 'Y', 'PaaS-TA 오픈 기념 이벤트', '개발환경설치가이드v0.6 (1).docx', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/7bda5a85be84465e9f0e4980c7cf49c6.docx', 2735675, '2016/09/02', '2016/10/31', '2016-09-02 13:30:03.21983', '2016-09-28 10:05:08.685618');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (809, '공지테스트3', 'false', 'notice_notice', 'Y', '공지테스트3', '', '', 0, '2016/09/20', '9999/12/31', '2016-09-28 11:11:32.093968', '2016-09-28 15:00:27.051068');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (807, '공지테스트1', 'true', 'notice_notice', 'Y', '공지테스트1', '', '', 0, '2016/09/19', '2016/10/20', '2016-09-28 11:11:19.422793', '2016-09-28 15:00:50.14339');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (808, '공지테스트2', 'false', 'notice_notice', 'Y', '공지테스트2', '', '', 0, '2016/09/27', '2016/10/21', '2016-09-28 11:11:26.097371', '2016-09-28 15:01:08.363306');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1888, '새로운 중요 공지', 'true', 'notice_event', 'Y', '새로운 공지', '', '', 0, '2016/10/30', '2016/11/10', '2016-11-03 15:57:25.932244', '2016-11-03 16:37:04.422071');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1889, '새로운 공지', 'false', 'notice_notice', 'Y', '새로운 공지', 'earth-day-2016.jpg', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/3b89339486c146db9ed8cfa4f734549f.jpg', 62977, '2016/11/03', '9999/12/31', '2016-11-03 15:57:35.755343', '2016-11-03 16:37:24.292269');
INSERT INTO notice (no, title, important, classification, use_yn, content, file_name, file_path, file_size, start_date, end_date, created, lastmodified) VALUES (1890, '새로운 공지', 'true', 'notice_notice', 'Y', '새로운 공지', '', '', 0, '2016/11/01', '2016/11/01', '2016-11-03 15:57:57.337838', '2016-11-03 15:57:57.337838');


--
-- Name: notice_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('notice_no_seq', 1920, true);


--
-- Data for Name: question; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (232, '파스타 포털에 오신걸 환영합니다. 4', 'question_build_pack', 'admin', '파스타 포털에 오신걸 환영합니다. 4', NULL, 'waiting', 'supra.jpg', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/1a5f3b0bc7454166abaddf9c5e9616af.jpg', 473342, '2016-08-30 15:22:41.154487', '2016-08-30 15:22:41.154487');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (233, '파스타 포털에 오신걸 환영합니다. 5', 'question_starter', 'admin', '파스타 포털에 오신걸 환영합니다. 5', NULL, 'waiting', 'large_supra.JPG', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/cf71831f8b1349d185fabba425b8633f.JPG', 473342, '2016-08-30 15:22:48.511716', '2016-08-30 15:23:29.605481');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (231, '파스타 포털에 오신걸 환영합니다. 3', 'question_etc', 'admin', '파스타 포털에 오신걸 환영합니다. 3', NULL, 'waiting', 'm5.jpg', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/a3255de17fc8431c8604ce6265e03d92.jpg', 31235, '2016-08-30 15:08:15.150194', '2016-08-30 15:23:46.329753');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (235, 'no image 테스트 7', 'question_starter', 'admin', 'no image 테스트 7', NULL, 'waiting', '', '', 0, '2016-08-30 15:24:22.73234', '2016-08-30 15:24:39.865045');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (239, 'no image 테스트 11', 'question_starter', 'admin', 'no image 테스트 11', NULL, 'answered', '', '', 0, '2016-08-30 15:25:14.81336', '2016-09-01 14:41:20.760795');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (2, '파스타 포털에 오신걸 환영합니다. 1', 'question_starter', 'admin', '파스타 포털에 오신걸 환영합니다. 1', NULL, 'waiting', 'test_img.jpg', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/587019541fed4d9bb7a62f9e395d0edf.jpg', 590641, '2016-08-26 10:23:37.965013', '2016-08-30 15:21:49.52964');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (3, '파스타 포털에 오신걸 환영합니다. 2', 'question_service_pack', 'admin', 'Welcome to Cloud Foundry

Cloud Foundry is an open platform as a service (PaaS) that provides a choice of clouds, developer frameworks, and application services. Cloud Foundry makes it faster and easier to build, test, deploy, and scale applications.

This repository contains the Cloud Foundry source code. Cloud Foundry is deployed as a BOSH release. See the BOSH documentation for more information on BOSH.

Documentation
Release Notes
CI
Mailing List
Table of Contents

About Branches
Repository Contents
Cloud Foundry Components (V2)
Running Cloud Foundry
Useful Scripts
Ask Questions
File a Bug
Understanding Changes
Contributions
About Branches

The develop branch is where we do active development. Although we endeavor to keep the develop branch stable, we do not guarantee that any given commit will deploy cleanly.

The release-candidate branch has passed all of our unit, integration, smoke, & acceptance tests, but has not been used in a final release yet. This branch should be fairly stable.

The master branch points to the most recent stable final release.

At semi-regular intervals a final release is created from the release-candidate branch. This final release is tagged and pushed to the master branch.

Pushing to any branch other than develop will create problems for the CI pipeline, which relies on fast forward merges. To recover from this condition follow the instructions here.

Repository Contents

This repository is structured for use with BOSH; an open source tool for release engineering, deployment and lifecycle management of large scale distributed services. There are several directories of note:

jobs: start and stop commands for each of the jobs (processes) running on Cloud Foundry nodes.
packages: packaging instructions used by BOSH to build each of the dependencies.
src: the source code for the components in Cloud Foundry. Note that each of the components is a submodule with a pointer to a specific SHA.
releases: yml files containing the references to blobs for each package in a given release; these are solved within .final_builds
.final_builds: references into the public blostore for final jobs & packages (each referenced by one or more releases)
config: URLs and access credentials to the bosh blobstore for storing final releases
git: Local git hooks
Running Cloud Foundry

Cloud Foundry can be run locally or in the cloud. The best way to run Cloud Foundry is to deploy it using BOSH. For more information about using BOSH, the bosh-release repository has links to documentation, mailing lists, and IRC channels.

To run BOSH and Cloud Foundry locally, use BOSH-Lite. BOSH-Lite provisions a Vagrant VM running the BOSH director as well as Garden-Linux for creating Linux containers that simulate VMs in a real IaaS.

To run BOSH and Cloud Foundry in the cloud, there are several supported IaaS providers, primarily AWS, vSphere, and OpenStack.

Full instructions on infrastructure setup, building Cloud Foundry, and deploying Cloud Foundry with BOSH are available on our documentation site.

Cloud Foundry Components (V2)

The current development efforts center on V2, also known as NG. For information on what the core team is working on, please see our roadmap.

The components in a V2 deployment are:

Component	Description
Cloud Controller (cc)	The primary API entry point for Cloud Foundry. API documentation here.
gorouter	The central router that manages traffic to applications deployed on Cloud Foundry.
DEA (dea_next)	The droplet execution agent (DEA) performs two key activities in Cloud Foundry: staging and hosting applications.
Health Manager	The health manager monitors the state of the applications and ensures that started applications are indeed running, their versions and number of instances correct.
UAA	The UAA (User Account and Authentication) is the identity management service for Cloud Foundry.
Collector	The collector will discover the various components on the message bus and query their /healthz and /varz interfaces.
Loggregator	Loggregator is the user application logging subsystem for Cloud Foundry.
Useful Scripts

scripts/update pulls cf-release and updates all submodules (recursively) to the correct commit. This is useful in the following situations:
After you''ve first cloned the repo
Before you make changes to the directory. (Running the script avoids having to rebase your changes on top of submodule updates.)
scripts/setup-git-hooks will ensure basic unit tests run before committing.
scripts/commit_with_shortlog commits changes you''ve made to updated git submodules.
Ask Questions

Questions about the Cloud Foundry Open Source Project can be directed to our Mailing Lists: https://lists.cloudfoundry.org/mailman/listinfo

There are lists for Cloud Foundry Developers, BOSH Users, and BOSH Developers.

File a Bug

Bugs can be filed using GitHub Issues in the respective repository of each Cloud Foundry component.

Understanding Changes

You can generate an HTML document which will show all commits between any two given SHAs, branches, tags, or other references, and then view it in your favourite browser:

$ bundle && bundle exec git_release_notes html --from=v210 --to=v212 > /tmp/changes.html && open /tmp/changes.html
Contributions

Please read the contributors'' guide', NULL, 'waiting', '다운로드.png', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/d170d9e34d5c4d0389627cc5869b7b04.png', 11977, '2016-08-26 10:24:15.748969', '2016-08-30 17:14:36.356791');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (234, '파스타 포털에 오신걸 환영합니다. 6', 'question_starter', 'admin', '파스타 포털에 오신걸 환영합니다. 6', NULL, 'answered', 'org_noimage.jpg', 'http://52.201.48.51:8080/v1/KEY_84586dfdc15e4f8b9c2a8e8090ed9810/portal-container/de6dc49f53bd47d796b2040b39025d29.jpg', 11676, '2016-08-30 15:23:02.161585', '2016-09-12 14:44:29.510995');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (238, 'no image 테스트 10', 'question_starter', 'admin', 'no image 테스트 10', NULL, 'answered', '', '', 0, '2016-08-30 15:25:07.127103', '2016-09-26 15:23:24.795069');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (237, 'no image 테스트 9', 'question_starter', 'admin', 'no image 테스트 9', NULL, 'answered', '', '', 0, '2016-08-30 15:24:58.215381', '2016-09-26 15:25:28.636574');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (236, 'no image 테스트 8', 'question_starter', 'admin', 'no image 테스트 8', NULL, 'answered', '', '', 0, '2016-08-30 15:24:49.284318', '2016-09-26 15:29:55.872613');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (2338, '문의합니다', 'question_etc', 'admin', '문의합니다', NULL, 'waiting', '시범사업_Help_Desk_준공_보고서.pdf', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/37e3937df57f4aa48d708ecaf44b7844.pdf', 3816381, '2016-10-24 17:28:11.22554', '2016-10-24 18:09:47.368535');
INSERT INTO question (no, title, classification, user_id, content, cell_phone, status, file_name, file_path, file_size, created, lastmodified) VALUES (2339, '문의', 'question_starter', 'admin', '내용', NULL, 'waiting', '', '', 0, '2016-10-25 06:15:40.312408', '2016-10-25 06:15:40.312408');


--
-- Name: question_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('question_no_seq', 2390, true);


--
-- Data for Name: servicepack_category; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (1130, 'RabbitMQ 메시지 큐 서비스', 'service_message', 'RabbitMQ는 AMQP를 구현한 비동기 메시지 큐 ', 'AMQP(Advanced Message Queuing Protocol)을 사용한 오픈소스 비동기방식 메시지 지향 미들웨어이다.', 'p-rabbitmq', 'rabbitmq.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/24501734d88b464a87e4b598082a4b98.jpg', 'N', 'admin', '2016-07-22 10:50:06.594368', '2016-08-31 00:42:01.030642');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (8, 'Mongo-DB DBMS 서비스', 'service_nosql', 'Mongo-DB 도큐먼트 지향 NoSQL DBMS', 'MongoDB는 크로스 플랫폼 도큐먼트 지향 데이터베이스 시스템이며 NoSQL 데이터베이스로 분류되는 MongoDB는 JSON과 같은 동적 스키마형 문서들을 선호함에 따라 전통적인 테이블 기반 관계형 데이터베이스 구조의 사용을 삼간다. ', 'Mongo-DB', 'mongodb.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/1d3ba87ece904759bf56c09b1b4b08a6.png', 'N', 'admin', '2016-07-19 11:12:45.224413', '2016-08-31 00:42:15.602993');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (3124, '큐브리드 DBMS 서비스', 'service_rdbms', '큐브리드 관계형 DBMS 서비스', '큐브리드는 관계형 DBMS로서 엔터프라이즈 시장에서 요구하는 대용량 데이터 처리 능력 및 성능, 안정성, 가용성, 관리 편의성을 제공하고 있다.', 'CubridDB', '큐브리드디비.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/a9abf2dfcc624752b79c4267f6e7ea32.jpg', 'N', 'admin', '2016-07-26 05:44:57.453243', '2016-08-31 00:45:46.233359');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (20565, 'test 12', 'service_storage', 'test 112', 'test 1112', 'Pinpoint', '', '', 'Y', 'admin', '2016-09-12 16:17:39.608458', '2016-09-12 16:18:20.056408');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (1756, 'Redis 서비스', 'service_nosql', 'Redis NoSQL 및 In memory 서비스', 'Redis는 메모리 기반의 Key/Value Store 로써 NoSQL DBMS 및 In memory 솔루션으로 분리된다.', 'redis-sb', 'Redis서비스.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/e9e2aab90494465896d62092b245ce10.jpg', 'Y', 'admin', '2016-07-22 14:45:36.180601', '2016-08-23 06:13:49.985041');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (3126, 'Java 애플리케이션 APM 서비스', 'service_monitoring', 'Java 애플리케이션 대규모 분산 시스템 성능을 분석', 'Pinpoint는 자바 애플리케이션 대규모 분산 시스템의 성능을 분석하고 문제를 진단, 처리하는 플랫폼입니다. ', 'Pinpoint', 'pinpoint서비스.jpg', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/317dad4db307400491aa0e6144abf89b.jpg', 'Y', 'admin', '2016-07-26 05:50:50.690989', '2016-08-24 10:35:21.291381');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (3125, 'Swift 오브젝트 스토리지 서비스', 'service_storage', 'Swift Object 데이터 저장소', 'Swift 오브젝트 스토리지는 비정형 클라우드 데이터 저장소를 제공하여 시장에 낮은 비용, 신뢰성, 속도로 클라우드 애플리케이션 및 서비스를 빌드하고 제공합니다. ', 'glusterfs', '오브젝트스토리지.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/fa583ef4977147cba90658af495ba028.png', 'Y', 'admin', '2016-07-26 05:46:31.424795', '2016-08-24 10:36:42.007472');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (3123, 'Mqsql DBMS 서비스', 'service_rdbms', 'Mysql 관계형 DBMS 서비스', 'MySQL은 가장 많이 쓰이는 오픈 소스의 관계형 데이터베이스 관리 시스템(RDBMS)이고 다중 스레드, 다중 사용자 형식의 구조질의어 형식의 데이터베이스 관리 시스템이다.', 'Mysql-DB', 'mysqldb.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/c1821745ed1246e6b848752457334185.png', 'Y', 'admin', '2016-07-26 04:32:32.150908', '2016-08-24 10:37:03.781339');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (32375, 'star test', 'service_storage', '스타 테스트', '', 'redis-sb', '', '', 'N', 'admin', '2016-11-03 15:53:03.85869', '2016-11-03 16:38:49.954299');
INSERT INTO servicepack_category (no, name, classification, summary, description, service_name, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (32373, '서비스 테스트1', 'service_rdbms', '서비스 테스트1', '', 'Pinpoint', 'MTR_Map.gif', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/7f41032744e444ce9cd2b8591f6e28d1.gif', 'N', 'admin', '2016-11-03 15:42:24.479367', '2016-11-03 16:38:53.917516');


--
-- Name: servicepack_category_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('servicepack_category_no_seq', 32650, true);


--
-- Data for Name: starter_buildpack_relation; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO starter_buildpack_relation (no, starter_category_no, buildpack_category_no) VALUES (81, 127, 20);
INSERT INTO starter_buildpack_relation (no, starter_category_no, buildpack_category_no) VALUES (82, 128, 3157);
INSERT INTO starter_buildpack_relation (no, starter_category_no, buildpack_category_no) VALUES (9563, 9609, 3155);
INSERT INTO starter_buildpack_relation (no, starter_category_no, buildpack_category_no) VALUES (16847, 16893, 665);
INSERT INTO starter_buildpack_relation (no, starter_category_no, buildpack_category_no) VALUES (31385, 31431, 20);
INSERT INTO starter_buildpack_relation (no, starter_category_no, buildpack_category_no) VALUES (31386, 31432, 3158);


--
-- Name: starter_buildpack_relation_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('starter_buildpack_relation_no_seq', 31666, true);


--
-- Data for Name: starter_category; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO starter_category (no, name, classification, summary, description, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (127, 'Java + Mysql', 'starter_main', 'Java Tomcat 환경의 MysqlDB  앱 템플릿', '자바8 Tomcat 앱 개발 환경과  Mysql DB  서비스로 애플리케이션을 개발합니다.', '자바+mysql.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/032cdb937c554b3e85b483ee9749e6f7.png', 'Y', 'admin', '2016-07-20 14:54:38.95811', '2016-08-31 00:43:44.153917');
INSERT INTO starter_category (no, name, classification, summary, description, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (128, 'NodeJS + Mongo-DB 앱 템플릿', 'starter_main', 'NodeJS + Mongo-DB 앱 템플릿', 'NodeJS 앱 개발 환경과 No-SQL Mongo DB 서비스를 사용하여 애플리케이션을 개발합니다.', 'Node+mongodb.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/f5b3ea693cc2404e85e4f2265913ca19.png', 'N', 'admin', '2016-07-20 14:55:42.810425', '2016-08-31 00:44:01.072904');
INSERT INTO starter_category (no, name, classification, summary, description, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (9609, '전자정부 프레임워크 웹 애플리케이션 템플릿', 'starter_main', '전자정부 프레임워크 웹 애플리케이션 앱 템플릿', '전자정부 프레임워크 앱 개발 환경과 함께 Mysql DB 서비스를 사용하고 Redis 및 Object 저장소를 사용합니다.', '앱스타터이미지.png', 'http://52.201.48.51:8080/v1/KEY_14a87aaee3fa4b73b9944bd52c8b031a/portal-container/9417a5abbc9d47f69597ce140552c3ba.png', 'Y', 'admin', '2016-08-22 07:18:29.937784', '2016-08-31 00:45:37.144841');
INSERT INTO starter_category (no, name, classification, summary, description, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (16893, 'starter mysql test', 'starter_main', 'mysql test 1', 'mysql test 2', 'img7006859357306346388.png', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/a4beb57d63484bea93c94df8760c54db.png', 'Y', 'admin', '2016-09-05 17:56:31.08907', '2016-10-28 12:55:46.182844');
INSERT INTO starter_category (no, name, classification, summary, description, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (31431, '템플릿 테스트', 'starter_main', '템플릿 테스트', '', '캡처.PNG', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/5f20e16e96a741e8a10ffa7381effc3c.PNG', 'N', 'admin', '2016-11-03 15:44:21.411394', '2016-11-03 16:38:24.136759');
INSERT INTO starter_category (no, name, classification, summary, description, thumb_img_name, thumb_img_path, use_yn, user_id, created, lastmodified) VALUES (31432, 'Star test', 'starter_main', '스타 테스트', '', '', '', 'N', 'admin', '2016-11-03 15:52:31.698639', '2016-11-03 16:38:29.82748');


--
-- Name: starter_category_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('starter_category_no_seq', 31712, true);


--
-- Data for Name: starter_servicepack_relation; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (24968, 127, 3125);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (24969, 127, 3123);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (24970, 128, 8);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (24971, 9609, 1756);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (24972, 9609, 3123);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (24973, 9609, 3125);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (617525, 16893, 3123);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (678218, 31431, 8);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (678219, 31431, 3124);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (678220, 31431, 3125);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (678221, 31432, 8);
INSERT INTO starter_servicepack_relation (no, starter_category_no, servicepack_category_no) VALUES (678222, 31432, 3124);


--
-- Name: starter_servicepack_relation_no_seq; Type: SEQUENCE SET; Schema: public; Owner: portaladmin
--

SELECT pg_catalog.setval('starter_servicepack_relation_no_seq', 694187, true);


--
-- Data for Name: user_detail; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('mingu', '1', '01044441111', '', '', '', '조민구', 'N', NULL, 0, '2016-09-28', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/bdb496b84e3c49e6b8343a5797fe1ba0.png');
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('yjasmin2@gmail.com', '1', NULL, NULL, NULL, NULL, '이인정', 'N', 'F3LYTHTDRTSNLJWIFHQ', 2, '2016-11-01', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('openpasta@gmail.com', '1', NULL, NULL, NULL, NULL, '오픈파스타', 'N', '', 0, '2016-10-05', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('admin', '1', '01000000000', '222222', 'admin_addr', 'admin_addr_detail', '관리자', 'Y', NULL, 0, '2016-09-28', 'http://52.201.48.51:8080/v1/KEY_508666cb499b4970a5030fb067cb3557/portal-container/99736290e9254eb2a9812773d51f76b3.png');
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('chsong', '1', '01026599152', '', '', '', '송창학', 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('ijlee@bluedigm.com', '0', NULL, NULL, NULL, NULL, NULL, 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('junit-test-user', '1', '01034344350', '', '', '', '테스트유저', 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('kimdojun', '1', NULL, NULL, NULL, NULL, NULL, 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('nia', '1', '0000000000', '', '', '', '한국정보화진흥원', 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('no-org-user', '1', NULL, NULL, NULL, NULL, NULL, 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('chsong@bluedigm.com', '1', NULL, NULL, NULL, NULL, '송창학', 'N', 'KMM59OB1KXDHECILPDG', 2, '2016-09-30', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('test-user', '1', NULL, NULL, NULL, NULL, NULL, 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('gramryn@gmail.com', '1', NULL, NULL, NULL, NULL, '창학송', 'N', '', 0, '2016-11-01', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('mingu@bluedigm.com', '1', '01022222222', '222222', 'mingu_addr', 'mingu_arrd_detail', '조민구', 'Y', 'N58JK7HLMI91AYS2HUE', 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('test', '0', NULL, NULL, NULL, NULL, 'test', 'N', NULL, 0, '2016-09-28', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('yjkim@bluedigm.com', '1', NULL, NULL, NULL, NULL, 'yjkim', 'Y', 'VRHOTMAWHOEPQN1LJQN', 3, '2016-11-02', NULL);
INSERT INTO user_detail (user_id, status, tell_phone, zip_code, address, address_detail, user_name, admin_yn, refresh_token, auth_access_cnt, auth_access_time, img_path) VALUES ('insertUser', '1', NULL, NULL, NULL, NULL, NULL, 'N', 'N9TVLSLPWIXIBOUNY4L', 0, '2016-11-04', NULL);


--
-- Data for Name: web_ide_user; Type: TABLE DATA; Schema: public; Owner: portaladmin
--

INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('admin', 'OCP', 'http://115.68.46.183:8080', 'Y', '2016-10-25 00:34:16.243654', '2016-10-25 00:52:55.395419');
INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('yjkim@bluedigm.com', 'hi', 'http://115.68.46.183:8080', 'Y', '2016-11-03 17:11:00.547589', '2016-11-03 17:11:08.429017');
INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('nia', 'nia.org', '', 'N', '2016-10-06 08:10:39.876985', '2016-10-31 10:02:02.669804');
INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('admin', 'nia.or.kr', 'http://115.68.46.184:8080', 'Y', '2016-09-19 01:22:52.716058', '2016-10-31 10:02:12.866205');
INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('admin', 'abcdefghij', NULL, 'N', '2016-10-26 10:40:56.320621', NULL);
INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('admin', 'yjkim', 'http://115.68.46.183:8080', 'Y', '2016-10-27 05:04:31.444674', '2016-11-03 17:02:44.366115');
INSERT INTO web_ide_user (user_id, org_name, url, use_yn, created_at, updated_at) VALUES ('admin', 'sample_test', '', 'N', '2016-09-12 02:10:28.130412', '2016-10-24 13:33:02.133526');


--
-- Name: answer_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY answer
    ADD CONSTRAINT answer_pkey PRIMARY KEY (no);


--
-- Name: auto_scaling_config_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY auto_scaling_config
    ADD CONSTRAINT auto_scaling_config_pkey PRIMARY KEY (no);


--
-- Name: board_comment_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY board_comment
    ADD CONSTRAINT board_comment_pkey PRIMARY KEY (no);


--
-- Name: board_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY board
    ADD CONSTRAINT board_pkey PRIMARY KEY (no);


--
-- Name: bom_key; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY bom
    ADD CONSTRAINT bom_key PRIMARY KEY (item_id);


--
-- Name: buildpack_category_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY buildpack_category
    ADD CONSTRAINT buildpack_category_pkey PRIMARY KEY (no);


--
-- Name: catalog_history_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY catalog_history
    ADD CONSTRAINT catalog_history_pkey PRIMARY KEY (no);


--
-- Name: code_group_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY code_group
    ADD CONSTRAINT code_group_pkey PRIMARY KEY (id);


--
-- Name: config_info_primary; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY config_info
    ADD CONSTRAINT config_info_primary PRIMARY KEY (name);


--
-- Name: documents_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (no);


--
-- Name: invite_org_space_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY invite_org_space
    ADD CONSTRAINT invite_org_space_pkey PRIMARY KEY (id);


--
-- Name: menu_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY menu
    ADD CONSTRAINT menu_pkey PRIMARY KEY (no);


--
-- Name: notice_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY notice
    ADD CONSTRAINT notice_pkey PRIMARY KEY (no);


--
-- Name: question_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY question
    ADD CONSTRAINT question_pkey PRIMARY KEY (no);


--
-- Name: servicepack_category_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY servicepack_category
    ADD CONSTRAINT servicepack_category_pkey PRIMARY KEY (no);


--
-- Name: starter_buildpack_relation_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY starter_buildpack_relation
    ADD CONSTRAINT starter_buildpack_relation_pkey PRIMARY KEY (no);


--
-- Name: starter_category_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY starter_category
    ADD CONSTRAINT starter_category_pkey PRIMARY KEY (no);


--
-- Name: starter_servicepack_relation_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY starter_servicepack_relation
    ADD CONSTRAINT starter_servicepack_relation_pkey PRIMARY KEY (no);


--
-- Name: user_detail_pkey; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY user_detail
    ADD CONSTRAINT user_detail_pkey PRIMARY KEY (user_id);


--
-- Name: web_ide_user_primary; Type: CONSTRAINT; Schema: public; Owner: portaladmin
--

ALTER TABLE ONLY web_ide_user
    ADD CONSTRAINT web_ide_user_primary PRIMARY KEY (org_name);


--
-- Name: public; Type: ACL; Schema: -; Owner: vcap
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM vcap;
GRANT ALL ON SCHEMA public TO vcap;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

