#!/bin/bash

# ENVIRONMENTS
PSQL_VERSION=postgres-9.4.6
PSQL_USER=vcap
PSQL_PORT=5524
PSQL_BIN_DIR=/var/vcap/packages/$PSQL_VERSION/bin
INIT_SQL_DIR=.

# DROP
$PSQL_BIN_DIR/psql -U $PSQL_USER -p $PSQL_PORT -d postgres -c "DROP DATABASE \"portaldb\""
$PSQL_BIN_DIR/psql -U $PSQL_USER -p $PSQL_PORT -d postgres -c "DROP ROLE \"portaladmin\""

# CREATE
$PSQL_BIN_DIR/psql -U $PSQL_USER -p $PSQL_PORT -d postgres -c "CREATE ROLE \"portaladmin\""
$PSQL_BIN_DIR/psql -U $PSQL_USER -p $PSQL_PORT -d postgres -c "ALTER ROLE \"portaladmin\" WITH LOGIN PASSWORD 'admin'"
$PSQL_BIN_DIR/psql -U $PSQL_USER -p $PSQL_PORT -d postgres -c "CREATE DATABASE \"portaldb\""
$PSQL_BIN_DIR/psql -U portaladmin -p $PSQL_PORT -d portaldb -a -f $INIT_SQL_DIR/postgresql.sql

